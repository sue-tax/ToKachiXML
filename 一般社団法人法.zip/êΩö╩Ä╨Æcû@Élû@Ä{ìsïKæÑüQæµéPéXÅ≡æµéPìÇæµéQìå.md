<font color="lightsalmon">（報酬等の額の算定方法）</font>
[一般社団法人法施行規則第１９条第１項](一般社団法人法施行規則＿第１９条第１項)第２号

イに掲げる額をロに掲げる数で除して得た額

　イ　次に掲げる額の合計額

　　<font color="lightsalmon">（１）</font>　当該役員等が当該一般社団法人から受けた退職慰労金の額

　　<font color="lightsalmon">（２）</font>　当該役員等が当該一般社団法人の使用人を兼ねていた場合における当該使用人としての退職手当のうち当該役員等を兼ねていた期間の職務執行の対価である部分の額

　　<font color="lightsalmon">（３）</font>　<font color="lightsalmon">（１）</font>又は<font color="lightsalmon">（２）</font>に掲げるものの性質を有する財産上の利益の額

　ロ　当該役員等がその職に就いていた年数<font color="lightsalmon">（当該役員等が次に掲げるものに該当する場合における次に定める数が当該年数を超えている場合にあっては、当該数）</font>

　　<font color="lightsalmon">（１）</font>　代表理事　六

　　<font color="lightsalmon">（２）</font>　代表理事以外の理事であって、次に掲げる者　四

　　<font color="lightsalmon">（ⅰ）</font>　理事会の決議によって一般社団法人の業務を執行する理事として選定されたもの

　　<font color="lightsalmon">（ⅱ）</font>　当該一般社団法人の業務を執行した理事<font color="lightsalmon">（<font color="darkkhaki">（ⅰ）</font>に掲げる理事を除く。）</font>

　　<font color="lightsalmon">（ⅲ）</font>　当該一般社団法人の使用人

　　<font color="lightsalmon">（３）</font>　理事<font color="lightsalmon">（<font color="darkkhaki">（１）</font>及び<font color="darkkhaki">（２）</font>に掲げるものを除く。）</font>、監事又は会計監査人　二

--- ---

[条(全)](一般社団法人法施行規則＿第１９条_.md)    [項(全)](一般社団法人法施行規則＿第１９条第１項_.md)    [項](一般社団法人法施行規則＿第１９条第１項.md)

[前号←](一般社団法人法施行規則＿第１９条第１項第１号.md)  ~~→次号~~

[目次](index一般社団法人法施行規則.md)

