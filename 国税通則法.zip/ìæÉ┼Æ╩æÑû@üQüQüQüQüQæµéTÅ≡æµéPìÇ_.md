<font color="lightsalmon">（相続による国税の納付義務の承継）</font>
国税通則法第５条第１項

相続<font color="lightsalmon">（包括遺贈を含む。以下同じ。）</font>があつた場合には、相続人<font color="lightsalmon">（包括受遺者を含む。以下同じ。）</font>又は民法<font color="lightsalmon">（明治二十九年法律第八十九号）</font>第九百五十一条<font color="lightsalmon">（相続財産法人の成立）</font>の法人は、その被相続人<font color="lightsalmon">（包括遺贈者を含む。以下同じ。）</font>に課されるべき、又はその被相続人が納付し、若しくは徴収されるべき国税<font color="lightsalmon">（その滞納処分費を含む。次章、第三章第一節<font color="darkkhaki">（国税の納付）</font>、第六章<font color="darkkhaki">（附帯税）</font>、第七章第一節<font color="darkkhaki">（国税の更正、決定等の期間制限）</font>、第七章の二<font color="darkkhaki">（国税の調査）</font>及び第十一章<font color="darkkhaki">（犯則事件の調査及び処分）</font>を除き、以下同じ。）</font>を納める義務を承継する。この場合において、相続人が限定承認をしたときは、その相続人は、相続によつて得た財産の限度においてのみその国税を納付する責めに任ずる。


---

[条(全)](国税通則法＿＿＿＿＿第５条_.md)  [項](国税通則法＿＿＿＿＿第５条第１項.md)

~~前項(全)←~~　  [→次項(全)](国税通則法＿＿＿＿＿第５条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](国税通則法＿＿＿＿＿第５条第２項.md)



[目次](index国税通則法＿＿＿＿.md)

