<font color="lightsalmon">（賦課決定）</font>
国税通則法第３２条第５項

第二十七条<font color="lightsalmon">（国税庁又は国税局の職員の調査に基づく更正又は決定）</font>、第二十八条第三項後段<font color="lightsalmon">（決定通知書の附記事項）</font>及び第二十九条<font color="lightsalmon">（更正等の効力）</font>の規定は、第一項又は第二項の規定による決定<font color="lightsalmon">（以下「賦課決定」という。）</font>について準用する。


---

[条(全)](国税通則法＿＿＿＿＿第３２条_.md)  [項](国税通則法＿＿＿＿＿第３２条第５項.md)

[前項(全)←](国税通則法＿＿＿＿＿第３２条第４項_.md)  ~~→次項(全)~~

[前項 　 ←](国税通則法＿＿＿＿＿第３２条第４項.md)  ~~→次項~~



[目次](index国税通則法＿＿＿＿.md)

