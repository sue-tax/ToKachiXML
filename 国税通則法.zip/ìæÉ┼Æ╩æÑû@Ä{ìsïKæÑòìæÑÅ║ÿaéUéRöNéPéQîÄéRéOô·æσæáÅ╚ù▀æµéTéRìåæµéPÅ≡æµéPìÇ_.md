<font color="lightsalmon">（施行期日）</font>
国税通則法施行規則附則昭和６３年１２月３０日大蔵省令第５３号第１条第１項

この省令は、法の施行の日から施行する。ただし、附則第五条、第六条<font color="lightsalmon">（大蔵省組織規程<font color="darkkhaki">（昭和二十四年大蔵省令第三十七号）</font>第九十条第一項第五号の改正規定に限る。）</font>、附則第七条<font color="lightsalmon">（税関職員の身分を示す証票等の書式に関する省令<font color="darkkhaki">（昭和二十九年大蔵省令第六十四号）</font>の改正規定中<font color="peru">「第三十四条第四項又は」</font>の下に<font color="peru">「消費税法第六十二条第四項、」</font>を加える部分を除く。）</font>、附則第八条から第十条まで、第十一条<font color="lightsalmon">（国税質問検査章規則<font color="darkkhaki">（昭和四十年大蔵省令第四十九号）</font>第二条第一号の改正規定中<font color="peru">「第百五十七条」</font>の下に<font color="peru">「、消費税法（昭和六十三年法律第百八号）第六十二条第四項」</font>を加える部分を除く。）</font>、附則第十三条及び第十四条<font color="lightsalmon">（沖縄の復帰に伴う国税関係法令の適用の特別措置等に関する省令<font color="darkkhaki">（昭和四十七年大蔵省令第四十二号）</font>第三十条の次に一条を加える改正規定を除く。）</font>の規定は、平成元年四月一日から施行する。

--- ---


[条(全)](国税通則法施行規則附則昭和６３年１２月３０日大蔵省令第５３号第１条_.md)  [項](国税通則法施行規則附則昭和６３年１２月３０日大蔵省令第５３号第１条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index国税通則法施行規則.md)

