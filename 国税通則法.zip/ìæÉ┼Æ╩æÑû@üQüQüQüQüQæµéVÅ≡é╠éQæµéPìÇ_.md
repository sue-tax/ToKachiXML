<font color="lightsalmon">（信託に係る国税の納付義務の承継）</font>
国税通則法第７条の２第１項

信託法<font color="lightsalmon">（平成十八年法律第百八号）</font>第五十六条第一項各号<font color="lightsalmon">（受託者の任務の終了事由）</font>に掲げる事由により受託者の任務が終了した場合において、新たな受託者<font color="lightsalmon">（以下この項及び第六項において「新受託者」という。）</font>が就任したときは、当該新受託者は当該受託者に課されるべき、又は当該受託者が納付し、若しくは徴収されるべき国税<font color="lightsalmon">（その納める義務が信託財産責任負担債務<font color="darkkhaki">（同法第二条第九項<font color="springgreen">（定義）</font>に規定する信託財産責任負担債務をいう。第三十八条第一項<font color="springgreen">（繰上請求）</font>及び第五十七条第一項<font color="springgreen">（充当）</font>において同じ。）</font>となるものに限る。以下この条において同じ。）</font>を納める義務を承継する。


---

[条(全)](国税通則法＿＿＿＿＿第７条の２_.md)  [項](国税通則法＿＿＿＿＿第７条の２第１項.md)

~~前項(全)←~~　  [→次項(全)](国税通則法＿＿＿＿＿第７条の２第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](国税通則法＿＿＿＿＿第７条の２第２項.md)



[目次](index国税通則法＿＿＿＿.md)

