<font color="lightsalmon">（仮決算をした場合の中間申告書の記載事項等）</font>
[法人税法第１４４条の４第４項](法人税法＿＿＿＿＿第１４４条の４第４項)第２号

[第百四十二条第二項](法人税法＿＿＿＿＿第１４２条第２項)<font color="lightsalmon">（恒久的施設帰属所得に係る所得の金額の計算）</font>の規定により前編第一章第一節第三款<font color="lightsalmon">（[第二十三条の二](法人税法＿＿＿＿＿第２３条の２第１項)<font color="darkkhaki">（外国子会社から受ける配当等の益金不算入）</font>を除く。）</font>、第四款<font color="lightsalmon">（[第四十六条](法人税法＿＿＿＿＿第４６条第１項)<font color="darkkhaki">（非出資組合が賦課金で取得した固定資産等の圧縮額の損金算入）</font>を除く。）</font>及び第七款<font color="lightsalmon">（課税標準及びその計算）</font><font color="lightsalmon">（[第五十七条第二項](法人税法＿＿＿＿＿第５７条第２項)及び[第十項](法人税法＿＿＿＿＿第１４４条の４第１０項)<font color="darkkhaki">（欠損金の繰越し）</font>並びに[第五十八条第三項](法人税法＿＿＿＿＿第５８条第３項)<font color="darkkhaki">（青色申告書を提出しなかつた事業年度の欠損金の特例）</font>を除く。）</font>の規定に準じて計算する場合におけるこれらの規定中<font color="peru">「確定した決算」</font>とあるのは<font color="peru">「決算」</font>と、<font color="peru">「確定申告書」</font>とあるのは<font color="peru">「中間申告書」</font>と読み替えるものとする。

--- ---

[条(全)](法人税法＿＿＿＿＿第１４４条の４_.md)    [項(全)](法人税法＿＿＿＿＿第１４４条の４第４項_.md)    [項](法人税法＿＿＿＿＿第１４４条の４第４項.md)

[前号←](法人税法＿＿＿＿＿第１４４条の４第４項第１号.md)  ~~→次号~~

[目次](index法人税法＿＿＿＿.md)

