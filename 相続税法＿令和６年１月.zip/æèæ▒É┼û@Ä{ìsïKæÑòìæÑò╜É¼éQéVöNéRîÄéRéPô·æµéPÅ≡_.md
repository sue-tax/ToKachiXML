<font color="lightsalmon">（施行期日）</font>
相続税法施行規則附則平成２７年３月３１日第１条

１　この省令は、平成二十七年四月一日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第三十条<font color="lightsalmon">（見出しを含む。）</font>の改正規定<font color="lightsalmon">（同条第三項第五号イ<font color="darkkhaki">（３）</font>を同号イ<font color="darkkhaki">（４）</font>とし、同号イ<font color="darkkhaki">（２）</font>の次に次のように加える部分、同号ロ<font color="darkkhaki">（２）</font>に係る部分及び同号ハ<font color="darkkhaki">（５）</font>を同号ハ<font color="darkkhaki">（６）</font>とし、同号ハ<font color="darkkhaki">（２）</font>から<font color="darkkhaki">（４）</font>までを同号ハ<font color="darkkhaki">（３）</font>から<font color="darkkhaki">（５）</font>までとし、同号ハ<font color="darkkhaki">（１）</font>の次に次のように加える部分を除く。）</font>、第三十一条の改正規定、第五号書式の改正規定、第六号書式の改正規定、第八号書式の改正規定及び同号書式を第九号書式とし、第七号書式の次に次の書式を加える改正規定並びに附則第三条及び第四条の規定　平成三十年一月一日

二　第九条の改正規定、同条第三号を削る改正規定、第十一条第一項第一号の改正規定及び第十六条第三項第二号の改正規定並びに次条の規定　行政手続における特定の個人を識別するための番号の利用等に関する法律の施行に伴う関係法律の整備等に関する法律<font color="lightsalmon">（平成二十五年法律第二十八号）</font>附則第三号に掲げる規定の施行の日


---

~~前条(全)←~~　  [→次条(全)](相続税法施行規則附則平成２７年３月３１日第２条_.md)

[第１項(全)](相続税法施行規則附則平成２７年３月３１日第１条第１項_.md)  

[第１項 　 ](相続税法施行規則附則平成２７年３月３１日第１条第１項.md)  

[目次](index相続税法施行規則.md)

