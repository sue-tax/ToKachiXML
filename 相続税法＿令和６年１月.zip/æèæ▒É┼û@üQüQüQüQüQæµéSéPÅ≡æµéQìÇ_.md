<font color="lightsalmon">（物納の要件）</font>
相続税法第４１条第２項

前項の規定による物納に充てることができる財産は、納税義務者の課税価格計算の基礎となつた財産<font color="lightsalmon">（当該財産により取得した財産を含み、第二十一条の九第三項の規定の適用を受ける財産を除く。）</font>でこの法律の施行地にあるもののうち次に掲げるもの<font color="lightsalmon">（管理又は処分をするのに不適格なものとして政令で定めるもの<font color="darkkhaki">（第四十五条第一項において「管理処分不適格財産」という。）</font>を除く。）</font>とする。

一　不動産及び船舶

二　次に掲げる有価証券<font color="lightsalmon">（その権利の帰属が社債、株式等の振替に関する法律<font color="darkkhaki">（平成十三年法律第七十五号）</font>の規定により振替口座簿の記載又は記録により定まるもの及び登録国債を含む。）</font>

イ　国債証券及び地方債証券

ロ　社債券<font color="lightsalmon">（特別の法律により法人の発行する債券を含み、短期社債等に係る有価証券を除く。）</font>

ハ　株券<font color="lightsalmon">（特別の法律により法人の発行する出資証券を含む。）</font>

ニ　投資信託及び投資法人に関する法律<font color="lightsalmon">（昭和二十六年法律第百九十八号）</font>第二条第四項<font color="lightsalmon">（定義）</font>に規定する証券投資信託の受益証券

ホ　貸付信託法<font color="lightsalmon">（昭和二十七年法律第百九十五号）</font>第二条第一項<font color="lightsalmon">（定義）</font>に規定する貸付信託の受益証券

ヘ　金融商品取引所<font color="lightsalmon">（金融商品取引法<font color="darkkhaki">（昭和二十三年法律第二十五号）</font>第二条第十六項<font color="darkkhaki">（定義）</font>に規定する金融商品取引所をいう。第五項において同じ。）</font>に上場されている有価証券で次に掲げるもの

<font color="lightsalmon">（１）</font>　新株予約権証券

<font color="lightsalmon">（２）</font>　投資信託及び投資法人に関する法律第二条第三項に規定する投資信託<font color="lightsalmon">（ニに規定する証券投資信託を除く。）</font>の受益証券

<font color="lightsalmon">（３）</font>　投資信託及び投資法人に関する法律第二条第十五項に規定する投資証券<font color="lightsalmon">（トにおいて「投資証券」という。）</font>

<font color="lightsalmon">（４）</font>　資産の流動化に関する法律<font color="lightsalmon">（平成十年法律第百五号）</font>第二条第十三項<font color="lightsalmon">（定義）</font>に規定する特定目的信託の受益証券

<font color="lightsalmon">（５）</font>　信託法第百八十五条第三項<font color="lightsalmon">（受益証券の発行に関する信託行為の定め）</font>に規定する受益証券発行信託の受益証券

ト　投資信託及び投資法人に関する法律第二条第十二項に規定する投資法人<font color="lightsalmon">（その規約に同条第十六項に規定する投資主の請求により投資口<font color="darkkhaki">（同条第十四項に規定する投資口をいう。）</font>の払戻しをする旨が定められているものに限る。）</font>の投資証券で財務省令で定めるもの

三　動産


---

[条(全)](相続税法＿＿＿＿＿第４１条_.md)  [項](相続税法＿＿＿＿＿第４１条第２項.md)

[前項(全)←](相続税法＿＿＿＿＿第４１条第１項_.md)    [→次項(全)](相続税法＿＿＿＿＿第４１条第３項_.md)

[前項 　 ←](相続税法＿＿＿＿＿第４１条第１項.md)    [→次項 　 ](相続税法＿＿＿＿＿第４１条第３項.md)

[第１号](相続税法＿＿＿＿＿第４１条第２項第１号.md)  [第２号](相続税法＿＿＿＿＿第４１条第２項第２号.md)  [第３号](相続税法＿＿＿＿＿第４１条第２項第３号.md)  

[目次](index相続税法＿＿＿＿.md)

