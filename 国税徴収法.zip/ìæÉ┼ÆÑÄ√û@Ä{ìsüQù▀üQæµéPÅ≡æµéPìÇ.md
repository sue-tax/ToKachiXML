<font color="lightsalmon">（定義）</font>
国税徴収法施行令第１条第１項

この政令において、<font color="peru">「国税」</font>、<font color="peru">「地方税」</font>、<font color="peru">「公課」</font>、<font color="peru">「納税者」</font>、<font color="peru">「第二次納税義務者」</font>、<font color="peru">「保証人」</font>、<font color="peru">「滞納者」</font>、<font color="peru">「法定納期限」</font>、<font color="peru">「徴収職員」</font>、<font color="peru">「強制換価手続」</font>、<font color="peru">「執行機関」</font>又は<font color="peru">「行政機関等」</font>とは、それぞれ国税徴収法<font color="lightsalmon">（以下<font color="peru">「法」</font>という。）</font>[第二条第一号](国税徴収法施行＿令＿第２条第１項第１号)、[第二号](国税徴収法施行＿令＿第１条第１項第２号)又は[第五号](国税徴収法施行＿令＿第１条第１項第５号)から[第十三号](国税徴収法施行＿令＿第１条第１項第１３号)まで<font color="lightsalmon">（定義）</font>に規定する国税、地方税、公課、納税者、第二次納税義務者、保証人、滞納者、法定納期限、徴収職員、強制換価手続、執行機関又は行政機関等をいう。

--- ---

[条(全)](国税徴収法施行＿令＿第１条_.md)  [項(全)](国税徴収法施行＿令＿第１条第１項_.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index国税徴収法施行＿令.md)

