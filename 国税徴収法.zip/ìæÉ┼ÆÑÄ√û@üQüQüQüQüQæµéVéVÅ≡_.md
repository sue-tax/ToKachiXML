<font color="lightsalmon">（社会保険制度に基づく給付の差押禁止）</font>
国税徴収法第７７条

１　社会保険制度に基づき支給される退職年金、老齢年金、普通恩給、休業手当金及びこれらの性質を有する給付<font color="lightsalmon">（確定給付企業年金法<font color="darkkhaki">（平成十三年法律第五十号）</font>第三十八条第一項<font color="darkkhaki">（老齢給付金の支給方法）</font>の規定に基づいて支給される年金、確定拠出年金法<font color="darkkhaki">（平成十三年法律第八十八号）</font>第三十五条第一項<font color="darkkhaki">（老齢給付金の支給方法）</font><font color="darkkhaki">（同法第七十三条<font color="springgreen">（企業型年金に係る規定の準用）</font>において準用する場合を含む。）</font>の規定に基づいて支給される年金その他政令で定める退職年金を含む。）</font>に係る債権は給料等と、退職一時金、一時恩給及びこれらの性質を有する給付<font color="lightsalmon">（確定給付企業年金法第三十八条第二項の規定に基づいて支給される一時金及び同法第四十二条<font color="darkkhaki">（脱退一時金の支給方法）</font>の規定に基づいて支給される脱退一時金、確定拠出年金法第三十五条第二項<font color="darkkhaki">（同法第七十三条において準用する場合を含む。）</font>の規定に基づいて支給される一時金その他政令で定める退職一時金を含む。）</font>に係る債権は退職手当等とそれぞれみなして、前条の規定を適用する。

２　前項に規定する社会保険制度とは、次に掲げる法律に基づく保険、共済又は恩給に関する制度その他政令で定めるこれらに類する制度をいう。

一　厚生年金保険法<font color="lightsalmon">（昭和二十九年法律第百十五号）</font>

二　船員保険法<font color="lightsalmon">（昭和十四年法律第七十三号）</font>

三　国民年金法<font color="lightsalmon">（昭和三十四年法律第百四十一号）</font>

四　恩給法<font color="lightsalmon">（大正十二年法律第四十八号）</font><font color="lightsalmon">（他の法律において準用する場合を含む。）</font>

五　国家公務員共済組合法<font color="lightsalmon">（昭和三十三年法律第百二十八号）</font>

六　地方公務員等共済組合法<font color="lightsalmon">（昭和三十七年法律第百五十二号）</font>

七　私立学校教職員共済法<font color="lightsalmon">（昭和二十八年法律第二百四十五号）</font>


---

[前条(全)←](国税徴収法＿＿＿＿＿第７６条_.md)    [→次条(全)](国税徴収法＿＿＿＿＿第７８条_.md)

[第１項(全)](国税徴収法＿＿＿＿＿第７７条第１項_.md)  [第２項(全)](国税徴収法＿＿＿＿＿第７７条第２項_.md)  

[第１項 　 ](国税徴収法＿＿＿＿＿第７７条第１項.md)  [第２項 　 ](国税徴収法＿＿＿＿＿第７７条第２項.md)  

[目次](index国税徴収法＿＿＿＿.md)

