<font color="lightsalmon">（実質課税額等の第二次納税義務）</font>
国税徴収法第３６条第１項

滞納者の次の各号に掲げる国税につき滞納処分を執行してもなおその徴収すべき額に不足すると認められるときは、第一号に定める者にあつては同号に規定する収益が生じた財産<font color="lightsalmon">（その財産の異動により取得した財産及びこれらの財産に基因して取得した財産<font color="darkkhaki">（以下この条及び次条において「取得財産」という。）</font>を含む。）</font>、第二号に定める者にあつては同号に規定する貸付けに係る財産<font color="lightsalmon">（取得財産を含む。）</font>、第三号に定める者にあつてはその受けた利益の額を限度として、その滞納に係る国税の第二次納税義務を負う。

一　所得税法第十二条<font color="lightsalmon">（実質所得者課税の原則）</font>若しくは第百五十八条<font color="lightsalmon">（事業所の所得の帰属の推定）</font>又は法人税法第十一条<font color="lightsalmon">（実質所得者課税の原則）</font>の規定により課された国税　その国税の賦課の基因となつた収益が法律上帰属するとみられる者

二　消費税法<font color="lightsalmon">（昭和六十三年法律第百八号）</font>第十三条<font color="lightsalmon">（資産の譲渡等又は特定仕入れを行つた者の実質判定）</font>の規定により課された国税<font color="lightsalmon">（同法第二条第一項第八号<font color="darkkhaki">（定義）</font>に規定する貸付けに係る部分に限る。）</font>　その国税の賦課の基因となつた当該貸付けを法律上行つたとみられる者

三　所得税法第百五十七条<font color="lightsalmon">（同族会社等の行為又は計算の否認等）</font>若しくは第百六十八条の二<font color="lightsalmon">（非居住者の恒久的施設帰属所得に係る行為又は計算の否認）</font>、法人税法第百三十二条<font color="lightsalmon">（同族会社等の行為又は計算の否認）</font>、第百三十二条の二<font color="lightsalmon">（組織再編成に係る行為又は計算の否認）</font>、第百三十二条の三<font color="lightsalmon">（通算法人に係る行為又は計算の否認）</font>若しくは第百四十七条の二<font color="lightsalmon">（外国法人の恒久的施設帰属所得に係る行為又は計算の否認）</font>、相続税法第六十四条<font color="lightsalmon">（同族会社等の行為又は計算の否認等）</font>又は地価税法<font color="lightsalmon">（平成三年法律第六十九号）</font>第三十二条<font color="lightsalmon">（同族会社等の行為又は計算の否認等）</font>の規定により課された国税　これらの規定により否認された納税者の行為<font color="lightsalmon">（否認された計算の基礎となつた行為を含む。）</font>につき利益を受けたものとされる者


---

[条(全)](国税徴収法＿＿＿＿＿第３６条_.md)  [項](国税徴収法＿＿＿＿＿第３６条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~

[第１号](国税徴収法＿＿＿＿＿第３６条第１項第１号.md)  [第２号](国税徴収法＿＿＿＿＿第３６条第１項第２号.md)  [第３号](国税徴収法＿＿＿＿＿第３６条第１項第３号.md)  

[目次](index国税徴収法＿＿＿＿.md)

