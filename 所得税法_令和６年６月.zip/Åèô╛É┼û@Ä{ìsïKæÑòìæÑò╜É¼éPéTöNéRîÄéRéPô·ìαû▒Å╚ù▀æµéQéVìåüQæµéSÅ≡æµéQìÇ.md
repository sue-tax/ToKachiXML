<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第２項

別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（同表の備考中５を６とし、４を５とし、同表の備考３の次に次のように加える改正規定を除く。）</font>、別表第三<font color="lightsalmon">（二）</font>の改正規定<font color="lightsalmon">（同表の備考中<font color="peru">「第８条の４第１項」</font>を<font color="peru">「第８条の５第１項第５号」</font>に改める部分に限る。）</font>及び別表第三<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表及び同表の備考中<font color="peru">「私募投資信託等」</font>を<font color="peru">「公募投資信託等」</font>に改める部分及び<font color="peru">「公募投資信託等」</font>を<font color="peru">「私募公社債等運用投資信託等」</font>に改める部分に限る。）</font>による新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>及び別表第三<font color="lightsalmon">（四）</font>に定める書式は、平成十六年一月一日以後に新[法第二百二十条](所得税法＿＿＿＿＿第２２０条第１項)の規定により添付する同条に規定する計算書について適用し、同日前に添付した当該計算書については、なお従前の例による。

--- ---

[条(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条_.md)  [項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条第２項_.md)

[前項(全)←](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条第１項_.md)    [→次項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条第３項_.md)

[前項 　 ←](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条第１項.md)    [→次項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号＿第４条第３項.md)



[目次](index所得税法施行規則.md)

