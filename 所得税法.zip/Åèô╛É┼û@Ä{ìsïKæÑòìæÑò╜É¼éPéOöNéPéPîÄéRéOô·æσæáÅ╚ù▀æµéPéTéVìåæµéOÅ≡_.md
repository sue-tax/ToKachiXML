　
所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条

１　この省令は、金融システム改革のための関係法律の整備等に関する法律の施行の日<font color="lightsalmon">（平成十年十二月一日）</font>から施行する。

２　改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>第六条第一項<font color="lightsalmon">（非課税貯蓄申込書の特例が認められる預貯金等の範囲等）</font>の規定は、この省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に購入をする所得税法第十条第一項<font color="lightsalmon">（老人等の少額預金の利子所得等の非課税）</font>に規定する有価証券について適用する。

３　金融システム改革のための関係法律の整備等に関する法律の施行に伴う関係政令の整備等に関する政令<font color="lightsalmon">（平成十年政令第三百六十九号）</font>第二十五条<font color="lightsalmon">（所得税法施行令の一部改正）</font>の規定による改正後の所得税法施行令第五十一条の二第二項<font color="lightsalmon">（公社債等に係る有価証券の保管の委託又は登録）</font>に規定する証券投資信託委託業者の営業所がした同項に規定する公社債等の保管の委託の取次ぎが、当該証券投資信託委託業者の営業所において同条に定めるところにより保管の委託<font color="lightsalmon">（以下この項において<font color="peru">「直前の保管の委託」</font>という。）</font>がされていた当該公社債等に係る有価証券の当該直前の保管の委託の終了後直ちに行われる保管の委託<font color="lightsalmon">（同条第一項第二号に掲げる方法により行われるものに限る。）</font>に係る保管の委託の取次ぎである場合における当該公社債等に係る新規則第十六条<font color="lightsalmon">（公社債等に係る有価証券の保管の委託又は登録等）</font>の規定の適用については、同条第一項第七号中<font color="peru">「その他参考となるべき事項」</font>とあるのは<font color="peru">「その保管の委託の取次ぎが所得税法施行規則の一部を改正する省令（平成十年大蔵省令第百五十七号）附則第三項の保管の委託の取次ぎに該当するものである旨、同項に規定する直前の保管の委託を受けた日、同項に規定する直前の保管の委託の終了の日その他参考となるべき事項」</font>とする。

４　新規則第八十一条の四第九号<font color="lightsalmon">（反復して預貯金等の預入等をすることを約する契約の範囲等）</font>の規定は、施行日以後に支払の確定する所得税法第二百二十四条第一項<font color="lightsalmon">（利子等の受領者の告知）</font>に規定する利子等について適用する。

５　新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（七）</font>、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（二十九）</font>及び別表第八<font color="lightsalmon">（二）</font>に定める書式は、施行日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>、第二百二十五条<font color="lightsalmon">（支払調書及び支払通知書）</font>又は第二百二十八条<font color="lightsalmon">（名義人受領の配当所得等の調書）</font>の規定により添付し又は提出するこれらの規定に規定する計算書、調書及び通知書について適用し、同日前に添付し又は提出したこれらの計算書、調書及び通知書については、なお従前の例による。

６　前項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める計算書、調書又は通知書に新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（七）</font>、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（二十九）</font>及び別表第八<font color="lightsalmon">（二）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第１項_.md) [第２項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第２項_.md) [第３項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第３項_.md) [第４項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第４項_.md) [第５項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第５項_.md) [第６項(全)](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第６項_.md) 

[第１項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第１項.md) [第２項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第２項.md) [第３項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第３項.md) [第４項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第４項.md) [第５項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第５項.md) [第６項 　 ](所得税法施行規則附則平成１０年１１月３０日大蔵省令第１５７号第０条第６項.md) 

[目次](index所得税法施行規則.md)

