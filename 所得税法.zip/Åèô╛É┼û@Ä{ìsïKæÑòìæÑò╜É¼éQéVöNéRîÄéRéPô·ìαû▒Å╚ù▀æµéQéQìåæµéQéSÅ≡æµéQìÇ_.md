<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第２項

別表第五<font color="lightsalmon">（十七）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（十八）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（十九）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（二十）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（二十一）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（二十二）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>、別表第五<font color="lightsalmon">（二十三）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>及び別表第五<font color="lightsalmon">（二十七）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分に限る。）</font>による新規則別表第五<font color="lightsalmon">（十七）</font>から別表第五<font color="lightsalmon">（二十三）</font>まで及び別表第五<font color="lightsalmon">（二十七）</font>に定める書式は、附則第一条第六号に定める日以後に新法第二百二十五条第一項の規定により提出する同項に規定する調書について適用し、同日前に旧法第二百二十五条第一項の規定により提出した同項に規定する調書については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条_.md)  [項](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第２項.md)

[前項(全)←](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第１項_.md)    [→次項(全)](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第３項_.md)

[前項 　 ←](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第１項.md)    [→次項 　 ](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第２４条第３項.md)



[目次](index所得税法施行規則.md)

