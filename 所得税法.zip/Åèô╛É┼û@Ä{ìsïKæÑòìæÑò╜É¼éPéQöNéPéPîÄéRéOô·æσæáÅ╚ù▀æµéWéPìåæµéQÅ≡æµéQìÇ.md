<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項

新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（三十）</font>、別表第七、別表第八<font color="lightsalmon">（一）</font>及び別表第八<font color="lightsalmon">（二）</font>に定める書式は、施行日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>、第二百二十四条第二項<font color="lightsalmon">（利子、配当、償還金等の受領者の告知）</font>、第二百二十五条<font color="lightsalmon">（支払調書及び支払通知書）</font>、第二百二十七条<font color="lightsalmon">（信託に関する計算書）</font>又は第二百二十八条第一項<font color="lightsalmon">（名義人受領の配当所得等の調書）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、告知書、調書及び通知書について適用し、施行日前に添付し、提出し、又は交付したこれらの計算書、告知書、調書及び通知書については、なお従前の例による。

--- ---

[条(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条_.md)  [項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項_.md)

[前項(全)←](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第１項_.md)    [→次項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項_.md)

[前項 　 ←](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第１項.md)    [→次項 　 ](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項.md)



[目次](index所得税法施行規則.md)

