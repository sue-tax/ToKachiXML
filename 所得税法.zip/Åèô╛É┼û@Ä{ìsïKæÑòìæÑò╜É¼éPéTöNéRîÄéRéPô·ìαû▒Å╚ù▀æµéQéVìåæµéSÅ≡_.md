（書式に関する経過措置）
所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条

１　別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（同表の備考中５を６とし、４を５とし、同表の備考３の次に次のように加える改正規定に限る。）</font>、別表第三<font color="lightsalmon">（二）</font>の改正規定<font color="lightsalmon">（同表の備考中<font color="peru">「第８条の４第１項」</font>を<font color="peru">「第８条の５第１項第５号」</font>に改める部分を除く。）</font>及び別表第三<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表及び同表の備考中<font color="peru">「私募投資信託等」</font>を<font color="peru">「公募投資信託等」</font>に改める部分及び<font color="peru">「公募投資信託等」</font>を<font color="peru">「私募公社債等運用投資信託等」</font>に改める部分を除く。）</font>による新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>及び別表第三<font color="lightsalmon">（四）</font>に定める書式は、この省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に新法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>の規定により添付する同条に規定する計算書について適用し、施行日前に添付した当該計算書については、なお従前の例による。

２　別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（同表の備考中５を６とし、４を５とし、同表の備考３の次に次のように加える改正規定を除く。）</font>、別表第三<font color="lightsalmon">（二）</font>の改正規定<font color="lightsalmon">（同表の備考中<font color="peru">「第８条の４第１項」</font>を<font color="peru">「第８条の５第１項第５号」</font>に改める部分に限る。）</font>及び別表第三<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表及び同表の備考中<font color="peru">「私募投資信託等」</font>を<font color="peru">「公募投資信託等」</font>に改める部分及び<font color="peru">「公募投資信託等」</font>を<font color="peru">「私募公社債等運用投資信託等」</font>に改める部分に限る。）</font>による新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>及び別表第三<font color="lightsalmon">（四）</font>に定める書式は、平成十六年一月一日以後に新法第二百二十条の規定により添付する同条に規定する計算書について適用し、同日前に添付した当該計算書については、なお従前の例による。

３　新規則別表第三<font color="lightsalmon">（五）</font>、別表第五<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（八）</font>及び別表第六<font color="lightsalmon">（一）</font>に定める書式は、施行日以後に新法第二百二十条、第二百二十五条第一項<font color="lightsalmon">（支払調書）</font>及び第二百二十六条第一項<font color="lightsalmon">（源泉徴収票）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、調書及び源泉徴収票について適用し、施行日前に添付し、提出し、又は交付したこれらの計算書、調書及び源泉徴収票については、なお従前の例による。

４　新規則別表第五<font color="lightsalmon">（二十七）</font>及び別表第八<font color="lightsalmon">（二）</font>に定める書式は、平成十六年一月一日以後に新法第二百二十条、第二百二十五条第一項及び第二百二十八条<font color="lightsalmon">（名義人受領の配当所得等の調書）</font>の規定により添付し、又は提出するこれらの規定に規定する計算書及び調書について適用し、施行日前に添付し、又は提出したこれらの計算書及び調書については、なお従前の例による。

５　前各項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める計算書、調書又は源泉徴収票に、新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第三<font color="lightsalmon">（五）</font>、別表第五<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（八）</font>、別表第五<font color="lightsalmon">（二十七）</font>、別表第六<font color="lightsalmon">（一）</font>及び別表第八<font color="lightsalmon">（二）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[前条(全)←](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第３条_.md)  ~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第１項_.md) [第２項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第２項_.md) [第３項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第３項_.md) [第４項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第４項_.md) [第５項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第５項_.md) 

[第１項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第１項.md) [第２項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第２項.md) [第３項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第３項.md) [第４項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第４項.md) [第５項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第４条第５項.md) 

[目次](index所得税法施行規則.md)

