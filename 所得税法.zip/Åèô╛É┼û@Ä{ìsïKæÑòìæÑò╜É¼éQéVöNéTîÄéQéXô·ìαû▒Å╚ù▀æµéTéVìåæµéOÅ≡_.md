　
所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条

１　この省令は、公布の日から施行する。ただし、第一条中租税特別措置法施行規則別表第二<font color="lightsalmon">（二）</font>の表の備考２<font color="lightsalmon">（５）</font>及び別表第二<font color="lightsalmon">（六）</font>の表の備考２<font color="lightsalmon">（７）</font>の改正規定並びに第二条中所得税法施行規則第十三条第一項第七号の改正規定並びに同令別表第二<font color="lightsalmon">（二）</font>の表の備考２<font color="lightsalmon">（６）</font>及び別表第二<font color="lightsalmon">（六）</font>の表の備考２<font color="lightsalmon">（８）</font>の改正規定は、行政手続における特定の個人を識別するための番号の利用等に関する法律の施行に伴う関係法律の整備等に関する法律<font color="lightsalmon">（平成二十五年法律第二十八号）</font>附則第三号に掲げる規定の施行の日<font color="lightsalmon">（平成二十八年一月一日）</font>から施行する。

２　第二条の規定による改正後の所得税法施行規則<font color="lightsalmon">（以下「新規則」という。）</font>別表第三<font color="lightsalmon">（二）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（七）</font>及び別表第五<font color="lightsalmon">（二十九）</font>に定める書式は、この省令の施行の日以後に所得税法第二百二十条又は第二百二十五条第一項の規定により添付し、又は提出するこれらの規定に規定する計算書又は調書について適用し、同日前に添付し、又は提出したこれらの計算書又は調書については、なお従前の例による。

３　前項に規定する書式は、当分の間、第二条の規定による改正前の所得税法施行規則の相当の規定に定める計算書又は調書に、新規則別表第三<font color="lightsalmon">（二）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（七）</font>及び別表第五<font color="lightsalmon">（二十九）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第１項_.md) [第２項(全)](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第２項_.md) [第３項(全)](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第３項_.md) 

[第１項 　 ](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第１項.md) [第２項 　 ](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第２項.md) [第３項 　 ](所得税法施行規則附則平成２７年５月２９日財務省令第５７号第０条第３項.md) 

[目次](index所得税法施行規則.md)

