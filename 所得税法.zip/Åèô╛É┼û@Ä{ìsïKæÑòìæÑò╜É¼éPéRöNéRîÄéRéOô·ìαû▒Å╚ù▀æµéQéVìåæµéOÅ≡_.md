　
所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条

１　この省令は、平成十三年三月三十一日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第三条の六第二項第十五号の改正規定　予防接種法の一部を改正する法律<font color="lightsalmon">（平成十三年法律第百十六号）</font>の施行の日

二　第三十五条の二から第三十六条の二までの改正規定、第九十三条第一項の改正規定、別表第五<font color="lightsalmon">（三十）</font>の表の備考２<font color="lightsalmon">（２）</font>の改正規定<font color="lightsalmon">（<font color="peru">「第３７条の１３の２第１項」</font>を<font color="peru">「第３７条の１４第１項」</font>に改める部分に限る。）</font>、同表の備考２<font color="lightsalmon">（５）</font>の改正規定、同表の備考２<font color="lightsalmon">（７）</font>の改正規定及び別表第六<font color="lightsalmon">（一）</font>の改正規定　平成十三年四月一日

２　改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>第八十三条第一項及び第二項<font color="lightsalmon">（配当等の支払調書）</font>並びに第九十条の三<font color="lightsalmon">（交付金銭等の支払調書）</font>の規定並びに新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>及び別表第五<font color="lightsalmon">（七）</font>から別表第五<font color="lightsalmon">（二十八）</font>までに定める書式は、平成十三年四月一日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>又は第二百二十五条<font color="lightsalmon">（支払調書及び支払通知書）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、調書及び通知書について適用し、同日前に添付し、提出し、又は交付したこれらの計算書、調書及び通知書については、なお従前の例による。

３　前項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める計算書、調書又は通知書に新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>及び別表第五<font color="lightsalmon">（七）</font>から別表第五<font color="lightsalmon">（二十八）</font>までに準じて、記載したものをもってこれに代えることができる。

--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第１項_.md) [第２項(全)](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第２項_.md) [第３項(全)](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第３項_.md) 

[第１項 　 ](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第１項.md) [第２項 　 ](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第２項.md) [第３項 　 ](所得税法施行規則附則平成１３年３月３０日財務省令第２７号第０条第３項.md) 

[目次](index所得税法施行規則.md)

