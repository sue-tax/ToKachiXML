<font color="lightsalmon">（特別修繕引当金に関する経過措置）</font>
所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号第２条第１項

所得税法施行令の一部を改正する政令<font color="lightsalmon">（平成十年政令第百四号。以下この条において<font color="peru">「改正令」</font>という。）</font>附則第十二条第一項<font color="lightsalmon">（特別修繕引当金に関する経過措置）</font>の規定によりなおその効力を有するものとされる改正令による改正前の所得税法施行令第百六十条<font color="lightsalmon">（特別修繕引当金の対象資産及び特別の修繕の範囲）</font>及び第百六十一条<font color="lightsalmon">（特別修繕引当金勘定への繰入限度額）</font>の規定の適用については、改正前の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「旧規則」</font>という。）</font>第三十六条の二<font color="lightsalmon">（特別修繕引当金の対象資産及び特別の修繕の範囲）</font>及び第三十六条の三<font color="lightsalmon">（特別修繕引当金勘定への繰入限度額の計算等）</font>の規定並びに附則第四条の規定による改正前の所得税法施行規則の一部を改正する省令<font color="lightsalmon">（平成八年大蔵省令第十九号）</font>附則第二条の規定は、なおその効力を有する。この場合において、旧規則第三十六条の二及び第三十六条の三中<font color="peru">「大蔵省令」</font>とあるのは、<font color="peru">「財務省令」</font>とする。

--- ---

[条(全)](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号第２条_.md)  [項(全)](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号第２条第１項_.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index所得税法施行規則.md)

