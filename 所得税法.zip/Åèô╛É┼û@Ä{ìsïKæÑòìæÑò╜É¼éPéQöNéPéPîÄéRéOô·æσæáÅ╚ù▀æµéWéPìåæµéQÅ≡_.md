（書式に関する経過措置）
所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条

１　改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（六）</font>までに定める書式は、この省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に提出する特定目的会社による特定資産の流動化に関する法律等の一部を改正する法律<font color="lightsalmon">（平成十二年法律第九十七号。以下<font color="peru">「改正法」</font>という。）</font>第三条の規定による改正後の所得税法第十条第一項、第三項若しくは第四項<font color="lightsalmon">（老人等の少額預金の利子所得等の非課税）</font>又は特定目的会社による特定資産の流動化に関する法律等の一部を改正する法律の施行に伴う関係政令の整備等に関する政令<font color="lightsalmon">（平成十二年政令第四百八十二号。以下<font color="peru">「改正令」</font>という。）</font>第一条の規定による改正後の所得税法施行令第四十三条第一項から第三項まで<font color="lightsalmon">（非課税貯蓄に関する異動申告書）</font>、第四十五条第一項<font color="lightsalmon">（非課税貯蓄廃止申告書）</font>若しくは第四十七条第一項<font color="lightsalmon">（非課税貯蓄相続申込書）</font>の規定による申告書及び申込書について適用し、施行日前に提出した改正法第三条の規定による改正前の所得税法第十条第一項、第三項若しくは第四項又は改正令第一条の規定による改正前の所得税法施行令第四十三条第一項から第三項まで、第四十五条第一項若しくは第四十七条第一項の規定による申告書及び申込書については、なお従前の例による。

２　新規則別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（三十）</font>、別表第七、別表第八<font color="lightsalmon">（一）</font>及び別表第八<font color="lightsalmon">（二）</font>に定める書式は、施行日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>、第二百二十四条第二項<font color="lightsalmon">（利子、配当、償還金等の受領者の告知）</font>、第二百二十五条<font color="lightsalmon">（支払調書及び支払通知書）</font>、第二百二十七条<font color="lightsalmon">（信託に関する計算書）</font>又は第二百二十八条第一項<font color="lightsalmon">（名義人受領の配当所得等の調書）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、告知書、調書及び通知書について適用し、施行日前に添付し、提出し、又は交付したこれらの計算書、告知書、調書及び通知書については、なお従前の例による。

３　前二項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める申告書、申込書、計算書、告知書、調書又は通知書に新規則別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（六）</font>まで、別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（三十）</font>、別表第七、別表第八<font color="lightsalmon">（一）</font>及び別表第八<font color="lightsalmon">（二）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[前条(全)←](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第１条_.md)  ~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第１項_.md) [第２項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項_.md) [第３項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項_.md) 

[第１項 　 ](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第１項.md) [第２項 　 ](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項.md) [第３項 　 ](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項.md) 

[目次](index所得税法施行規則.md)

