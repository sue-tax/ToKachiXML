<font color="lightsalmon">（老人等に該当する旨を証する書類の範囲に関する経過措置）</font>
所得税法施行規則附則平成１６年３月３１日財務省令第２６号第２条第１項

改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>第三条の六第一項<font color="lightsalmon">（老人等に該当する旨を証する書類の範囲）</font>の規定は、この省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に所得税法等の一部を改正する法律<font color="lightsalmon">（平成十六年法律第十四号。以下<font color="peru">「改正法」</font>という。）</font>第一条<font color="lightsalmon">（所得税法の一部改正）</font>の規定による改正後の所得税法<font color="lightsalmon">（以下<font color="peru">「新法」</font>という。）</font>第九条の二第二項<font color="lightsalmon">（老人等の郵便貯金の利子所得の非課税）</font>又は所得税法施行令の一部を改正する政令<font color="lightsalmon">（平成十六年政令第百号。以下<font color="peru">「改正令」</font>という。）</font>による改正後の所得税法施行令<font color="lightsalmon">（以下<font color="peru">「新令」</font>という。）</font>第三十条の十二第一項<font color="lightsalmon">（非課税郵便貯金に関する異動届出書）</font>若しくは第三十条の十四第二項<font color="lightsalmon">（非課税郵便貯金相続申込書）</font>の規定による告知の際に提示するこれらの規定に規定する書類について適用し、施行日前に改正法第一条の規定による改正前の所得税法<font color="lightsalmon">（以下<font color="peru">「旧法」</font>という。）</font>第九条の二第二項<font color="lightsalmon">（老人等の郵便貯金の利子所得の非課税）</font>又は改正令による改正前の所得税法施行令<font color="lightsalmon">（以下<font color="peru">「旧令」</font>という。）</font>第三十条の十二第一項<font color="lightsalmon">（非課税郵便貯金に関する異動届出書）</font>若しくは第三十条の十四第二項<font color="lightsalmon">（非課税郵便貯金相続申込書）</font>の規定による告知の際に提示したこれらの規定に規定する書類については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成１６年３月３１日財務省令第２６号第２条_.md)  [項](所得税法施行規則附則平成１６年３月３１日財務省令第２６号第２条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index所得税法施行規則.md)

