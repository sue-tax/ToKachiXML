（書式に関する経過措置）
所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条

１　新規則別表第一<font color="lightsalmon">（一）</font>、別表第一<font color="lightsalmon">（三）</font>、別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（三）</font>まで及び別表第二<font color="lightsalmon">（六）</font>に定める書式は、平成十八年一月一日以後に提出する新規則第三条の十三<font color="lightsalmon">（非課税郵便貯金申込書等の書式）</font>及び第十五条<font color="lightsalmon">（非課税貯蓄申告書等の書式）</font>に規定する申込書又は申告書について適用し、同日前に提出したこれらの申込書又は申告書については、なお従前の例による。

２　別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（<font color="peru">「老人等」</font>を<font color="peru">「障害者等」</font>に改める部分を除く。）</font>による改正後の所得税法施行規則別表第三<font color="lightsalmon">（一）</font>に定める書式は、この省令の施行の日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>の規定により添付する同条に規定する計算書について適用し、同日前に添付した当該計算書については、なお従前の例による。

３　別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（<font color="peru">「老人等」</font>を<font color="peru">「障害者等」</font>に改める部分に限る。）</font>による改正後の所得税法施行規則別表第三<font color="lightsalmon">（一）</font>に定める書式は、平成十八年一月一日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>の規定により添付する同条に規定する計算書について適用し、同日前に添付した当該計算書については、なお従前の例による。

４　前三項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める申込書、申告書又は計算書に、新規則別表第一<font color="lightsalmon">（一）</font>、別表第一<font color="lightsalmon">（三）</font>、別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（三）</font>まで、別表第二<font color="lightsalmon">（六）</font>及び別表第三<font color="lightsalmon">（一）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[前条(全)←](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第３条_.md)  ~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第１項_.md) [第２項(全)](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第２項_.md) [第３項(全)](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第３項_.md) [第４項(全)](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第４項_.md) 

[第１項 　 ](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第１項.md) [第２項 　 ](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第２項.md) [第３項 　 ](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第３項.md) [第４項 　 ](所得税法施行規則附則平成１４年３月３１日財務省令第２５号第４条第４項.md) 

[目次](index所得税法施行規則.md)

