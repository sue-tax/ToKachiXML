（施行期日）
所得税法施行規則附則平成１５年３月３１日財務省令第２７号第１条

１　この省令は、平成十五年四月一日から施行する。ただし、目次の改正規定<font color="lightsalmon">（<font color="peru">「公益信託」</font>を<font color="peru">「公益信託等」</font>に改める部分を除く。）</font>、第五条の改正規定、第二編第一章第三節第一款の次に一款を加える改正規定、第四十条第二号の改正規定、第五十三条第一項第一号の改正規定、第八十一条の五の改正規定、第八十一条の九の改正規定、第八十一条の十九の改正規定、第八十一条の二十三の改正規定、第九十二条第二項の改正規定、別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（同表の備考中５を６とし、４を５とし、同表の備考３の次に次のように加える改正規定を除く。）</font>、別表第三<font color="lightsalmon">（二）</font>の改正規定<font color="lightsalmon">（同表の備考中<font color="peru">「第８条の４第１項」</font>を<font color="peru">「第８条の５第１項第５号」</font>に改める部分に限る。）</font>、別表第三<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表及び同表の備考中<font color="peru">「私募投資信託等」</font>を<font color="peru">「公募投資信託等」</font>に改める部分及び<font color="peru">「公募投資信託等」</font>を<font color="peru">「私募公社債等運用投資信託等」</font>に改める部分に限る。）</font>、別表第五<font color="lightsalmon">（二十七）</font>の改正規定、別表第八<font color="lightsalmon">（二）</font>の改正規定並びに附則第三条、第四条第二項及び第四項並びに第五条の規定は、平成十六年一月一日から施行する。

--- ---

~~前条(全)←~~　  [→次条(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第２条_.md)

[第１項(全)](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第１条第１項_.md) 

[第１項 　 ](所得税法施行規則附則平成１５年３月３１日財務省令第２７号第１条第１項.md) 

[目次](index所得税法施行規則.md)

