<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項

前二項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める申告書、申込書、計算書、告知書、調書又は通知書に新規則別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（六）</font>まで、別表第三<font color="lightsalmon">（一）</font>、別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（三十）</font>、別表第七、別表第八<font color="lightsalmon">（一）</font>及び別表第八<font color="lightsalmon">（二）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[条(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条_.md)  [項(全)](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第３項_.md)

[前項(全)←](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項_.md)  ~~→次項(全)~~

[前項 　 ←](所得税法施行規則附則平成１２年１１月３０日大蔵省令第８１号第２条第２項.md)  ~~→次項~~



[目次](index所得税法施行規則.md)

