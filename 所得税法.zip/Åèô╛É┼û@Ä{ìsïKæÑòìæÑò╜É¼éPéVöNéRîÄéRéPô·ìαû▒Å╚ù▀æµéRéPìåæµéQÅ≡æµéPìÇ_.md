<font color="lightsalmon">（個人年金保険契約等の対象となる共済に係る契約の要件の細目に関する経過措置）</font>
所得税法施行規則附則平成１７年３月３１日財務省令第３１号第２条第１項

改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>第四十条の六<font color="lightsalmon">（個人年金保険契約等の対象となる共済に係る契約の要件の細目）</font>の規定は、個人がこの省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に支払うべき所得税法等の一部を改正する法律<font color="lightsalmon">（平成十七年法律第二十一号）</font>第一条<font color="lightsalmon">（所得税法の一部改正）</font>の規定による改正後の所得税法<font color="lightsalmon">（以下<font color="peru">「新法」</font>という。）</font>第七十六条第二項<font color="lightsalmon">（生命保険料控除）</font>に規定する掛金に係る同条第四項に規定する個人年金保険契約等について適用し、個人が施行日前に支払うべき当該掛金に係る当該個人年金保険契約等については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成１７年３月３１日財務省令第３１号第２条_.md)  [項](所得税法施行規則附則平成１７年３月３１日財務省令第３１号第２条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index所得税法施行規則.md)

