　
所得税法施行規則附則平成１年３月３１日大蔵省令第３９号第０条第３項

[前項](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第２項)に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める申込書、届出書、申告書、計算書、告知書、調書、通知書又は源泉徴収票に新規則別表第一<font color="lightsalmon">（一）</font>から別表第一<font color="lightsalmon">（三）</font>まで、別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（六）</font>まで、別表第三<font color="lightsalmon">（一）</font>から別表第三<font color="lightsalmon">（六）</font>まで、別表第四<font color="lightsalmon">（一）</font>から別表第四<font color="lightsalmon">（四）</font>まで、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（二十七）</font>まで、別表第六<font color="lightsalmon">（一）</font>から別表第六<font color="lightsalmon">（三）</font>まで及び別表第八<font color="lightsalmon">（一）</font>から別表第八<font color="lightsalmon">（三）</font>までに準じて、記載したものをもってこれに代えることができる。

--- ---

[条(全)](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条_.md)  [項(全)](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第３項_.md)

[前項(全)←](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第２項_.md)  ~~→次項(全)~~

[前項 　 ←](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第２項.md)  ~~→次項~~



[目次](index所得税法施行規則.md)

