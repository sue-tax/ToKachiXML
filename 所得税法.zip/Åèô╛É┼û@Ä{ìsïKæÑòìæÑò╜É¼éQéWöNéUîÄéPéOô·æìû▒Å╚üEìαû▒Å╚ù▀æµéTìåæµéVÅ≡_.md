（所得税法施行規則の一部改正に伴う経過措置）　
所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条

１　前条の規定による改正後の所得税法施行規則<font color="lightsalmon">（以下「新所得税法施行規則」という。）</font>別表第三<font color="lightsalmon">（三）</font>及び別表第三<font color="lightsalmon">（四）</font>に定める書式は、適用開始日以後に所得税法第二百二十条の規定により添付する同条に規定する計算書について適用し、適用開始日前に添付した当該計算書については、なお従前の例による。

２　新所得税法施行規則別表第四<font color="lightsalmon">（一）</font>から別表第四<font color="lightsalmon">（三）</font>までに定める書式は、適用開始日以後に所得税法第二百二十四条第二項の規定により提出する同項に規定する告知書について適用し、適用開始日前に提出した当該告知書については、なお従前の例による。

３　新所得税法施行規則別表第五<font color="lightsalmon">（一）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（五）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（十八）</font>から別表第五<font color="lightsalmon">（二十三）</font>まで及び別表第五<font color="lightsalmon">（二十八）</font>に定める書式は、適用開始日以後に所得税法第二百二十五条第一項の規定により提出する同項に規定する調書について適用し、適用開始日前に提出した当該調書については、なお従前の例による。

４　新所得税法施行規則別表第八<font color="lightsalmon">（三）</font>に定める書式は、適用開始日以後に所得税法第二百二十八条第二項の規定により提出する同項に規定する調書について適用し、適用開始日前に提出した当該調書については、なお従前の例による。

５　前各項に規定する書式は、当分の間、前条の規定による改正前の所得税法施行規則の相当の規定に定める計算書、告知書又は調書に、新所得税法施行規則別表第三<font color="lightsalmon">（三）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>から別表第四<font color="lightsalmon">（三）</font>まで、別表第五<font color="lightsalmon">（一）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（五）</font>から別表第五<font color="lightsalmon">（七）</font>まで、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十）</font>、別表第五<font color="lightsalmon">（十八）</font>から別表第五<font color="lightsalmon">（二十三）</font>まで、別表第五<font color="lightsalmon">（二十八）</font>及び別表第八<font color="lightsalmon">（三）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[前条(全)←](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第１条_.md)  ~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第１項_.md) [第２項(全)](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第２項_.md) [第３項(全)](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第３項_.md) [第４項(全)](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第４項_.md) [第５項(全)](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第５項_.md) 

[第１項 　 ](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第１項.md) [第２項 　 ](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第２項.md) [第３項 　 ](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第３項.md) [第４項 　 ](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第４項.md) [第５項 　 ](所得税法施行規則附則平成２８年６月１０日総務省・財務省令第５号第７条第５項.md) 

[目次](index所得税法施行規則.md)

