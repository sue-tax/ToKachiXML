<font color="lightsalmon">（貯蓄取扱機関等の営業所の長に提示する書類の範囲等に関する経過措置）</font>
所得税法施行規則附則平成２７年３月３１日財務省令第２２号第１０条第１項

新規則第八十一条の六第二項<font color="lightsalmon">（第九号に係る部分に限る。）</font><font color="lightsalmon">（貯蓄取扱機関等の営業所の長に提示する書類の範囲）</font><font color="lightsalmon">（新規則第八十一条の二十第一項<font color="darkkhaki">（株式等の譲渡の対価の支払者に提示する書類の範囲）</font>、第八十一条の二十五第一項<font color="darkkhaki">（交付金銭等の交付者に提示する書類の範囲）</font>、第八十一条の二十九第一項<font color="darkkhaki">（株式等証券投資信託等の償還金等の交付者に提示する書類の範囲）</font>、第八十一条の三十三第一項<font color="darkkhaki">（信託受益権の譲渡の対価の支払者に提示する書類の範囲）</font>、第八十一条の三十六第二項<font color="darkkhaki">（先物取引の差金等決済をする者の告知）</font>及び第八十一条の三十八<font color="darkkhaki">（金地金等の譲渡の対価の支払者に提示する書類の範囲）</font>において準用する場合を含む。）</font>の規定は、附則第一条第六号<font color="lightsalmon">（施行期日）</font>に定める日以後に新法第二百二十四条第一項<font color="lightsalmon">（利子、配当、償還金等の受領者の告知）</font>、第二百二十四条の三第一項<font color="lightsalmon">（株式等の譲渡の対価の受領者の告知）</font><font color="lightsalmon">（同条第三項又は第四項において準用する場合を含む。）</font>、第二百二十四条の四<font color="lightsalmon">（信託受益権の譲渡の対価の受領者の告知）</font>、第二百二十四条の五第一項<font color="lightsalmon">（先物取引の差金等決済をする者の告知）</font>若しくは第二百二十四条の六<font color="lightsalmon">（金地金等の譲渡の対価の受領者の告知）</font>の規定による告知又は新法第二百二十四条第二項若しくは第四項若しくは第二百二十四条の二<font color="lightsalmon">（譲渡性預金の譲渡等に関する告知）</font>の規定による告知書の提出の際に提示するこれらの規定に規定する書類について適用する。

--- ---


[条(全)](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第１０条_.md)  [項](所得税法施行規則附則平成２７年３月３１日財務省令第２２号第１０条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index所得税法施行規則.md)

