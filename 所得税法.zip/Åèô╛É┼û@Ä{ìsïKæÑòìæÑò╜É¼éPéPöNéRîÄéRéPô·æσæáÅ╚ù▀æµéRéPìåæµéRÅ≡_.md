（書式に関する経過措置）
所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条

１　新規則別表第二<font color="lightsalmon">（四）</font>に定める書式は、施行日以後に提出する所得税法施行令の一部を改正する政令<font color="lightsalmon">（平成十一年政令第百十八号）</font>による改正後の所得税法施行令第四十三条第三項<font color="lightsalmon">（非課税貯蓄に関する異動申告書）</font>の規定による申告書について適用し、施行日前に提出をした所得税法施行令の一部を改正する政令による改正前の所得税法施行令第四十三条第三項の規定による申告書については、なお従前の例による。

２　新規則別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（一）</font>、別表第六<font color="lightsalmon">（一）</font>及び別表第六<font color="lightsalmon">（三）</font>に定める書式は、施行日以後に所得税法第二百二十条<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>、第二百二十四条第二項<font color="lightsalmon">（利子の受領者の告知）</font>、第二百二十四条の二<font color="lightsalmon">（譲渡性預金の譲渡等に関する告知）</font>、第二百二十五条第一項<font color="lightsalmon">（支払調書）</font>又は第二百二十六条第一項若しくは第三項<font color="lightsalmon">（源泉徴収票）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、告知書、調書及び源泉徴収票について適用し、施行日前に添付し、提出し、又は交付したこれらの計算書、告知書、調書及び源泉徴収票については、なお従前の例による。

３　前二項に規定する書式は、当分の間、改正前の所得税法施行規則の相当の規定に定める申告書、計算書、告知書、調書又は源泉徴収票に新規則別表第二<font color="lightsalmon">（四）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第四<font color="lightsalmon">（一）</font>、別表第四<font color="lightsalmon">（四）</font>、別表第五<font color="lightsalmon">（一）</font>、別表第六<font color="lightsalmon">（一）</font>及び別表第六<font color="lightsalmon">（三）</font>に準じて、記載したものをもってこれに代えることができる。

--- ---

[前条(全)←](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第２条_.md)  ~~→次条(全)~~

[第１項(全)](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第１項_.md) [第２項(全)](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第２項_.md) [第３項(全)](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第３項_.md) 

[第１項 　 ](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第１項.md) [第２項 　 ](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第２項.md) [第３項 　 ](所得税法施行規則附則平成１１年３月３１日大蔵省令第３１号第３条第３項.md) 

[目次](index所得税法施行規則.md)

