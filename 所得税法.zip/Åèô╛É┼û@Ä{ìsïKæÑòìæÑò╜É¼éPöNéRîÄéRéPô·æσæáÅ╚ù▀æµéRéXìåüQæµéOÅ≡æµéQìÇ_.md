　
所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第２項

改正後の所得税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>[第九十三条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第９３条第１項)<font color="lightsalmon">（給与等の源泉徴収票）</font>の規定並びに新規則別表第一<font color="lightsalmon">（一）</font>から別表第一<font color="lightsalmon">（三）</font>まで、別表第二<font color="lightsalmon">（一）</font>から別表第二<font color="lightsalmon">（六）</font>まで、別表第三<font color="lightsalmon">（一）</font>から別表第三<font color="lightsalmon">（六）</font>まで、別表第四<font color="lightsalmon">（一）</font>から別表第四<font color="lightsalmon">（四）</font>まで、別表第五<font color="lightsalmon">（一）</font>から別表第五<font color="lightsalmon">（二十七）</font>まで、別表第六<font color="lightsalmon">（一）</font>から別表第六<font color="lightsalmon">（三）</font>まで及び別表第八<font color="lightsalmon">（一）</font>から別表第八<font color="lightsalmon">（三）</font>までに定める書式は、この省令の施行の日<font color="lightsalmon">（以下<font color="peru">「施行日」</font>という。）</font>以後に提出し、添付し、又は交付する新規則[第三条の十三](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第３条の１３第１項)<font color="lightsalmon">（非課税郵便貯金申込書等の書式）</font>、[第十五条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第１５条第１項)<font color="lightsalmon">（非課税貯蓄申告書等の書式）</font>、[第八十条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第８０条第１項)<font color="lightsalmon">（計算書の書式）</font>、[第八十一条の八](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第８１条の８第１項)<font color="lightsalmon">（無記名公社債の利子等の受領者の告知書の記載事項等）</font>、[第八十一条の十二](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第８１条の１２第１項)<font color="lightsalmon">（譲渡性預金の譲渡等に関する告知書）</font>、[第九十一条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第９１条第１項)<font color="lightsalmon">（支払調書の書式）</font>、[第九十二条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第９２条第１項)<font color="lightsalmon">（オープン型の証券投資信託の収益の分配等の通知書）</font>、[第九十五条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第９５条第１項)<font color="lightsalmon">（源泉徴収票の書式）</font>及び[第九十七条](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第９７条第１項)<font color="lightsalmon">（名義人受領の配当所得等の調書）</font>に規定する申込書、届出書、申告書、計算書、告知書、調書、通知書及び源泉徴収票について適用し、施行日前に提出し、添付し、又は交付したこれらの申込書、届出書、申告書、計算書、告知書、調書、通知書及び源泉徴収票については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条_.md)  [項](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第２項.md)

[前項(全)←](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第１項_.md)    [→次項(全)](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第３項_.md)

[前項 　 ←](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第１項.md)    [→次項 　 ](所得税法施行規則附則平成１年３月３１日大蔵省令第３９号＿第０条第３項.md)



[目次](index所得税法施行規則.md)

