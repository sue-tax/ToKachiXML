<font color="lightsalmon">（届出書の記載事項等に関する経過措置）</font>
消費税法施行規則附則平成２８年３月３１日財務省令第２０号第２条第１項

第一条の規定による改正後の消費税法施行規則<font color="lightsalmon">（以下<font color="peru">「新規則」</font>という。）</font>第二十六条第一項<font color="lightsalmon">（第三号に係る部分に限る。）</font>の規定は、平成二十八年四月一日以後に所得税法等の一部を改正する法律<font color="lightsalmon">（平成二十八年法律第十五号。以下<font color="peru">「改正法」</font>という。）</font>第五条の規定による改正後の消費税法<font color="lightsalmon">（附則第四条第二項において<font color="peru">「新法」</font>という。）</font>第五十七条第一項<font color="lightsalmon">（第二号の二に係る部分に限る。）</font>の規定により提出する届出書について適用する。

--- ---

[条(全)](消費税法施行規則附則平成２８年３月３１日財務省令第２０号第２条_.md)  [項(全)](消費税法施行規則附則平成２８年３月３１日財務省令第２０号第２条第１項_.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index消費税法施行規則.md)

