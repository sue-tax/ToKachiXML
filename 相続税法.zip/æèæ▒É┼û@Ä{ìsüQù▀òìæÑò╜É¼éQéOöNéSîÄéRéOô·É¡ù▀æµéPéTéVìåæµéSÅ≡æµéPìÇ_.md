<font color="lightsalmon">（物納劣後財産に関する経過措置）</font>
相続税法施行令附則平成２０年４月３０日政令第１５７号第４条第１項

平成二十年四月一日以後に独立行政法人森林総合研究所法<font color="lightsalmon">（平成十一年法律第百九十八号）</font>附則第九条第一項に規定する業務のうち独立行政法人緑資源機構法を廃止する法律<font color="lightsalmon">（平成二十年法律第八号）</font>による廃止前の独立行政法人緑資源機構法<font color="lightsalmon">（平成十四年法律第百三十号）</font>第十一条第一項第七号イの事業又は独立行政法人森林総合研究所法附則第十一条第一項に規定する業務のうち森林開発公団法の一部を改正する法律<font color="lightsalmon">（平成十一年法律第七十号）</font>附則第八条の規定による廃止前の農用地整備公団法<font color="lightsalmon">（昭和四十九年法律第四十三号）</font>第十九条第一項第一号イの事業が施行された場合における新令第十九条の規定の適用については、同条第三号ニ中「土地改良事業」とあるのは、「土地改良事業又は独立行政法人森林総合研究所法<font color="lightsalmon">（平成十一年法律第百九十八号）</font>附則第九条第一項<font color="lightsalmon">（業務の特例）</font>に規定する業務のうち独立行政法人緑資源機構法を廃止する法律<font color="lightsalmon">（平成二十年法律第八号）</font>による廃止前の独立行政法人緑資源機構法<font color="lightsalmon">（平成十四年法律第百三十号）</font>第十一条第一項第七号イ<font color="lightsalmon">（業務の範囲）</font>の事業若しくは独立行政法人森林総合研究所法附則第十一条第一項<font color="lightsalmon">（業務の特例）</font>に規定する業務のうち森林開発公団法の一部を改正する法律<font color="lightsalmon">（平成十一年法律第七十号）</font>附則第八条<font color="lightsalmon">（農用地整備公団法の廃止）</font>の規定による廃止前の農用地整備公団法<font color="lightsalmon">（昭和四十九年法律第四十三号）</font>第十九条第一項第一号イ<font color="lightsalmon">（業務の範囲）</font>の事業」とする。

--- ---


[条(全)](相続税法施行＿令附則平成２０年４月３０日政令第１５７号第４条_.md)  [項](相続税法施行＿令附則平成２０年４月３０日政令第１５７号第４条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index相続税法施行＿令.md)

