<font color="lightsalmon">（施行期日）</font>
[相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条第１項](相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条第１項)第１号

第三十条<font color="lightsalmon">（見出しを含む。）</font>の改正規定<font color="lightsalmon">（同条第三項第五号イ<font color="darkkhaki">（３）</font>を同号イ<font color="darkkhaki">（４）</font>とし、同号イ<font color="darkkhaki">（２）</font>の次に次のように加える部分、同号ロ<font color="darkkhaki">（２）</font>に係る部分及び同号ハ<font color="darkkhaki">（５）</font>を同号ハ<font color="darkkhaki">（６）</font>とし、同号ハ<font color="darkkhaki">（２）</font>から<font color="darkkhaki">（４）</font>までを同号ハ<font color="darkkhaki">（３）</font>から<font color="darkkhaki">（５）</font>までとし、同号ハ<font color="darkkhaki">（１）</font>の次に次のように加える部分を除く。）</font>、第三十一条の改正規定、第五号書式の改正規定、第六号書式の改正規定、第八号書式の改正規定及び同号書式を第九号書式とし、第七号書式の次に次の書式を加える改正規定並びに附則第三条及び第四条の規定　平成三十年一月一日

--- ---

[条(全)](相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条_.md)    [項(全)](相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条第１項_.md)    [項](相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条第１項.md)

~~前号←~~　  [→次号](相続税法施行規則附則平成２７年３月３１日財務省令第２４号第１条第１項第２号.md)

[目次](index相続税法施行規則.md)

