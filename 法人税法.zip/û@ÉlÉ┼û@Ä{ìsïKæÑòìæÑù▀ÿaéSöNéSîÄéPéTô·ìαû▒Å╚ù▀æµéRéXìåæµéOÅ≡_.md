　
法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条

１　この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　別表一の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分及び同号<font color="darkkhaki"><font color="darkkhaki">（５）</font></font>に係る部分を除く。）</font></font>、別表一の二の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分を除く。）</font></font>、別表一の三の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号に係る部分を除く。）</font></font>及び別表二十の表の改正規定　令和四年十二月三十一日


二　別表十二<font color="lightsalmon"><font color="lightsalmon">（十四）</font></font>の記載要領第一号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「は、青色申告書を提出する法人で」</font></font>の次に<font color="peru"><font color="peru">「租税特別措置法第６１条の２第１項（農業経営基盤強化準備金）に規定する認定農地所有適格法人に該当するものが同条の規定の適用を受ける場合、青色申告書を提出する法人で所得税法等の一部を改正する法律（令和４年法律第４号）第１１条の規定による改正前の」</font></font>を加える部分に限る。）</font></font>　農業経営基盤強化促進法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和四年法律第　　　号）</font></font>の施行の日


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下同じ。）</font></font>の令和四年四月一日以後に終了する事業年度の所得に対する法人税及び連結法人<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号。以下<font color="peru"><font color="peru">「令和二年改正法」</font></font>という。）</font></font>第三条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「令和二年旧法」</font></font>という。）</font></font>第二条第十二号の七の二に規定する連結法人をいう。以下この項において同じ。）</font></font>の同日以後に終了する連結事業年度<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第十五条の二第一項に規定する連結事業年度をいう。以下この項において同じ。）</font></font>の連結所得<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十八号の四に規定する連結所得をいう。以下この項において同じ。）</font></font>に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


３　法人の令和四年四月一日前に開始した事業年度<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十二号の七に規定する連結子法人の令和二年旧法第十五条の二第一項に規定する連結親法人事業年度が同日前に開始した事業年度を含む。）</font></font>の所得に対する法人税に係る新規則別表の書式の適用については、新規則別表一から別表十九の三までの記載要領中次の各号に掲げる規定には、当該各号に定める規定を含むものとする。


一　法人税法の各規定　当該規定に対応する令和二年改正前法<font color="lightsalmon"><font color="lightsalmon">（令和二年改正法附則第十四条第二項の規定によりなおその効力を有するものとされる令和二年旧法をいう。以下同じ。）</font></font>の規定


二　所得税法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和四年法律第四号。以下<font color="peru"><font color="peru">「改正法」</font></font>という。）</font></font>第二条の規定による改正前の法人税法の各規定　当該規定に対応する旧令和二年改正前法<font color="lightsalmon"><font color="lightsalmon">（改正法第三条の規定による改正前の令和二年改正前法をいう。）</font></font>の規定


三　租税特別措置法<font color="lightsalmon"><font color="lightsalmon">（昭和三十二年法律第二十六号）</font></font>の各規定　当該規定に対応する令和二年改正前措置法<font color="lightsalmon"><font color="lightsalmon">（令和二年改正法附則第十四条第二項の規定によりなおその効力を有するものとされる令和二年改正法第十六条の規定による改正前の租税特別措置法をいう。以下同じ。）</font></font>の規定


四　改正法第十一条の規定による改正前の租税特別措置法の各規定　当該規定に対応する旧令和二年改正前措置法<font color="lightsalmon"><font color="lightsalmon">（改正法第十二条の規定による改正前の令和二年改正前措置法をいう。）</font></font>の規定


五　東日本大震災の被災者等に係る国税関係法律の臨時特例に関する法律<font color="lightsalmon"><font color="lightsalmon">（平成二十三年法律第二十九号）</font></font>の各規定　当該規定に対応する令和二年改正法附則第十四条第二項の規定によりなおその効力を有するものとされる令和二年改正法第二十三条の規定による改正前の東日本大震災の被災者等に係る国税関係法律の臨時特例に関する法律の規定


六　法人税法施行令<font color="lightsalmon"><font color="lightsalmon">（昭和四十年政令第九十七号）</font></font>の各規定　当該規定に対応する令和二年改正前令<font color="lightsalmon"><font color="lightsalmon">（法人税法施行令等の一部を改正する政令<font color="darkkhaki"><font color="darkkhaki">（令和二年政令第二百七号）</font></font>附則第二条第二項の規定によりなおその効力を有するものとされる同令第一条の規定による改正前の法人税法施行令をいう。以下同じ。）</font></font>の規定


七　法人税法施行令等の一部を改正する政令<font color="lightsalmon"><font color="lightsalmon">（令和四年政令第百三十七号。以下<font color="peru"><font color="peru">「改正令」</font></font>という。）</font></font>第一条の規定による改正前の法人税法施行令の各規定　当該規定に対応する旧令和二年改正前令<font color="lightsalmon"><font color="lightsalmon">（改正令第二条の規定による改正前の令和二年改正前令をいう。）</font></font>の規定


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項_.md) [第２項(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第２項_.md) [第３項(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第３項_.md) 

[第１項 　 ](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項.md) [第２項 　 ](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第２項.md) [第３項 　 ](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第３項.md) 

[目次](index法人税法施行規則.md)

