　
法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条

１　この省令は、公布の日から施行する。ただし、別表六<font color="lightsalmon"><font color="lightsalmon">（七）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同第二号の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十六）</font></font>の記載要領の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同表を別表六<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>とし、同表の前に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六<font color="darkkhaki"><font color="darkkhaki">（二十七）</font></font>を別表六<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>とする部分を除く。）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（四）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十二）</font></font>の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同第二号の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十三）</font></font>の記載要領の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>付表の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定及び別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>を別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>とし、同表の前に二表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十四）</font></font>を別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十五）</font></font>とする部分を除く。）</font></font>並びに附則第三項の規定は、特定高度情報通信技術活用システムの開発供給及び導入の促進に関する法律<font color="lightsalmon"><font color="lightsalmon">（令和二年法律第　　　号）</font></font>の施行の日から施行する。


２　別段の定めがあるものを除き、改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下同じ。）</font></font>の令和二年四月一日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


３　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>及び別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>付表の書式は、法人の附則第一項ただし書に規定する日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用する。


４　新規則別表十七<font color="lightsalmon"><font color="lightsalmon">（四）</font></font><font color="lightsalmon"><font color="lightsalmon">（同表の表の<font color="peru"><font color="peru">「無形資産の譲渡の対価」</font></font>から<font color="peru"><font color="peru">「貸付金の利息又は借入金の利息」</font></font>までの欄に係る部分に限る。）</font></font>及び別表十七の三<font color="lightsalmon"><font color="lightsalmon">（三）</font></font><font color="lightsalmon"><font color="lightsalmon">（同表の表の<font color="peru"><font color="peru">「無形資産の譲渡の対価」</font></font>から<font color="peru"><font color="peru">「貸付金の利息又は借入金の利息」</font></font>までの欄に係る部分に限る。）</font></font>の書式は、法人の令和二年四月一日以後に開始する事業年度の所得に対する法人税及び連結法人の同日以後に開始する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に開始した事業年度の所得に対する法人税及び連結法人の同日前に開始した連結事業年度の連結所得に対する法人税については、なお従前の例による。


５　この省令の施行の日から特定高度情報通信技術活用システムの開発供給及び導入の促進に関する法律の施行の日の前日までの間における次の各号に掲げる書式の適用については、当該各号に定めるところによる。


一　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の書式　同表の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「、第４２条の１２の５の２第２項（認定特定高度情報通信技術活用設備を取得した場合の法人税額の特別控除）又は」</font></font>とあるのは、<font color="peru"><font color="peru">「又は」</font></font>とする。


二　新規則別表六の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>の書式　同表の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「、第６８条の１５の６の２第２項（認定特定高度情報通信技術活用設備を取得した場合の法人税額の特別控除）又は」</font></font>とあるのは、<font color="peru"><font color="peru">「又は」</font></font>とする。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第１項_.md) [第２項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第２項_.md) [第３項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第３項_.md) [第４項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項_.md) [第５項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項_.md) 

[第１項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第１項.md) [第２項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第２項.md) [第３項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第３項.md) [第４項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項.md) [第５項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項.md) 

[目次](index法人税法施行規則.md)

