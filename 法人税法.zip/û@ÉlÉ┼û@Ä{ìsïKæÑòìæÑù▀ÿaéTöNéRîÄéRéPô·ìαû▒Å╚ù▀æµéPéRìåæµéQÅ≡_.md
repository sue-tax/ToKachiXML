（確定申告書の記載事項に関する経過措置）
法人税法施行規則附則令和５年３月３１日財務省令第１３号第２条

１　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第三十四条第一項第四号の規定は、この省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に残余財産が確定する内国法人の当該残余財産の確定の日の属する事業年度<font color="lightsalmon"><font color="lightsalmon">（施行日前に残余財産が確定した内国法人の当該残余財産の確定の日の属する事業年度で当該事業年度の所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和五年法律第三号。以下<font color="peru"><font color="peru">「改正法」</font></font>という。）</font></font>第二条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「旧法」</font></font>という。）</font></font>第七十四条第一項の規定による申告書の同条第二項の規定により読み替えて適用する同条第一項に規定する提出期限が施行日以後に到来するもの<font color="darkkhaki"><font color="darkkhaki">（以下この条及び附則第四条において<font color="peru"><font color="peru">「経過事業年度」</font></font>という。）</font></font>を含む。）</font></font>の所得に対する法人税について適用し、施行日前に残余財産が確定した内国法人の当該残余財産の確定の日の属する事業年度<font color="lightsalmon"><font color="lightsalmon">（経過事業年度を除く。）</font></font>の所得に対する法人税については、なお従前の例による。


--- ---

[前条(全)←](法人税法施行規則附則令和５年３月３１日財務省令第１３号第１条_.md)    [→次条(全)](法人税法施行規則附則令和５年３月３１日財務省令第１３号第３条_.md)

[第１項(全)](法人税法施行規則附則令和５年３月３１日財務省令第１３号第２条第１項_.md) 

[第１項 　 ](法人税法施行規則附則令和５年３月３１日財務省令第１３号第２条第１項.md) 

[目次](index法人税法施行規則.md)

