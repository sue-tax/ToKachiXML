　
法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条

１　この省令は、公布の日から施行する。


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表六<font color="darkkhaki"><font color="darkkhaki">（六）</font></font>の書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十一年四月一日以後に終了する事業年度の所得及び同日以後の解散又は合併による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下同じ。）</font></font>について適用し、法人の同日前に終了した事業年度の所得及び同日前の解散又は合併による清算所得に対する法人税については、なお従前の例による。


３　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の書式は、法人の平成十一年四月一日以後に開始する事業年度の所得に対する法人税について適用し、法人の同日前に開始した事業年度の所得に対する法人税については、なお従前の例による。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第１項_.md) [第２項(全)](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第２項_.md) [第３項(全)](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第３項_.md) 

[第１項 　 ](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第１項.md) [第２項 　 ](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第２項.md) [第３項 　 ](法人税法施行規則附則平成１１年４月１５日大蔵省令第５２号第０条第３項.md) 

[目次](index法人税法施行規則.md)

