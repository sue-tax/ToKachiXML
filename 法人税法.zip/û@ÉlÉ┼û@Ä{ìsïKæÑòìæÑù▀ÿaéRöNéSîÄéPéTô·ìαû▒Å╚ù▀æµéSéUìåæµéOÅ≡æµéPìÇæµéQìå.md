　
[法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項)第２号

第一条の改正規定<font color="lightsalmon"><font color="lightsalmon">（法人税法施行規則別表十四<font color="darkkhaki"><font color="darkkhaki">（二）</font></font>の記載要領第一号の改正規定に係る部分<font color="darkkhaki"><font color="darkkhaki">（<font color="peru"><font color="peru">「第６６条の１１の２第１項」</font></font>を<font color="peru"><font color="peru">「第６６条の１１の３第１項」</font></font>に改める部分に限る。）</font></font>に限る。）</font></font>　新型コロナウイルス感染症等の影響による社会経済情勢の変化に対応して金融の機能の強化及び安定の確保を図るための銀行法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和三年法律第　　　号）</font></font>の施行の日


--- ---

[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条_.md)    [項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項_.md)    [項](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項.md)

[前号←](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項第１号.md)  ~~→次号~~

[目次](index法人税法施行規則.md)

