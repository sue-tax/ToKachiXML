　
法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第３項

新規則別表十一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>及び別表十一<font color="lightsalmon"><font color="lightsalmon">（一の二）</font></font>の書式は、法人の平成十三年四月一日以後に開始する事業年度及び同日以後に行われる合併、分割型分割<font color="lightsalmon"><font color="lightsalmon">（法第二条第十二号の九に規定する分割型分割をいう。以下この項において同じ。）</font></font>、適格分社型分割<font color="lightsalmon"><font color="lightsalmon">（法第二条第十二号の十三に規定する適格分社型分割をいう。）</font></font>、適格現物出資又は適格事後設立<font color="lightsalmon"><font color="lightsalmon">（以下この項において<font color="peru"><font color="peru">「合併等」</font></font>という。）</font></font>に係る被合併法人、分割法人、現物出資法人又は事後設立法人<font color="lightsalmon"><font color="lightsalmon">（以下この項において<font color="peru"><font color="peru">「被合併法人等」</font></font>という。）</font></font>の経過事業年度<font color="lightsalmon"><font color="lightsalmon">（当該合併等の日<font color="darkkhaki"><font color="darkkhaki">（合併又は分割型分割にあっては、当該合併又は分割型分割の日の前日）</font></font>の属する事業年度をいい、当該被合併法人等の同年四月一日以後に開始する事業年度を除く。以下この項において同じ。）</font></font>の所得に対する法人税について適用し、法人の同年四月一日前に開始した事業年度<font color="lightsalmon"><font color="lightsalmon">（経過事業年度を除く。）</font></font>の所得に対する法人税については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条_.md)  [項](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第３項.md)

[前項(全)←](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第２項_.md)  ~~→次項(全)~~

[前項 　 ←](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第２項.md)  ~~→次項~~



[目次](index法人税法施行規則.md)

