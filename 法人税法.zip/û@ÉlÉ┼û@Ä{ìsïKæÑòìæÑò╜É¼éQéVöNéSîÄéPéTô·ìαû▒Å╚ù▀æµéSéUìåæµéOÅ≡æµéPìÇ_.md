　
法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　別表十六<font color="lightsalmon">（十）</font>の表の改正規定及び附則第七項の規定　平成二十七年十月一日

二　別表一<font color="lightsalmon">（一）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（４１）</font>」の欄に係る部分に限る。）</font>、別表一<font color="lightsalmon">（二）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（４１）</font>」の欄に係る部分に限る。）</font>、別表一<font color="lightsalmon">（三）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（３６）</font>」の欄に係る部分に限る。）</font>、別表一の二<font color="lightsalmon">（一）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（４１）</font>」の欄に係る部分に限る。）</font>、別表一の二<font color="lightsalmon">（二）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（４１）</font>」の欄に係る部分に限る。）</font>、別表一の二<font color="lightsalmon">（三）</font>の表の改正規定<font color="lightsalmon">（「法人番号」の欄に係る部分及び「所得税の額　<font color="darkkhaki">（３６）</font>」の欄に係る部分に限る。）</font>、別表六<font color="lightsalmon">（一）</font>の改正規定、同表の次に一表を加える改正規定、別表六<font color="lightsalmon">（五）</font>の表の改正規定<font color="lightsalmon">（「控除所得税額又は控除所得税額の個別帰属額　<font color="darkkhaki">（２１）</font>」の欄に係る部分に限る。）</font>、別表六の二<font color="lightsalmon">（一）</font>の改正規定、同表の次に一表を加える改正規定、別表十八の表及び別表十八の二の表の改正規定並びに別表十九の表の改正規定並びに附則第四項及び第五項の規定　平成二十八年一月一日

三　別表六<font color="lightsalmon">（十七）</font>の改正規定、同表の次に二表を加える改正規定、別表六の二<font color="lightsalmon">（十四）</font>の改正規定、同表の次に一表を加える改正規定、別表六の二<font color="lightsalmon">（十五）</font>を別表六の二<font color="lightsalmon">（十六）</font>とし、同表の前に三表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（十五）</font>を別表六の二<font color="darkkhaki">（十六）</font>とする部分を除く。）</font>及び別表十三<font color="lightsalmon">（五）</font>の改正規定<font color="lightsalmon">（同表の記載要領第一号に係る部分を除く。）</font>並びに附則第六項の規定　地域再生法の一部を改正する法律<font color="lightsalmon">（平成二十七年法律第　　　号）</font>の施行の日

--- ---


[条(全)](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条_.md)  [項](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第２項.md)

[第１号](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第１項第１号.md)  [第２号](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第１項第２号.md)  [第３号](法人税法施行規則附則平成２７年４月１５日財務省令第４６号第０条第１項第３号.md)  

[目次](index法人税法施行規則.md)

