　
法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項

新規則別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表十一<font color="darkkhaki"><font color="darkkhaki">（一の二）</font></font>、別表十二<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>、別表十二<font color="darkkhaki"><font color="darkkhaki">（十九）</font></font>及び別表十六<font color="darkkhaki"><font color="darkkhaki">（六）</font></font>の書式を除く。）</font></font>は、法人の施行日以後に終了する事業年度の所得及び施行日以後の解散又は合併による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下同じ。）</font></font>について適用し、法人の施行日前に終了した事業年度の所得及び施行日前の解散又は合併による清算所得に対する法人税については、なお従前の例による。


--- ---

[条(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条_.md)  [項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項_.md)

[前項(全)←](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項_.md)    [→次項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第４項_.md)

[前項 　 ←](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項.md)    [→次項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第４項.md)



[目次](index法人税法施行規則.md)

