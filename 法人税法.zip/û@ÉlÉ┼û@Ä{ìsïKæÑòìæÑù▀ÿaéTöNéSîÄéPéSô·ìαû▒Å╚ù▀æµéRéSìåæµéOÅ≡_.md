　
法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条

１　この省令は、公布の日から施行する。ただし、別表十六<font color="lightsalmon"><font color="lightsalmon">（十）</font></font>の記載要領第一号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「ついて令」</font></font>を<font color="peru"><font color="peru">「ついて令第１３９条の４（資産に係る控除対象外消費税額等の損金算入）（法人税法施行令等の一部を改正する政令（平成３０年政令第１３２号。以下この号において「平成３０年改正令」という。）附則第１４条第３項（資産に係る控除対象外消費税額等の損金算入に関する経過措置）の規定により読み替えて適用する場合を含む。）又は平成３０年改正令第１条の規定による改正前の法人税法施行令」</font></font>に、<font color="peru"><font color="peru">「法人税法施行令等の一部を改正する政令（平成３０年政令第１３２号）」</font></font>を<font color="peru"><font color="peru">「平成３０年改正令」</font></font>に改め、<font color="peru"><font color="peru">「（資産に係る控除対象外消費税額等の損金算入に関する経過措置）」</font></font>を削る部分に限る。）</font></font>は、令和五年十月一日から施行する。


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表十九の二の書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下同じ。）</font></font>の令和五年四月一日以後に終了する事業年度の所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号）</font></font>第三条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「令和二年旧法」</font></font>という。）</font></font>第二条第十二号の七の二に規定する連結法人をいう。）</font></font>の同日前に終了した連結事業年度<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第十五条の二第一項に規定する連結事業年度をいう。）</font></font>の連結所得<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十八号の四に規定する連結所得をいう。）</font></font>に対する法人税については、なお従前の例による。


３　新規則別表十九の二の書式は、外国法人の令和五年四月一日以後に納税義務が成立する中間申告書に係る法人税について適用し、外国法人の同日前に納税義務が成立した中間申告書に係る法人税については、なお従前の例による。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第１項_.md) [第２項(全)](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第２項_.md) [第３項(全)](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第３項_.md) 

[第１項 　 ](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第１項.md) [第２項 　 ](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第２項.md) [第３項 　 ](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第３項.md) 

[目次](index法人税法施行規則.md)

