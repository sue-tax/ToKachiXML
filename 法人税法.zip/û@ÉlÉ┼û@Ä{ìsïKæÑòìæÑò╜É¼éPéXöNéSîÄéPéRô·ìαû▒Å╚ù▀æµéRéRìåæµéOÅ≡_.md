　
法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条

１　この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十七<font color="darkkhaki">（二の三）</font>」を「別表十七<font color="darkkhaki">（二の四）</font>」に改める部分に限る。）</font>、第三十七条の九第二項の改正規定<font color="lightsalmon">（「別表十七<font color="darkkhaki">（二の三）</font>」を「別表十七<font color="darkkhaki">（二の四）</font>」に改める部分に限る。）</font>、別表六<font color="lightsalmon">（二）</font>の記載要領第一号の改正規定、別表六<font color="lightsalmon">（二の二）</font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon">（二）</font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon">（二）</font>付表の記載要領の改正規定、別表七<font color="lightsalmon">（一）</font>付表一の記載要領第三号の改正規定<font color="lightsalmon">（「第１１６条の２第５項」を「第１１６条の２第６項」に改める部分に限る。）</font>、別表十七<font color="lightsalmon">（二）</font>の記載要領第九号の改正規定、別表十七<font color="lightsalmon">（二）</font>付表の記載要領第十号の改正規定、別表十七<font color="lightsalmon">（二の二）</font>の記載要領第十八号の改正規定、別表十七<font color="lightsalmon">（二の二）</font>付表一の記載要領の改正規定、別表十七<font color="lightsalmon">（二の二）</font>付表二の記載要領の改正規定、別表十七<font color="lightsalmon">（二の三）</font>の記載要領第七号の改正規定及び同表の次に一表を加える改正規定　平成十九年五月一日

二　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（五）</font>」に改める部分に限る。）</font>、第三十四条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（五）</font>」に改める部分に限る。）</font>、第四十三条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>、別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（四）</font>から別表十四<font color="darkkhaki">（五）</font>まで」に改める部分に限る。）</font>及び別表十四<font color="lightsalmon">（四）</font>付表の次に一表を加える改正規定並びに附則第三項の規定　平成二十年四月一日

三　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>まで」を「別表十<font color="darkkhaki">（七）</font>まで、別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、第三十四条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>」を「別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、第四十三条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>」を「別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、別表四の表の改正規定、別表四の二の表の改正規定、別表四の二付表の表の改正規定、別表六<font color="lightsalmon">（一）</font>の表の改正規定、別表六<font color="lightsalmon">（二）</font>の表の改正規定、別表六の二<font color="lightsalmon">（一）</font>の表の改正規定、別表六の二<font color="lightsalmon">（二）</font>の表の改正規定、別表七<font color="lightsalmon">（二）</font>の記載要領第四号の改正規定、別表九<font color="lightsalmon">（四）</font>の改正規定、別表十<font color="lightsalmon">（八）</font>を別表十<font color="lightsalmon">（九）</font>とし、別表十<font color="lightsalmon">（七）</font>の次に一表を加える改正規定、別表十七<font color="lightsalmon">（二の三）</font>の記載要領第二号の改正規定、同第四号の改正規定、別表二十の記載要領第一号の改正規定及び別表二十一<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表を別表二十<font color="darkkhaki">（四）</font>とする部分を除く。）</font>　信託法<font color="lightsalmon">（平成十八年法律第百八号）</font>の施行の日

四　別表三<font color="lightsalmon">（二の三）</font>の記載要領第一号の改正規定及び別表三<font color="lightsalmon">（二の三）</font>付表の記載要領の改正規定　都市再生特別措置法等の一部を改正する法律<font color="lightsalmon">（平成十九年法律第十九号）</font>の施行の日

五　別表六<font color="lightsalmon">（二）</font>の記載要領第六号の改正規定<font color="lightsalmon">（「第２条第１９項」を「第２条第１２項」に改める部分に限る。）</font>、別表八の表の改正規定、別表八の二の表の改正規定、別表十<font color="lightsalmon">（七）</font>の表のⅠの改正規定及び同表の記載要領第三号の改正規定　証券取引法等の一部を改正する法律<font color="lightsalmon">（平成十八年法律第六十五号）</font>の施行の日

２　別段の定めがあるものを除き、改正後の法人税法施行規則<font color="lightsalmon">（以下「新規則」という。）</font>別表の書式は、法人<font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki">（定義）</font>に規定する人格のない社団等を含む。以下同じ。）</font>の平成十九年四月一日以後に終了する事業年度の所得に対する法人税、連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日以後に終了する計算期間の所得に対する法人税、法人の同日以後に終了する事業年度の退職年金等積立金に対する法人税及び法人の同日以後の解散<font color="lightsalmon">（合併による解散を除く。以下この項において同じ。）</font>による清算所得に対する法人税<font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の事業年度の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下この項において同じ。）</font>について適用し、法人の同日前に終了した事業年度の所得に対する法人税、連結法人の同日前に終了した連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日前に終了した計算期間の所得に対する法人税、法人の同日前に終了した事業年度の退職年金等積立金に対する法人税及び法人の同日前の解散による清算所得に対する法人税については、なお従前の例による。

３　新規則別表十四<font color="lightsalmon">（五）</font>の書式は、法人の平成二十年四月一日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用する。

--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項_.md) [第２項(全)](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第２項_.md) [第３項(全)](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第３項_.md) 

[第１項 　 ](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項.md) [第２項 　 ](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第２項.md) [第３項 　 ](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第３項.md) 

[目次](index法人税法施行規則.md)

