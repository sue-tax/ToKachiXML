<font color="lightsalmon">（法人税法施行規則の一部改正に伴う経過措置）</font>
法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第２項

新規則別表五<font color="lightsalmon">（二）</font>、別表五の二<font color="lightsalmon">（一）</font>付表二、別表六の二<font color="lightsalmon">（三）</font>付表三から別表六の二<font color="lightsalmon">（三）</font>付表五まで、別表六の二<font color="lightsalmon">（四）</font>付表二から別表六の二<font color="lightsalmon">（四）</font>付表四まで、別表七<font color="lightsalmon">（一）</font>付表一から別表七<font color="lightsalmon">（一）</font>付表三まで、別表九<font color="lightsalmon">（二）</font>、別表十一<font color="lightsalmon">（三）</font>、別表十二<font color="lightsalmon">（三）</font>、別表十二<font color="lightsalmon">（十）</font>、別表十六<font color="lightsalmon">（六）</font>、別表十六<font color="lightsalmon">（十）</font>及び別表十六<font color="lightsalmon">（十一）</font>の書式は、法人の平成二十二年十月一日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。

--- ---


[条(全)](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条_.md)  [項](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第２項.md)

[前項(全)←](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第１項_.md)    [→次項(全)](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第１項.md)    [→次項 　 ](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第２条第３項.md)



[目次](index法人税法施行規則.md)

