　
法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第二十二条の二第四号<font color="lightsalmon"><font color="lightsalmon">（寄附金の損金算入限度額の計算上公益法人等から除かれる法人）</font></font>の規定は、同号に掲げる法人のこの省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に終了する事業年度の所得に対する法人税について適用する。


--- ---

[条(全)](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条_.md)  [項(全)](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第２項_.md)

[前項(全)←](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第１項_.md)    [→次項(全)](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第１項.md)    [→次項 　 ](法人税法施行規則附則平成１１年３月３１日大蔵省令第３２号第０条第３項.md)



[目次](index法人税法施行規則.md)

