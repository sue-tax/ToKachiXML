　
法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項

次の各号に掲げる書式により令和三年四月一日前に終了した事業年度の所得に対する法人税又は同日前に終了した連結事業年度<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号）</font></font>第三条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「令和二年旧法」</font></font>という。）</font></font>第十五条の二第一項に規定する連結事業年度をいう。）</font></font>の連結所得<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十八号の四に規定する連結所得をいう。）</font></font>に対する法人税について同日以後に確定申告書又は同条第三十二号に規定する連結確定申告書<font color="lightsalmon"><font color="lightsalmon">（これらの申告書に係る修正申告書を含む。）</font></font>の提出をする場合には、当該各号に定めるところによる。


一　前項の規定によりなお従前の例によることとされる場合における改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「旧規則」</font></font>という。）</font></font>別表一若しくは別表一の二の書式、法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（令和二年財務省令第四十号。以下<font color="peru"><font color="peru">「令和二年改正規則」</font></font>という。）</font></font>附則第二項の規定によりなお従前の例によることとされる場合における令和二年改正規則による改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「令和二年旧規則」</font></font>という。）</font></font>別表一若しくは別表一の二の書式又は法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成三十一年財務省令第三十一号。以下<font color="peru"><font color="peru">「平成三十一年改正規則」</font></font>という。）</font></font>附則第二項の規定によりなお従前の例によることとされる場合における平成三十一年改正規則による改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「平成三十一年旧規則」</font></font>という。）</font></font>別表一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>から別表一の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>までの書式　これらの表の表中「


二　法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成三十年財務省令第三十五号。以下<font color="peru"><font color="peru">「平成三十年改正規則」</font></font>という。）</font></font>附則第二項その他これに類する法人税法施行規則別表の書式を改正する省令の経過措置を定める規定によりなお従前の例によることとされる場合におけるこれらの省令による改正前の法人税法施行規則別表一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>から別表一の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>までの書式<font color="lightsalmon"><font color="lightsalmon">（前号に掲げる書式を除く。）</font></font>　平成三十年改正規則附則第三項の規定にかかわらず、これらの表の表中「


--- ---


[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条_.md)  [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項.md)

[前項(全)←](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項_.md)    [→次項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項_.md)

[前項 　 ←](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項.md)    [→次項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項.md)

[第１号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項第１号.md)  [第２号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項第２号.md)  

[目次](index法人税法施行規則.md)

