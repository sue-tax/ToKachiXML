　
[法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項)第２号

[第三十七条の九第二項](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第３７条の９第２項)の改正規定<font color="lightsalmon">（<font color="peru">「別表七の二付表五」</font>を<font color="peru">「別表七の二付表六」</font>に改める部分に限る。）</font>、[第三十七条の十一第二項](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第３７条の１１第２項)の改正規定<font color="lightsalmon">（<font color="peru">「別表七の二付表五」</font>を<font color="peru">「別表七の二付表六」</font>に改める部分に限る。）</font>、別表六<font color="lightsalmon">（六）</font>の記載要領[第一号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第１号)<font color="lightsalmon">（１）</font>の改正規定<font color="lightsalmon">（<font color="peru">「第４２条の１２の５の２第２項」</font>を<font color="peru">「第４２条の１２の６第２項」</font>に、<font color="peru">「又は」</font>を<font color="peru">「、第４２条の１２の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font>に改める部分に限る。）</font>、別表六<font color="lightsalmon">（二十三）</font>の記載要領[第三号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第３号)の改正規定、別表六<font color="lightsalmon">（二十八）</font>を別表六<font color="lightsalmon">（三十一）</font>とし、同表の次に一表を加える改正規定<font color="lightsalmon">（別表六<font color="darkkhaki">（二十八）</font>を別表六<font color="darkkhaki">（三十一）</font>とする部分を除く。）</font>、別表六<font color="lightsalmon">（二十七）</font>の記載要領[第一号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第１号)の改正規定、別表六の二<font color="lightsalmon">（三）</font>の記載要領[第一号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第１号)<font color="lightsalmon">（１）</font>の改正規定<font color="lightsalmon">（<font color="peru">「又は」</font>を<font color="peru">「、第６８条の１５の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font>に改める部分に限る。）</font>、別表六の二<font color="lightsalmon">（二十五）</font>付表を別表六の二<font color="lightsalmon">（二十八）</font>付表とし、同表の次に二表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（二十五）</font>付表を別表六の二<font color="darkkhaki">（二十八）</font>付表とする部分を除く。）</font>、別表七<font color="lightsalmon">（一）</font>の記載要領の改正規定<font color="lightsalmon">（同[第四号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第４号)に係る部分を除く。）</font>、別表七<font color="lightsalmon">（一）</font>付表四の次に一表を加える改正規定、別表七の二付表一の記載要領の改正規定、別表七の二付表五の次に一表を加える改正規定、別表十二<font color="lightsalmon">（一）</font>の次に一表を加える改正規定、別表十六<font color="lightsalmon">（六）</font>の改正規定及び別表十六<font color="lightsalmon">（九）</font>の改正規定並びに附則[第五項](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第５項)の規定　産業競争力強化法等の一部を改正する等の法律<font color="lightsalmon">（令和三年法律第　　　号）</font>の施行の日

--- ---

[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条_.md)    [項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項_.md)    [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項.md)

[前号←](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第１号.md)    [→次号](法人税法施行規則附則令和３年４月１５日財務省令第４２号＿第０条第１項第３号.md)

[目次](index法人税法施行規則.md)

