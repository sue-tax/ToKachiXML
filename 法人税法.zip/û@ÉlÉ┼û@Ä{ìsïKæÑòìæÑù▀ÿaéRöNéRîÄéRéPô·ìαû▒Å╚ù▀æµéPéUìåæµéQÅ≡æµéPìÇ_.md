<font color="lightsalmon"><font color="lightsalmon">（経過措置の原則）</font></font>
法人税法施行規則附則令和３年３月３１日財務省令第１６号第２条第１項

別段の定めがあるものを除き、改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（次条において<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>の規定は、この省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に行われる合併、分割、現物出資、法人税法第二条第十二号の五の二に規定する現物分配、株式交換、株式移転又は株式交付<font color="lightsalmon"><font color="lightsalmon">（以下この条において<font color="peru"><font color="peru">「合併等」</font></font>という。）</font></font>について適用し、施行日前に行われた合併等については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則令和３年３月３１日財務省令第１６号第２条_.md)  [項](法人税法施行規則附則令和３年３月３１日財務省令第１６号第２条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index法人税法施行規則.md)

