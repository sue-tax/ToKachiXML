　
法人税法施行規則附則平成１４年３月３１日財務省令第２６号第０条

１　この省令は、平成十四年四月一日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　第二十二条の二に一号を加える改正規定　マンションの建替えの円滑化等に関する法律<font color="lightsalmon"><font color="lightsalmon">（平成十四年法律第七十八号）</font></font>の施行の日


二　第二十七条の十四第二号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「（特定都市鉄道整備準備金）」</font></font>の下に<font color="peru"><font color="peru">「、第二十一条の七第六号（新幹線鉄道大規模改修準備金）」</font></font>を加える部分に限る。）</font></font>　全国新幹線鉄道整備法の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（平成十四年法律第六十四号）</font></font>の施行の日


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１４年３月３１日財務省令第２６号第０条第１項_.md) 

[第１項 　 ](法人税法施行規則附則平成１４年３月３１日財務省令第２６号第０条第１項.md) 

[目次](index法人税法施行規則.md)

