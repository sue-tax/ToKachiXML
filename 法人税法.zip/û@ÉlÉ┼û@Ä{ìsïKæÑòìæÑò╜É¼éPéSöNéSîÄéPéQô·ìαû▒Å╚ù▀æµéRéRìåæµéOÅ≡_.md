　
法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条

１　この省令は、公布の日から施行する。ただし、別表十二<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>を別表十二<font color="lightsalmon"><font color="lightsalmon">（八）</font></font>とし、同表の次に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表十二<font color="darkkhaki"><font color="darkkhaki">（九）</font></font>を別表十二<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>とする部分を除く。）</font></font>、別表十二<font color="lightsalmon"><font color="lightsalmon">（十一）</font></font>の改正規定及び別表二十一の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「特定都市鉄道整備準備金」</font></font>の下に<font color="peru"><font color="peru">「、新幹線鉄道大規模改修準備金」</font></font>を加える部分及び<font color="peru"><font color="peru">「特定都市鉄道整備準備金積立額」</font></font>の下に<font color="peru"><font color="peru">「、新幹線鉄道大規模改修準備金積立額」</font></font>を加える部分に限る。）</font></font>は、全国新幹線鉄道整備法の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（平成十四年法律第六十四号）</font></font>の施行の日から施行する。


２　この省令の施行の日から前項ただし書に規定する日までの間における改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（次項において<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第二十七条の十四の規定の適用については、同条中<font color="peru"><font color="peru">「別表十二（九）」</font></font>とあるのは、<font color="peru"><font color="peru">「別表十二（八）」</font></font>とする。


３　新規則別表の様式は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十四年四月一日以後に終了する事業年度の所得に対する法人税及び同日以後の解散又は合併による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下同じ。）</font></font>について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び同日前の解散又は合併による清算所得に対する法人税については、なお従前の例による。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第１項_.md) [第２項(全)](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第２項_.md) [第３項(全)](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第３項_.md) 

[第１項 　 ](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第１項.md) [第２項 　 ](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第２項.md) [第３項 　 ](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第３項.md) 

[目次](index法人税法施行規則.md)

