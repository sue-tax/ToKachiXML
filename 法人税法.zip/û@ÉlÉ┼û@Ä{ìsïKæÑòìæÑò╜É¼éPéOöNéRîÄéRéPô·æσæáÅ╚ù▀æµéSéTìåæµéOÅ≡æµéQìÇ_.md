　
法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第八条の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>のこの省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に終了する事業年度の所得に対する法人税について適用し、法人の施行日前に終了した事業年度の所得に対する法人税については、なお従前の例による。この場合において、理容師法及び美容師法の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（平成七年法律第百九号）</font></font>附則第四条第二項の規定により厚生大臣の指定がなおその効力を有することとされる施設に係る新令第五条第一項第三十号ニの規定の適用については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条_.md)  [項](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項.md)

[前項(全)←](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第１項_.md)    [→次項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第１項.md)    [→次項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項.md)



[目次](index法人税法施行規則.md)

