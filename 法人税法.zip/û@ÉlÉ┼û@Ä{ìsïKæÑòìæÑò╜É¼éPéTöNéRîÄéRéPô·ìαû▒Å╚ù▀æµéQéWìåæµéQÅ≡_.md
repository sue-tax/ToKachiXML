（収益事業の範囲に関する経過措置）
法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条

１　法人税法施行令の一部を改正する政令<font color="lightsalmon"><font color="lightsalmon">（平成十五年政令第百三十一号）</font></font>附則第四条第二項<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲に関する経過措置）</font></font>の規定によりなおその効力を有するものとされる同令による改正前の法人税法施行令第五条第一項第一号イ<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲）</font></font>の適用については、改正前の法人税法施行規則第四条<font color="lightsalmon"><font color="lightsalmon">（学校給食用の物資の範囲）</font></font>の規定は、なおその効力を有する。


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第八条の二の二第一項<font color="lightsalmon"><font color="lightsalmon">（信用保証業で収益事業に該当しないものの範囲等）</font></font><font color="lightsalmon"><font color="lightsalmon">（都市再生特別措置法に係る部分を除く。）</font></font>の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の前条第三号に定める日以後に終了する事業年度の所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税については、なお従前の例による。


３　新規則第八条の二の二第一項<font color="lightsalmon"><font color="lightsalmon">（都市再生特別措置法に係る部分に限る。）</font></font>の規定は、法人のこの省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に開始する事業年度の所得に対する法人税について適用し、法人の施行日前に開始した事業年度の所得に対する法人税については、なお従前の例による。


４　新規則第八条の三第一項<font color="lightsalmon"><font color="lightsalmon">（無体財産権の提供等を行う事業で収益事業に該当しないものの範囲等）</font></font>の規定は、法人の前条第三号に定める日以後に終了する事業年度の所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税については、なお従前の例による。


--- ---

[前条(全)←](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第１条_.md)    [→次条(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第３条_.md)

[第１項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項_.md) [第２項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項_.md) [第３項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第３項_.md) [第４項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第４項_.md) 

[第１項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項.md) [第２項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項.md) [第３項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第３項.md) [第４項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第４項.md) 

[目次](index法人税法施行規則.md)

