　
法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項

新規則別表十七<font color="lightsalmon"><font color="lightsalmon">（四）</font></font><font color="lightsalmon"><font color="lightsalmon">（同表の表の<font color="peru"><font color="peru">「無形資産の譲渡の対価」</font></font>から<font color="peru"><font color="peru">「貸付金の利息又は借入金の利息」</font></font>までの欄に係る部分に限る。）</font></font>及び別表十七の三<font color="lightsalmon"><font color="lightsalmon">（三）</font></font><font color="lightsalmon"><font color="lightsalmon">（同表の表の<font color="peru"><font color="peru">「無形資産の譲渡の対価」</font></font>から<font color="peru"><font color="peru">「貸付金の利息又は借入金の利息」</font></font>までの欄に係る部分に限る。）</font></font>の書式は、法人の令和二年四月一日以後に開始する事業年度の所得に対する法人税及び連結法人の同日以後に開始する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に開始した事業年度の所得に対する法人税及び連結法人の同日前に開始した連結事業年度の連結所得に対する法人税については、なお従前の例による。


--- ---

[条(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条_.md)  [項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項_.md)

[前項(全)←](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第３項_.md)    [→次項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項_.md)

[前項 　 ←](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第３項.md)    [→次項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項.md)



[目次](index法人税法施行規則.md)

