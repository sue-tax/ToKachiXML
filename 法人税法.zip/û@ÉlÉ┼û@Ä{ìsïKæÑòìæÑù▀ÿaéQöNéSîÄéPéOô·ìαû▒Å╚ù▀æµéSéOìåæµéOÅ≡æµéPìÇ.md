　
法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第１項

この省令は、公布の日から施行する。ただし、別表六<font color="lightsalmon"><font color="lightsalmon">（七）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同第二号の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十六）</font></font>の記載要領の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同表を別表六<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>とし、同表の前に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六<font color="darkkhaki"><font color="darkkhaki">（二十七）</font></font>を別表六<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>とする部分を除く。）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（四）</font></font>の記載要領第四号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十二）</font></font>の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定、同第二号の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十三）</font></font>の記載要領の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>付表の記載要領第三号<font color="lightsalmon"><font color="lightsalmon">（３）</font></font>の改正規定及び別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十四）</font></font>を別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>とし、同表の前に二表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十四）</font></font>を別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十五）</font></font>とする部分を除く。）</font></font>並びに附則第三項の規定は、特定高度情報通信技術活用システムの開発供給及び導入の促進に関する法律<font color="lightsalmon"><font color="lightsalmon">（令和二年法律第　　　号）</font></font>の施行の日から施行する。


--- ---

[条(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条_.md)  [項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第１項_.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第２項.md)



[目次](index法人税法施行規則.md)

