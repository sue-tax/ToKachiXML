　
法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第５項

新規則別表六<font color="lightsalmon"><font color="lightsalmon">（三十二）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十九）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十九）</font></font>付表、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>付表五、別表七の二付表六、別表十二<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>、別表十六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>及び別表十六<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>の書式は、法人の附則第一項第二号に定める日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条_.md)  [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第５項.md)

[前項(全)←](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項_.md)    [→次項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第６項_.md)

[前項 　 ←](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項.md)    [→次項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第６項.md)



[目次](index法人税法施行規則.md)

