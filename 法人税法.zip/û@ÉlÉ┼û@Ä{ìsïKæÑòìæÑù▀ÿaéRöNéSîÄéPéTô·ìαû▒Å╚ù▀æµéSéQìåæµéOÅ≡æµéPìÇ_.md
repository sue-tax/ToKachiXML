　
法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　別表十二<font color="lightsalmon"><font color="lightsalmon">（十三）</font></font>の記載要領第一号の改正規定　令和四年四月一日


二　第三十七条の九第二項の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「別表七の二付表五」</font></font>を<font color="peru"><font color="peru">「別表七の二付表六」</font></font>に改める部分に限る。）</font></font>、第三十七条の十一第二項の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「別表七の二付表五」</font></font>を<font color="peru"><font color="peru">「別表七の二付表六」</font></font>に改める部分に限る。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第４２条の１２の５の２第２項」</font></font>を<font color="peru"><font color="peru">「第４２条の１２の６第２項」</font></font>に、<font color="peru"><font color="peru">「又は」</font></font>を<font color="peru"><font color="peru">「、第４２条の１２の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font></font>に改める部分に限る。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（二十三）</font></font>の記載要領第三号の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>を別表六<font color="lightsalmon"><font color="lightsalmon">（三十一）</font></font>とし、同表の次に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>を別表六<font color="darkkhaki"><font color="darkkhaki">（三十一）</font></font>とする部分を除く。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「又は」</font></font>を<font color="peru"><font color="peru">「、第６８条の１５の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font></font>に改める部分に限る。）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>付表を別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>付表とし、同表の次に二表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十五）</font></font>付表を別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>付表とする部分を除く。）</font></font>、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号に係る部分を除く。）</font></font>、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>付表四の次に一表を加える改正規定、別表七の二付表一の記載要領の改正規定、別表七の二付表五の次に一表を加える改正規定、別表十二<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>の次に一表を加える改正規定、別表十六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の改正規定及び別表十六<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>の改正規定並びに附則第五項の規定　産業競争力強化法等の一部を改正する等の法律<font color="lightsalmon"><font color="lightsalmon">（令和三年法律第　　　号）</font></font>の施行の日


三　別表一の記載要領第九号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>ロの改正規定　マンションの管理の適正化の推進に関する法律及びマンションの建替え等の円滑化に関する法律の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和二年法律第六十二号）</font></font>の施行の日


四　別表十<font color="lightsalmon"><font color="lightsalmon">（七）</font></font>の改正規定及び別表十四<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>の記載要領第一号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第６６条の１１の２第１項」</font></font>を<font color="peru"><font color="peru">「第６６条の１１の３第１項」</font></font>に改める部分に限る。）</font></font>並びに附則第六項の規定　新型コロナウイルス感染症等の影響による社会経済情勢の変化に対応して金融の機能の強化及び安定の確保を図るための銀行法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和三年法律第　　　号）</font></font>の施行の日


--- ---


[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条_.md)  [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項.md)

[第１号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項第１号.md)  [第２号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項第２号.md)  [第３号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項第３号.md)  [第４号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項第４号.md)  

[目次](index法人税法施行規則.md)

