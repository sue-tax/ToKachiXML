　
法人税法施行規則附則平成１６年１２月２８日財務省令第８１号第０条

１　この省令は、破産法<font color="lightsalmon"><font color="lightsalmon">（平成十六年法律第七十五号）</font></font>の施行の日<font color="lightsalmon"><font color="lightsalmon">（平成十七年一月一日）</font></font>から施行する。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１６年１２月２８日財務省令第８１号第０条第１項_.md) 

[第１項 　 ](法人税法施行規則附則平成１６年１２月２８日財務省令第８１号第０条第１項.md) 

[目次](index法人税法施行規則.md)

