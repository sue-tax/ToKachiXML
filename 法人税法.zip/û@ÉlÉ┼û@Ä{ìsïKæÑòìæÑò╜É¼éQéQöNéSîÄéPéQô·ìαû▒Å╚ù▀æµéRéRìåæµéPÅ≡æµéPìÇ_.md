<font color="lightsalmon">（施行期日）</font>
法人税法施行規則附則平成２２年４月１２日財務省令第３３号第１条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第一条中法人税法施行規則第二十七条の十四の改正規定<font color="lightsalmon">（「別表十一<font color="darkkhaki">（一）</font>、別表十一<font color="darkkhaki">（二）</font>」を「別表十一<font color="darkkhaki">（一）</font>から別表十一<font color="darkkhaki">（二）</font>まで」に改める部分に限る。）</font>、同令別表一<font color="lightsalmon">（一）</font>の表の改正規定<font color="lightsalmon">（「残余財産の最後の分配又は引渡しの日」の欄に係る部分に限る。）</font>、同令別表一<font color="lightsalmon">（二）</font>の表の改正規定<font color="lightsalmon">（「残余財産の最後の分配又は引渡しの日」の欄に係る部分に限る。）</font>、同令別表三<font color="lightsalmon">（一）</font>の記載要領第三号の改正規定<font color="lightsalmon">（「　平成二十二年十月一日）</font>

二　第一条中法人税法施行規則別表六<font color="lightsalmon">（十）</font>の記載要領第三号の改正規定　石油代替エネルギーの開発及び導入の促進に関する法律等の一部を改正する法律<font color="lightsalmon">（平成二十一年法律第七十号）</font>の施行の日

--- ---


[条(全)](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第１条_.md)  [項](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第１条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~

[第１号](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第１条第１項第１号.md)  [第２号](法人税法施行規則附則平成２２年４月１２日財務省令第３３号第１条第１項第２号.md)  

[目次](index法人税法施行規則.md)

