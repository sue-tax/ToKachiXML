（仮決算をした場合の中間申告書の記載事項に関する経過措置）
法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の３

１　新法人税法施行規則第三十二条第二項の規定の適用については、同項に規定する中間申告書には、旧法人税法第八十一条の二十第一項各号に掲げる事項を記載する旧法人税法第二条第三十一号の二に規定する連結中間申告書<font color="lightsalmon">（当該申告書に係る修正申告書及び更正請求書を含む。）</font>を含むものとする。この場合において、新法人税法施行規則第三十二条第二項中「別表一、別表一付表、別表二、別表三<font color="lightsalmon">（二）</font>から別表三<font color="lightsalmon">（七）</font>まで、別表四、別表四付表、別表五<font color="lightsalmon">（一）</font>から別表五<font color="lightsalmon">（二）</font>まで、別表六<font color="lightsalmon">（一）</font>から別表六<font color="lightsalmon">（三十七）</font>まで、別表七<font color="lightsalmon">（一）</font>から別表七<font color="lightsalmon">（四）</font>付表まで、別表七の三から別表八<font color="lightsalmon">（三）</font>付表まで、別表九<font color="lightsalmon">（一）</font>から別表十<font color="lightsalmon">（九）</font>付表まで、別表十<font color="lightsalmon">（十一）</font>、別表十一<font color="lightsalmon">（一）</font>から別表十四<font color="lightsalmon">（十）</font>付表二まで、別表十五、別表十五付表、別表十六<font color="lightsalmon">（一）</font>から別表十七<font color="lightsalmon">（二の三）</font>付表まで、別表十七<font color="lightsalmon">（三の二）</font>から別表十七<font color="lightsalmon">（三の八）</font>まで及び別表十八<font color="lightsalmon">（一）</font>から別表十八<font color="lightsalmon">（三）</font>まで<font color="lightsalmon">（更正請求書にあつては、別表一を除く。）</font>」とあるのは、「別表一から別表一の二まで、別表二、別表三<font color="lightsalmon">（二）</font>から別表三<font color="lightsalmon">（七）</font>まで、別表四から別表五の二<font color="lightsalmon">（一）</font>付表一まで、別表五の二<font color="lightsalmon">（二）</font>から別表六の二<font color="lightsalmon">（二十七）</font>まで、別表七<font color="lightsalmon">（一）</font>から別表七<font color="lightsalmon">（四）</font>付表まで、別表七の二から別表十<font color="lightsalmon">（九）</font>付表まで、別表十<font color="lightsalmon">（十一）</font>から別表十七<font color="lightsalmon">（二の三）</font>付表まで、別表十七<font color="lightsalmon">（三の二）</font>から別表十七<font color="lightsalmon">（三の八）</font>まで、別表十七の二<font color="lightsalmon">（一）</font>から別表十七の二<font color="lightsalmon">（二）</font>付表二まで及び別表十八<font color="lightsalmon">（一）</font>から別表十八<font color="lightsalmon">（三）</font>まで<font color="lightsalmon">（更正請求書にあつては、別表一及び別表一の二を除く。）</font>」とする。

２　新法人税法施行規則第三十二条第二項ただし書の規定の適用については、同項ただし書に規定する場合には連結法人が旧法人税法第八十一条の三第一項に規定する個別損金額を計算する場合の法人税法施行令第六十三条第二項又は第六十七条第二項の規定の適用を受ける場合を含むものとし、新法人税法施行規則第三十二条第二項ただし書に規定する明細書には連結法人が旧法人税法第八十一条の三第一項に規定する個別損金額を計算する場合の法人税法施行令第六十三条第二項又は第六十七条第二項に規定する明細書を含むものとする。

--- ---

[前条(全)←](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の２_.md)    [→次条(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の４_.md)

[第１項(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の３第１項_.md) [第２項(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の３第２項_.md) 

[第１項 　 ](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の３第１項.md) [第２項 　 ](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の３第２項.md) 

[目次](index法人税法施行規則.md)

