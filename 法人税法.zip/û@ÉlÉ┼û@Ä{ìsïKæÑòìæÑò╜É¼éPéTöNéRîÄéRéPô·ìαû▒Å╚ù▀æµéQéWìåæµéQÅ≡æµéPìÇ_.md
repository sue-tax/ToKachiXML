<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲に関する経過措置）</font></font>
法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項

法人税法施行令の一部を改正する政令<font color="lightsalmon"><font color="lightsalmon">（平成十五年政令第百三十一号）</font></font>附則第四条第二項<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲に関する経過措置）</font></font>の規定によりなおその効力を有するものとされる同令による改正前の法人税法施行令第五条第一項第一号イ<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲）</font></font>の適用については、改正前の法人税法施行規則第四条<font color="lightsalmon"><font color="lightsalmon">（学校給食用の物資の範囲）</font></font>の規定は、なおその効力を有する。


--- ---


[条(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条_.md)  [項](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項.md)



[目次](index法人税法施行規則.md)

