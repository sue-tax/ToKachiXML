<font color="lightsalmon"><font color="lightsalmon">（法人税法施行規則等の一部改正に伴う経過措置の原則）</font></font>
法人税法施行規則附則令和２年６月３０日財務省令第５６号第２条第１項

別段の定めがあるものを除き、第一条の規定による改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新法人税法施行規則」</font></font>という。）</font></font>、第二条の規定による改正後の地方法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（附則第十一条において<font color="peru"><font color="peru">「新地方法人税法施行規則」</font></font>という。）</font></font>、第三条の規定による改正後の租税特別措置法施行規則<font color="lightsalmon"><font color="lightsalmon">（附則第十二条において<font color="peru"><font color="peru">「新租税特別措置法施行規則」</font></font>という。）</font></font>、第四条の規定による改正後の東日本大震災の被災者等に係る国税関係法律の臨時特例に関する法律施行規則<font color="lightsalmon"><font color="lightsalmon">（附則第十四条において<font color="peru"><font color="peru">「新震災特例法施行規則」</font></font>という。）</font></font>、第七条の規定による改正後の減価償却資産の耐用年数等に関する省令、第九条の規定による改正後の租税条約等の実施に伴う所得税法、法人税法及び地方税法の特例等に関する法律の施行に関する省令及び第十八条の規定による改正後の法人税法施行規則の一部を改正する省令の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下附則第十条までにおいて同じ。）</font></font>のこの省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に開始する事業年度<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号。以下<font color="peru"><font color="peru">「改正法」</font></font>という。）</font></font>附則第十四条第一項に規定する旧事業年度<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「旧事業年度」</font></font>という。）</font></font>を除く。）</font></font>の所得に対する法人税及び施行日以後に開始する課税事業年度<font color="lightsalmon"><font color="lightsalmon">（旧事業年度を除く。）</font></font>の基準法人税額に対する地方法人税について適用する。


--- ---

[条(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第２条_.md)  [項(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第２条第１項_.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第２条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則令和２年６月３０日財務省令第５６号第２条第２項.md)



[目次](index法人税法施行規則.md)

