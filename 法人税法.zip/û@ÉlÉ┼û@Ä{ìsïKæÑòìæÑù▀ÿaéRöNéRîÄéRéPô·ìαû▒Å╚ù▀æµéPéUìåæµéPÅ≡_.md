（施行期日）
法人税法施行規則附則令和３年３月３１日財務省令第１６号第１条

１　この省令は、令和三年四月一日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　別表十七<font color="lightsalmon"><font color="lightsalmon">（二の二）</font></font>付表二の記載要領の改正規定、別表十七<font color="lightsalmon"><font color="lightsalmon">（二の五）</font></font>の記載要領第六号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>の改正規定、別表十七<font color="lightsalmon"><font color="lightsalmon">（二の五）</font></font>付表の記載要領の改正規定、別表十七の二<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>付表二の記載要領の改正規定、別表十七の二<font color="lightsalmon"><font color="lightsalmon">（四）</font></font>の記載要領の改正規定及び別表十七の二<font color="lightsalmon"><font color="lightsalmon">（四）</font></font>付表の記載要領の改正規定　令和三年三月三十一日


二　第三十六条の三の二第一項の改正規定、同条第七項の改正規定、第三十七条の十五の二第一項の改正規定及び同条第七項の改正規定　令和四年一月一日


三　第二十二条の四第六号の改正規定　マンションの管理の適正化の推進に関する法律及びマンションの建替え等の円滑化に関する法律の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和二年法律第六十二号）</font></font>の施行の日


--- ---

~~前条(全)←~~　  [→次条(全)](法人税法施行規則附則令和３年３月３１日財務省令第１６号第２条_.md)

[第１項(全)](法人税法施行規則附則令和３年３月３１日財務省令第１６号第１条第１項_.md) 

[第１項 　 ](法人税法施行規則附則令和３年３月３１日財務省令第１６号第１条第１項.md) 

[目次](index法人税法施行規則.md)

