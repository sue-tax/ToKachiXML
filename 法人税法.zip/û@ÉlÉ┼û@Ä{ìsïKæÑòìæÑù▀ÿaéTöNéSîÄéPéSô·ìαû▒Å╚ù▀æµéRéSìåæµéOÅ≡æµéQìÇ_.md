　
法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表十九の二の書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下同じ。）</font></font>の令和五年四月一日以後に終了する事業年度の所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号）</font></font>第三条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「令和二年旧法」</font></font>という。）</font></font>第二条第十二号の七の二に規定する連結法人をいう。）</font></font>の同日前に終了した連結事業年度<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第十五条の二第一項に規定する連結事業年度をいう。）</font></font>の連結所得<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十八号の四に規定する連結所得をいう。）</font></font>に対する法人税については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条_.md)  [項](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第２項.md)

[前項(全)←](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第１項_.md)    [→次項(全)](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第３項_.md)

[前項 　 ←](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第１項.md)    [→次項 　 ](法人税法施行規則附則令和５年４月１４日財務省令第３４号第０条第３項.md)



[目次](index法人税法施行規則.md)

