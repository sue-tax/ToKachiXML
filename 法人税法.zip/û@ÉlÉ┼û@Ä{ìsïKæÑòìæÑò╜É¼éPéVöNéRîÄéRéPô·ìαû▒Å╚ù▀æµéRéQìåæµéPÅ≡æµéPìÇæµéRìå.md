<font color="lightsalmon"><font color="lightsalmon">（施行期日）</font></font>
[法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項)第３号

第二十七条の十四第二号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第二十一条の十三第二項第五号」</font></font>を<font color="peru"><font color="peru">「第二十一条の十二第二項第五号」</font></font>に、<font color="peru"><font color="peru">「第二十一条の十三の二第五号」</font></font>を<font color="peru"><font color="peru">「第二十一条の十三第五号」</font></font>に改める部分に限る。）</font></font>　原子力発電における使用済燃料の再処理等のための積立金の積立て及び管理に関する法律<font color="lightsalmon"><font color="lightsalmon">（平成十七年法律第四十八号）</font></font>の施行の日


--- ---

[条(全)](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条_.md)    [項(全)](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項_.md)    [項](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項.md)

[前号←](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項第２号.md)  ~~→次号~~

[目次](index法人税法施行規則.md)

