<font color="lightsalmon"><font color="lightsalmon">（税額控除不足額相当額の控除を受けるための書類等に関する経過措置）</font></font>
法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条第１項

内国法人の施行日前に開始した事業年度<font color="lightsalmon"><font color="lightsalmon">（旧事業年度を含む。）</font></font>に連結事業年度に該当するものがある場合における新法人税法施行規則第三十条の二第一項及び第三項<font color="lightsalmon"><font color="lightsalmon">（これらの規定を法人税法施行規則第三十条の五において準用する場合を含む。）</font></font>の規定の適用については、新法人税法施行規則第三十条の二第一項第三号中<font color="peru"><font color="peru">「第二十九条の四第一項各号」</font></font>とあるのは<font color="peru"><font color="peru">「法人税法施行規則等の一部を改正する省令（令和二年財務省令第五十六号）附則第六条（外国税額控除を受けるための書類等に関する経過措置）の規定により読み替えられた第二十九条の四第一項各号」</font></font>と、<font color="peru"><font color="peru">「前条第一項第二号」</font></font>とあるのは<font color="peru"><font color="peru">「同令附則第七条第一項（繰越し又は繰戻しによる外国税額の控除を受けるための書類等に関する経過措置）の規定により読み替えられた前条第一項第二号」</font></font>と、同項第五号中<font color="peru"><font color="peru">「係る事業年度」</font></font>とあるのは<font color="peru"><font color="peru">「係る事業年度又は連結事業年度（所得税法等の一部を改正する法律（令和二年法律第八号）第三条の規定による改正前の法人税法（以下この号及び第三項第三号において「旧法人税法」という。）第十五条の二（連結事業年度の意義）に規定する連結事業年度をいう。以下この号において同じ。）」</font></font>と、<font color="peru"><font color="peru">「以後の各事業年度」</font></font>とあるのは<font color="peru"><font color="peru">「又は連結事業年度以後の各事業年度又は各連結事業年度」</font></font>と、<font color="peru"><font color="peru">「の控除限度額」</font></font>とあるのは<font color="peru"><font color="peru">「の控除限度額又は連結控除限度個別帰属額（旧法人税法第八十一条の十五第一項（連結事業年度における外国税額の控除）に規定する連結控除限度個別帰属額をいう。第三項第二号において同じ。）」</font></font>と、<font color="peru"><font color="peru">「を記載した」</font></font>とあるのは<font color="peru"><font color="peru">「又は個別控除対象外国法人税の額（旧法人税法第八十一条の十五第一項に規定する個別控除対象外国法人税の額をいう。第三項第三号において同じ。）を記載した」</font></font>と、同条第三項第二号中<font color="peru"><font color="peru">「の控除限度額」</font></font>とあるのは<font color="peru"><font color="peru">「の控除限度額又は連結控除限度個別帰属額」</font></font>と、同項第三号中<font color="peru"><font color="peru">「金額）」</font></font>とあるのは<font color="peru"><font color="peru">「金額）又は個別控除対象外国法人税の額（当該繰越控除限度額等に係る各事業年度において旧法人税法第八十一条の十五第八項の規定の適用があつた場合には、法人税法施行令等の一部を改正する政令（令和二年政令第二百七号）第一条の規定による改正前の法人税法施行令第百五十五条の三十五第一項（連結事業年度において外国法人税が減額された場合の特例）に規定する控除後の金額）」</font></font>とする。


--- ---

[条(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条_.md)  [項(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条第１項_.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index法人税法施行規則.md)

