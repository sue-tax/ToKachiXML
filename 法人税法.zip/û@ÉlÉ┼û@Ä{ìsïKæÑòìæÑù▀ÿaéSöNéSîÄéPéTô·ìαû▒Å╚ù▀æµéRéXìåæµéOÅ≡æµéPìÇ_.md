　
法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　別表一の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分及び同号<font color="darkkhaki"><font color="darkkhaki">（５）</font></font>に係る部分を除く。）</font></font>、別表一の二の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分を除く。）</font></font>、別表一の三の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号に係る部分を除く。）</font></font>及び別表二十の表の改正規定　令和四年十二月三十一日


二　別表十二<font color="lightsalmon"><font color="lightsalmon">（十四）</font></font>の記載要領第一号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「は、青色申告書を提出する法人で」</font></font>の次に<font color="peru"><font color="peru">「租税特別措置法第６１条の２第１項（農業経営基盤強化準備金）に規定する認定農地所有適格法人に該当するものが同条の規定の適用を受ける場合、青色申告書を提出する法人で所得税法等の一部を改正する法律（令和４年法律第４号）第１１条の規定による改正前の」</font></font>を加える部分に限る。）</font></font>　農業経営基盤強化促進法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和四年法律第　　　号）</font></font>の施行の日


--- ---


[条(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条_.md)  [項](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第２項.md)

[第１号](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項第１号.md)  [第２号](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項第２号.md)  

[目次](index法人税法施行規則.md)

