　
[法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項)第１号

別表一の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分及び同号<font color="darkkhaki"><font color="darkkhaki">（５）</font></font>に係る部分を除く。）</font></font>、別表一の二の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号<font color="darkkhaki"><font color="darkkhaki">（２）</font></font>に係る部分を除く。）</font></font>、別表一の三の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号に係る部分を除く。）</font></font>及び別表二十の表の改正規定　令和四年十二月三十一日


--- ---

[条(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条_.md)    [項(全)](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項_.md)    [項](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項.md)

~~前号←~~　  [→次号](法人税法施行規則附則令和４年４月１５日財務省令第３９号第０条第１項第２号.md)

[目次](index法人税法施行規則.md)

