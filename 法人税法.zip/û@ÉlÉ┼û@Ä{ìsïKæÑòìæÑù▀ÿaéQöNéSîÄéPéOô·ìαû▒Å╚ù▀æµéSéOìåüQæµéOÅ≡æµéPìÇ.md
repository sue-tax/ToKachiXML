　
法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第１項

この省令は、公布の日から施行する。ただし、別表六<font color="lightsalmon">（七）</font>の記載要領[第四号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第４号)<font color="lightsalmon">（３）</font>の改正規定、別表六<font color="lightsalmon">（二十五）</font>の記載要領[第三号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第３号)<font color="lightsalmon">（３）</font>の改正規定、同[第二号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第２号)の改正規定、別表六<font color="lightsalmon">（二十六）</font>の記載要領の改正規定、別表六<font color="lightsalmon">（二十七）</font>の記載要領[第四号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第４号)<font color="lightsalmon">（３）</font>の改正規定、同表を別表六<font color="lightsalmon">（二十八）</font>とし、同表の前に一表を加える改正規定<font color="lightsalmon">（別表六<font color="darkkhaki">（二十七）</font>を別表六<font color="darkkhaki">（二十八）</font>とする部分を除く。）</font>、別表六の二<font color="lightsalmon">（四）</font>の記載要領[第四号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第４号)<font color="lightsalmon">（３）</font>の改正規定、別表六の二<font color="lightsalmon">（二十二）</font>の記載要領[第三号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第３号)<font color="lightsalmon">（３）</font>の改正規定、同[第二号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第２号)の改正規定、別表六の二<font color="lightsalmon">（二十三）</font>の記載要領の改正規定、別表六の二<font color="lightsalmon">（二十四）</font>付表の記載要領[第三号](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項第３号)<font color="lightsalmon">（３）</font>の改正規定及び別表六の二<font color="lightsalmon">（二十四）</font>を別表六の二<font color="lightsalmon">（二十五）</font>とし、同表の前に二表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（二十四）</font>を別表六の二<font color="darkkhaki">（二十五）</font>とする部分を除く。）</font>並びに附則[第三項](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第３項)の規定は、特定高度情報通信技術活用システムの開発供給及び導入の促進に関する法律<font color="lightsalmon">（令和二年法律第　　　号）</font>の施行の日から施行する。

--- ---

[条(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条_.md)  [項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第１項_.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則令和２年４月１０日財務省令第４０号＿第０条第２項.md)



[目次](index法人税法施行規則.md)

