<font color="lightsalmon"><font color="lightsalmon">（中間申告書の記載事項に関する経過措置）</font></font>
法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の２第１項

新法人税法施行規則第三十一条第二項の規定の適用については、同項に規定する中間申告書には、旧法人税法第八十一条の十九第一項各号に掲げる事項を記載する旧法人税法第二条第三十一号の二に規定する連結中間申告書<font color="lightsalmon"><font color="lightsalmon">（当該申告書に係る修正申告書を含む。）</font></font>を含むものとする。この場合において、新法人税法施行規則第三十一条第二項中<font color="peru"><font color="peru">「別表十九」</font></font>とあるのは<font color="peru"><font color="peru">「別表十九及び別表十九の二」</font></font>と、<font color="peru"><font color="peru">「同表」</font></font>とあるのは<font color="peru"><font color="peru">「これらの表」</font></font>とする。


--- ---


[条(全)](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の２_.md)  [項](法人税法施行規則附則令和２年６月３０日財務省令第５６号第８条の２第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index法人税法施行規則.md)

