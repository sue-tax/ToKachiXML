　
法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>の規定及び新規則別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表六<font color="darkkhaki"><font color="darkkhaki">（六）</font></font>から別表六<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>まで、別表六の二<font color="darkkhaki"><font color="darkkhaki">（三）</font></font>から別表六の二<font color="darkkhaki"><font color="darkkhaki">（五）</font></font>付表二まで及び別表七から別表七の二付表二までの書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十五年四月一日以後に終了する事業年度の所得に対する法人税、連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日以後に終了する計算期間の所得に対する法人税、法人の同日以後に終了する事業年度の退職年金等積立金に対する法人税及び法人の同日以後の解散<font color="lightsalmon"><font color="lightsalmon">（合併による解散を除く。以下この項において同じ。）</font></font>による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の事業年度の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下この項において同じ。）</font></font>について適用し、法人の同日前に終了した事業年度の所得に対する法人税、連結法人の同日前に終了した連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日前に終了した計算期間の所得に対する法人税、法人の同日前に終了した事業年度の退職年金等積立金に対する法人税及び法人の同日前の解散による清算所得に対する法人税については、なお従前の例による。


--- ---

[条(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条_.md)  [項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第２項_.md)

[前項(全)←](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第１項_.md)    [→次項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第１項.md)    [→次項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第３項.md)



[目次](index法人税法施行規則.md)

