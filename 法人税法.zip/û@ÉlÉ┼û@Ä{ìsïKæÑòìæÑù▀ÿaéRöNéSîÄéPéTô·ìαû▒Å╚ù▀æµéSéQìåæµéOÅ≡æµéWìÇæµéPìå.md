　
[法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項)第１号

新規則別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の書式　同表の記載要領第二号中<font color="peru"><font color="peru">「第２７条の１２の５第１５項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第１５項」</font></font>と、同第三号中<font color="peru"><font color="peru">「第２７条の１２の５第６項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第６項第２号イ」</font></font>と、<font color="peru"><font color="peru">「第２７条の１２の５第５項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第５項第２号イ」</font></font>と、同第四号中<font color="peru"><font color="peru">「第２７条の１２の５第７項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第７項」</font></font>と、同号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「第２７条の１２の５第２１項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第２１項」</font></font>とする。


--- ---

[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条_.md)    [項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項_.md)    [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項.md)

~~前号←~~　  [→次号](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項第２号.md)

[目次](index法人税法施行規則.md)

