　
法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条

１　この省令は、平成十年四月一日から施行する。ただし、第五十九条第五項及び第六十七条第五項の改正規定は、同年七月一日から施行する。


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第八条の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>のこの省令の施行の日<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「施行日」</font></font>という。）</font></font>以後に終了する事業年度の所得に対する法人税について適用し、法人の施行日前に終了した事業年度の所得に対する法人税については、なお従前の例による。この場合において、理容師法及び美容師法の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（平成七年法律第百九号）</font></font>附則第四条第二項の規定により厚生大臣の指定がなおその効力を有することとされる施設に係る新令第五条第一項第三十号ニの規定の適用については、なお従前の例による。


３　新規則別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表十一<font color="darkkhaki"><font color="darkkhaki">（一の二）</font></font>、別表十二<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>、別表十二<font color="darkkhaki"><font color="darkkhaki">（十九）</font></font>及び別表十六<font color="darkkhaki"><font color="darkkhaki">（六）</font></font>の書式を除く。）</font></font>は、法人の施行日以後に終了する事業年度の所得及び施行日以後の解散又は合併による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下同じ。）</font></font>について適用し、法人の施行日前に終了した事業年度の所得及び施行日前の解散又は合併による清算所得に対する法人税については、なお従前の例による。


４　新規則別表十一<font color="lightsalmon"><font color="lightsalmon">（一の二）</font></font>、別表十二<font color="lightsalmon"><font color="lightsalmon">（十九）</font></font>及び別表十六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の書式は、法人の施行日以後に開始する事業年度の所得に対する法人税について適用する。


５　新規則別表十二<font color="lightsalmon"><font color="lightsalmon">（八）</font></font>の書式は、法人の平成十年六月十七日以後に終了する事業年度の所得に対する法人税について適用する。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第１項_.md) [第２項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項_.md) [第３項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項_.md) [第４項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第４項_.md) [第５項(全)](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第５項_.md) 

[第１項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第１項.md) [第２項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第２項.md) [第３項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第３項.md) [第４項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第４項.md) [第５項 　 ](法人税法施行規則附則平成１０年３月３１日大蔵省令第４５号第０条第５項.md) 

[目次](index法人税法施行規則.md)

