<font color="lightsalmon"><font color="lightsalmon">（施行期日）</font></font>
[法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条第１項](法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条第１項)第２号

次に掲げる規定　令和五年一月一日

イ　第一条中法人税法施行規則目次の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「一括償却資産」</font></font>を<font color="peru"><font color="peru">「少額の減価償却資産等」</font></font>に、<font color="peru"><font color="peru">「第三十条の四」</font></font>を<font color="peru"><font color="peru">「第三十条の五」</font></font>に改める部分を除く。）</font></font>、同令第二編第一章第一節第六款の二の次に一款を加える改正規定、同令第三十六条の四第一項の改正規定及び同令第六十条の四の改正規定


--- ---

[条(全)](法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条_.md)    [項(全)](法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条第１項_.md)    [項](法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条第１項.md)

[前号←](法人税法施行規則附則令和４年３月３１日財務省令第１４号第１条第１項第１号.md)  ~~→次号~~

[目次](index法人税法施行規則.md)

