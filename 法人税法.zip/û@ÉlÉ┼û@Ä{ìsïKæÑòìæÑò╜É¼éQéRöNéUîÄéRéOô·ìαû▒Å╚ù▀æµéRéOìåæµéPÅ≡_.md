（施行期日）
法人税法施行規則附則平成２３年６月３０日財務省令第３０号第１条

１　この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　別表六<font color="lightsalmon">（二十三）</font>を別表六<font color="lightsalmon">（二十四）</font>とし、同表の次に三表を加える改正規定<font color="lightsalmon">（別表六<font color="darkkhaki">（二十五）</font>に係る部分に限る。）</font>、別表六の二<font color="lightsalmon">（十二）</font>付表を別表六の二<font color="lightsalmon">（十三）</font>付表とし、同表の次に四表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（十四）</font>及び別表六の二<font color="darkkhaki">（十四）</font>付表に係る部分に限る。）</font>、別表十<font color="lightsalmon">（一）</font>の次に二表を加える改正規定<font color="lightsalmon">（別表十<font color="darkkhaki">（二）</font>に係る部分に限る。）</font>及び別表十八の記載要領第四号の改正規定<font color="lightsalmon">（「第４２条の６第５項」を「第４２条の５の２第５項<font color="darkkhaki">（連結納税の承認を取り消された場合のエネルギー環境負荷低減推進設備等に係る法人税額）</font>、第４２条の６第５項」に改める部分及び「第６８条の１１第５項」を「第６８条の１０の２第５項<font color="darkkhaki">（連結納税の承認を取り消された場合のエネルギー環境負荷低減推進設備等に係る法人税額）</font>、第６８条の１１第５項」に改める部分を除く。）</font>並びに附則第九条第二項の規定　総合特別区域法<font color="lightsalmon">（平成二十三年法律第八十一号）</font>の施行の日

二　別表十<font color="lightsalmon">（一）</font>の次に二表を加える改正規定<font color="lightsalmon">（別表十<font color="darkkhaki">（二）</font>に係る部分を除く。）</font>及び附則第九条第五項の規定　特定多国籍企業による研究開発事業等の促進に関する特別措置法<font color="lightsalmon">（平成二十四年法律第五十五号）</font>の施行の日

--- ---

~~前条(全)←~~　  [→次条(全)](法人税法施行規則附則平成２３年６月３０日財務省令第３０号第２条_.md)

[第１項(全)](法人税法施行規則附則平成２３年６月３０日財務省令第３０号第１条第１項_.md) 

[第１項 　 ](法人税法施行規則附則平成２３年６月３０日財務省令第３０号第１条第１項.md) 

[目次](index法人税法施行規則.md)

