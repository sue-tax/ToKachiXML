　
法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　別表五<font color="lightsalmon">（一）</font>の記載要領第三号の改正規定、別表五の二<font color="lightsalmon">（一）</font>付表一の記載要領第三号の改正規定及び別表十四<font color="lightsalmon">（七）</font>の改正規定並びに附則第十項の規定　平成二十八年九月一日

二　別表一<font color="lightsalmon">（一）</font>の表の改正規定<font color="lightsalmon">（「課税留保金額　<font color="darkkhaki">（８）</font>」及び「同上に対する税額　<font color="darkkhaki">（９）</font>」の欄に係る部分に限る。）</font>、別表一の二<font color="lightsalmon">（一）</font>の表の改正規定<font color="lightsalmon">（「課税連結留保金額　<font color="darkkhaki">（８）</font>」及び「同上に対する税額　<font color="darkkhaki">（９）</font>」の欄に係る部分に限る。）</font>、別表三<font color="lightsalmon">（一）</font>の表の改正規定、同表の記載要領第三号の改正規定、同第五号<font color="lightsalmon">（１）</font>の改正規定、同号<font color="lightsalmon">（３）</font>の改正規定、同第六号の改正規定、別表三の二の改正規定、別表三の二付表の表の改正規定、同表の記載要領第五号の改正規定、同第六号の改正規定、同第七号<font color="lightsalmon">（２）</font>及び<font color="lightsalmon">（３）</font>の改正規定、同第九号及び第十号の改正規定、別表五<font color="lightsalmon">（二）</font>の記載要領第二号の改正規定、別表六<font color="lightsalmon">（十七）</font>を別表六<font color="lightsalmon">（十五）</font>とし、同表の次に三表を加える改正規定<font color="lightsalmon">（別表六<font color="darkkhaki">（十七）</font>に係る部分に限る。）</font>並びに別表六の二<font color="lightsalmon">（十五）</font>付表二を別表六の二<font color="lightsalmon">（十三）</font>付表二とし、同表の次に二表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（十五）</font>付表二を別表六の二<font color="darkkhaki">（十三）</font>付表二とする部分を除く。）</font>並びに附則第五項の規定　地域再生法の一部を改正する法律<font color="lightsalmon">（平成二十八年法律第　　　号）</font>の施行の日

--- ---


[条(全)](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条_.md)  [項](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第２項.md)

[第１号](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第１項第１号.md)  [第２号](法人税法施行規則附則平成２８年４月１５日財務省令第４１号第０条第１項第２号.md)  

[目次](index法人税法施行規則.md)

