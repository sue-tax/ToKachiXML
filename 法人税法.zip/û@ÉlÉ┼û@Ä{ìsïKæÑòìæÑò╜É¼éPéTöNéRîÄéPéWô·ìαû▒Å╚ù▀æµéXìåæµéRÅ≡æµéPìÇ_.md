<font color="lightsalmon"><font color="lightsalmon">（書式に関する経過措置）</font></font>
法人税法施行規則附則平成１５年３月１８日財務省令第９号第３条第１項

改正前の法人税法施行規則に定める書式<font color="lightsalmon"><font color="lightsalmon">（同規則別表八、別表十一<font color="darkkhaki"><font color="darkkhaki">（三）</font></font>及び別表十一<font color="darkkhaki"><font color="darkkhaki">（四）</font></font>の書式を除く。）</font></font>は、平成十五年三月三十一日に終了する事業年度の所得に対する法人税の申告又は計算期間の所得に対する法人税の申告を行う場合において、所要の調整をして使用することができる。


--- ---


[条(全)](法人税法施行規則附則平成１５年３月１８日財務省令第９号第３条_.md)  [項](法人税法施行規則附則平成１５年３月１８日財務省令第９号第３条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index法人税法施行規則.md)

