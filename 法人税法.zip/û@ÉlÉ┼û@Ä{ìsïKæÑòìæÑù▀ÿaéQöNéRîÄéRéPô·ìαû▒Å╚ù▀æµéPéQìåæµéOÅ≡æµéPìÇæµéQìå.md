　
[法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条第１項](法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条第１項)第２号

第二十六条の二第一項第五号の改正規定、第二十六条の九第九号の改正規定、第二十六条の十<font color="lightsalmon"><font color="lightsalmon">（見出しを含む。）</font></font>の改正規定<font color="lightsalmon"><font color="lightsalmon">（同条第一号中<font color="peru"><font color="peru">「第百十八条の八第三号」</font></font>を<font color="peru"><font color="peru">「第百十八条の八第一項第三号」</font></font>に、<font color="peru"><font color="peru">「価格」</font></font>を<font color="peru"><font color="peru">「金額」</font></font>に改める部分を除く。）</font></font>及び第二十七条の十五第一項第五号の改正規定　情報通信技術の進展に伴う金融取引の多様化に対応するための資金決済に関する法律等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和元年法律第二十八号）</font></font>の施行の日


--- ---

[条(全)](法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条_.md)    [項(全)](法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条第１項_.md)    [項](法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条第１項.md)

[前号←](法人税法施行規則附則令和２年３月３１日財務省令第１２号第０条第１項第１号.md)  ~~→次号~~

[目次](index法人税法施行規則.md)

