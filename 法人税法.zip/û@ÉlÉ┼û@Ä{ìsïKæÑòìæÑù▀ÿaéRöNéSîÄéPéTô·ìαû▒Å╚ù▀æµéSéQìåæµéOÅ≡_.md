　
法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条

１　この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　別表十二<font color="lightsalmon"><font color="lightsalmon">（十三）</font></font>の記載要領第一号の改正規定　令和四年四月一日


二　第三十七条の九第二項の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「別表七の二付表五」</font></font>を<font color="peru"><font color="peru">「別表七の二付表六」</font></font>に改める部分に限る。）</font></font>、第三十七条の十一第二項の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「別表七の二付表五」</font></font>を<font color="peru"><font color="peru">「別表七の二付表六」</font></font>に改める部分に限る。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第４２条の１２の５の２第２項」</font></font>を<font color="peru"><font color="peru">「第４２条の１２の６第２項」</font></font>に、<font color="peru"><font color="peru">「又は」</font></font>を<font color="peru"><font color="peru">「、第４２条の１２の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font></font>に改める部分に限る。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（二十三）</font></font>の記載要領第三号の改正規定、別表六<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>を別表六<font color="lightsalmon"><font color="lightsalmon">（三十一）</font></font>とし、同表の次に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>を別表六<font color="darkkhaki"><font color="darkkhaki">（三十一）</font></font>とする部分を除く。）</font></font>、別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「又は」</font></font>を<font color="peru"><font color="peru">「、第６８条の１５の７第４項から第６項まで（事業適応設備を取得した場合等の法人税額の特別控除）又は」</font></font>に改める部分に限る。）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十五）</font></font>付表を別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>付表とし、同表の次に二表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十五）</font></font>付表を別表六の二<font color="darkkhaki"><font color="darkkhaki">（二十八）</font></font>付表とする部分を除く。）</font></font>、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>の記載要領の改正規定<font color="lightsalmon"><font color="lightsalmon">（同第四号に係る部分を除く。）</font></font>、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>付表四の次に一表を加える改正規定、別表七の二付表一の記載要領の改正規定、別表七の二付表五の次に一表を加える改正規定、別表十二<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>の次に一表を加える改正規定、別表十六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の改正規定及び別表十六<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>の改正規定並びに附則第五項の規定　産業競争力強化法等の一部を改正する等の法律<font color="lightsalmon"><font color="lightsalmon">（令和三年法律第　　　号）</font></font>の施行の日


三　別表一の記載要領第九号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>ロの改正規定　マンションの管理の適正化の推進に関する法律及びマンションの建替え等の円滑化に関する法律の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和二年法律第六十二号）</font></font>の施行の日


四　別表十<font color="lightsalmon"><font color="lightsalmon">（七）</font></font>の改正規定及び別表十四<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>の記載要領第一号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第６６条の１１の２第１項」</font></font>を<font color="peru"><font color="peru">「第６６条の１１の３第１項」</font></font>に改める部分に限る。）</font></font>並びに附則第六項の規定　新型コロナウイルス感染症等の影響による社会経済情勢の変化に対応して金融の機能の強化及び安定の確保を図るための銀行法等の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（令和三年法律第　　　号）</font></font>の施行の日


２　別段の定めがあるものを除き、改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式は、法人<font color="lightsalmon"><font color="lightsalmon">（人格のない社団等を含む。以下同じ。）</font></font>の令和三年四月一日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


３　次の各号に掲げる書式により令和三年四月一日前に終了した事業年度の所得に対する法人税又は同日前に終了した連結事業年度<font color="lightsalmon"><font color="lightsalmon">（所得税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（令和二年法律第八号）</font></font>第三条の規定による改正前の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「令和二年旧法」</font></font>という。）</font></font>第十五条の二第一項に規定する連結事業年度をいう。）</font></font>の連結所得<font color="lightsalmon"><font color="lightsalmon">（令和二年旧法第二条第十八号の四に規定する連結所得をいう。）</font></font>に対する法人税について同日以後に確定申告書又は同条第三十二号に規定する連結確定申告書<font color="lightsalmon"><font color="lightsalmon">（これらの申告書に係る修正申告書を含む。）</font></font>の提出をする場合には、当該各号に定めるところによる。


一　前項の規定によりなお従前の例によることとされる場合における改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「旧規則」</font></font>という。）</font></font>別表一若しくは別表一の二の書式、法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（令和二年財務省令第四十号。以下<font color="peru"><font color="peru">「令和二年改正規則」</font></font>という。）</font></font>附則第二項の規定によりなお従前の例によることとされる場合における令和二年改正規則による改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「令和二年旧規則」</font></font>という。）</font></font>別表一若しくは別表一の二の書式又は法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成三十一年財務省令第三十一号。以下<font color="peru"><font color="peru">「平成三十一年改正規則」</font></font>という。）</font></font>附則第二項の規定によりなお従前の例によることとされる場合における平成三十一年改正規則による改正前の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「平成三十一年旧規則」</font></font>という。）</font></font>別表一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>から別表一の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>までの書式　これらの表の表中「


二　法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成三十年財務省令第三十五号。以下<font color="peru"><font color="peru">「平成三十年改正規則」</font></font>という。）</font></font>附則第二項その他これに類する法人税法施行規則別表の書式を改正する省令の経過措置を定める規定によりなお従前の例によることとされる場合におけるこれらの省令による改正前の法人税法施行規則別表一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>から別表一の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>までの書式<font color="lightsalmon"><font color="lightsalmon">（前号に掲げる書式を除く。）</font></font>　平成三十年改正規則附則第三項の規定にかかわらず、これらの表の表中「


４　次の各号に掲げる書式により令和三年四月一日前に終了した事業年度の所得に対する法人税について同日以後に確定申告書<font color="lightsalmon"><font color="lightsalmon">（当該確定申告書に係る修正申告書を含む。）</font></font>の提出をする場合には、当該各号に定めるところによる。


一　第二項の規定によりなお従前の例によることとされる場合における旧規則別表一の三の書式、令和二年改正規則附則第二項の規定によりなお従前の例によることとされる場合における令和二年旧規則別表一の三の書式又は平成三十一年改正規則附則第二項の規定によりなお従前の例によることとされる場合における平成三十一年旧規則別表一の三の書式　これらの表の表中「


二　平成三十年改正規則附則第二項の規定によりなお従前の例によることとされる場合における平成三十年改正規則による改正前の法人税法施行規則別表一の三の書式又は法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成二十九年財務省令第三十六号）</font></font>附則第二項の規定によりなお従前の例によることとされる場合における同令による改正前の法人税法施行規則別表一の三の書式　平成三十年改正規則附則第四項の規定にかかわらず、これらの表の表中「


５　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（三十二）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十九）</font></font>、別表六の二<font color="lightsalmon"><font color="lightsalmon">（二十九）</font></font>付表、別表七<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>付表五、別表七の二付表六、別表十二<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>、別表十六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>及び別表十六<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>の書式は、法人の附則第一項第二号に定める日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


６　新規則別表十<font color="lightsalmon"><font color="lightsalmon">（七）</font></font>の書式は、法人の附則第一項第四号に定める日以後に終了する事業年度の所得に対する法人税及び連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税及び連結法人の同日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


７　新規則別表十八から別表十八の三までの書式は、法人の令和三年四月一日以後に提出する中間申告書に係る法人税及び連結法人の同日以後に提出する連結中間申告書に係る法人税について適用し、法人の同日前に提出した中間申告書に係る法人税及び連結法人の同日前に提出した連結中間申告書に係る法人税については、なお従前の例による。


８　この省令の施行の日から附則第一項第二号に定める日の前日までの間における次の各号に掲げる書式の適用については、当該各号に定めるところによる。


一　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（二十七）</font></font>の書式　同表の記載要領第二号中<font color="peru"><font color="peru">「第２７条の１２の５第１５項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第１５項」</font></font>と、同第三号中<font color="peru"><font color="peru">「第２７条の１２の５第６項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第６項第２号イ」</font></font>と、<font color="peru"><font color="peru">「第２７条の１２の５第５項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第５項第２号イ」</font></font>と、同第四号中<font color="peru"><font color="peru">「第２７条の１２の５第７項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第７項」</font></font>と、同号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「第２７条の１２の５第２１項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第２１項」</font></font>とする。


二　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（二十八）</font></font>の書式　同表の記載要領第二号中<font color="peru"><font color="peru">「第２７条の１２の５第１５項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第１５項」</font></font>と、同第三号中<font color="peru"><font color="peru">「第２７条の１２の５第６項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第６項第２号イ」</font></font>と、<font color="peru"><font color="peru">「第２７条の１２の５第５項第２号イ」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第５項第２号イ」</font></font>と、同第四号中<font color="peru"><font color="peru">「第２７条の１２の５第２０項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第２０項」</font></font>と、同号<font color="lightsalmon"><font color="lightsalmon">（２）</font></font>中<font color="peru"><font color="peru">「第２７条の１２の５第２１項」</font></font>とあるのは<font color="peru"><font color="peru">「第２７条の１２の４の２第２１項」</font></font>とする。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項_.md) [第２項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項_.md) [第３項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項_.md) [第４項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項_.md) [第５項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第５項_.md) [第６項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第６項_.md) [第７項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第７項_.md) [第８項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項_.md) 

[第１項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第１項.md) [第２項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第２項.md) [第３項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項.md) [第４項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第４項.md) [第５項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第５項.md) [第６項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第６項.md) [第７項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第７項.md) [第８項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第８項.md) 

[目次](index法人税法施行規則.md)

