<font color="lightsalmon"><font color="lightsalmon">（法人税法施行規則等の一部改正に伴う経過措置の原則）</font></font>
法人税法施行規則附則平成１４年８月１日財務省令第４６号第２条第１項

この附則に別段の定めがあるものを除き、第一条の規定による改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新法人税法施行規則」</font></font>という。）</font></font>の規定、第二条の規定による改正後の租税特別措置法施行規則の規定及び第三条の規定による改正後の阪神・淡路大震災の被災者等に係る国税関係法律の臨時特例に関する法律施行規則の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法等の一部を改正する法律<font color="darkkhaki"><font color="darkkhaki">（平成十四年法律第七十九号。以下<font color="peru"><font color="peru">「改正法」</font></font>という。）</font></font>第一条の規定による改正後の法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「新法人税法」</font></font>という。）</font></font>第二条第八号に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十五年三月三十一日以後に終了する事業年度の所得に対する法人税、連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日以後に終了する計算期間の所得に対する法人税、法人の同日以後に終了する事業年度の退職年金等積立金に対する法人税及び法人の同日以後の解散<font color="lightsalmon"><font color="lightsalmon">（合併による解散を除く。以下この条において同じ。）</font></font>による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の事業年度の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下この条において同じ。）</font></font>について適用し、法人の同日前に終了した事業年度の所得に対する法人税、特定信託の受託者である法人の同日前に終了した計算期間の所得に対する法人税、法人の同日前に終了した事業年度の退職年金等積立金に対する法人税及び法人の同日前の解散による清算所得に対する法人税については、なお従前の例による。


--- ---


[条(全)](法人税法施行規則附則平成１４年８月１日財務省令第４６号第２条_.md)  [項](法人税法施行規則附則平成１４年８月１日財務省令第４６号第２条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index法人税法施行規則.md)

