<font color="lightsalmon"><font color="lightsalmon">（収益事業の範囲に関する経過措置）</font></font>
法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>第八条の二の二第一項<font color="lightsalmon"><font color="lightsalmon">（信用保証業で収益事業に該当しないものの範囲等）</font></font><font color="lightsalmon"><font color="lightsalmon">（都市再生特別措置法に係る部分を除く。）</font></font>の規定は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の前条第三号に定める日以後に終了する事業年度の所得に対する法人税について適用し、法人の同日前に終了した事業年度の所得に対する法人税については、なお従前の例による。


--- ---

[条(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条_.md)  [項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第２項_.md)

[前項(全)←](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項_.md)    [→次項(全)](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第１項.md)    [→次項 　 ](法人税法施行規則附則平成１５年３月３１日財務省令第２８号第２条第３項.md)



[目次](index法人税法施行規則.md)

