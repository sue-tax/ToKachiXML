　
法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条

１　この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第一条の改正規定<font color="lightsalmon">（法人税法施行規則第三十二条第二項の改正規定に係る部分<font color="darkkhaki">（「、別表十八及び別表十八付表」を「及び別表十八から別表十八付表二まで」に改める部分に限る。）</font>、同令第三十四条第二項の改正規定に係る部分、同令第六十一条の二第三項及び第六十一条の四第三項の改正規定に係る部分、同令別表七<font color="darkkhaki">（一）</font>の記載要領の改正規定に係る部分<font color="darkkhaki">（同第四号の改正規定中「の次に「」を「を「<font color="springgreen">（法第５８条の規定の適用がある場合」に、「を加え」を「に改め」に改める部分を除く。）</font>、同令別表七<font color="springgreen">（一）</font>付表四の記載要領第二号<font color="springgreen">（２）</font>の改正規定の次に次のように加える部分、同表の次に五表を加える改正規定に係る部分<font color="springgreen">（同令別表七<font color="deepskyblue">（二）</font>の記載要領第七号<font color="deepskyblue">（１）</font>に係る部分を除く。）</font>、同令別表七の二付表五の次に三表を加える改正規定に係る部分<font color="springgreen">（「別表七の二付表五」を「別表七の二付表六」に改める部分に限る。）</font>並びに同令別表十七の三<font color="springgreen">（三）</font>の次に二表を加える改正規定に係る部分<font color="springgreen">（同令別表十八に係る部分を除く。）</font>に限る。）</font>　産業競争力強化法等の一部を改正する等の法律<font color="darkkhaki">（令和三年法律第　　　号）</font>の施行の日）</font>

二　第一条の改正規定<font color="lightsalmon">（法人税法施行規則別表十四<font color="darkkhaki">（二）</font>の記載要領第一号の改正規定に係る部分<font color="darkkhaki">（「第６６条の１１の２第１項」を「第６６条の１１の３第１項」に改める部分に限る。）</font>に限る。）</font>　新型コロナウイルス感染症等の影響による社会経済情勢の変化に対応して金融の機能の強化及び安定の確保を図るための銀行法等の一部を改正する法律<font color="lightsalmon">（令和三年法律第　　　号）</font>の施行の日

--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項_.md) 

[第１項 　 ](法人税法施行規則附則令和３年４月１５日財務省令第４６号第０条第１項.md) 

[目次](index法人税法施行規則.md)

