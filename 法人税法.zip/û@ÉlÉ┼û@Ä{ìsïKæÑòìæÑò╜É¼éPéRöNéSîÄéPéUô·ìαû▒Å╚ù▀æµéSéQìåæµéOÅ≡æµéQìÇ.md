　
法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第２項

改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表十一<font color="darkkhaki"><font color="darkkhaki">（一）</font></font>及び別表十一<font color="darkkhaki"><font color="darkkhaki">（一の二）</font></font>の書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法<font color="darkkhaki"><font color="darkkhaki">（以下<font color="peru"><font color="peru">「法」</font></font>という。）</font></font>第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十三年四月一日以後に終了する事業年度及び同日以後に合併等<font color="lightsalmon"><font color="lightsalmon">（合併、分割、現物出資又は事後設立<font color="darkkhaki"><font color="darkkhaki">（法第二条第十二号の六に規定する事後設立をいう。以下この項において同じ。）</font></font>をいう。以下この項において同じ。）</font></font>が行われる場合における法人の事業年度の所得並びに同年四月一日以後の解散による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下同じ。）</font></font>について適用し、法人の同日前に終了した事業年度<font color="lightsalmon"><font color="lightsalmon">（同日に合併等が行われる場合における法人の事業年度を除く。）</font></font>及び同日前に合併、現物出資又は事後設立が行われた場合における法人の事業年度の所得並びに同日前の解散又は合併による清算所得に対する法人税については、なお従前の例による。


--- ---

[条(全)](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条_.md)  [項(全)](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第２項_.md)

[前項(全)←](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第１項_.md)    [→次項(全)](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第３項_.md)

[前項 　 ←](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第１項.md)    [→次項 　 ](法人税法施行規則附則平成１３年４月１６日財務省令第４２号第０条第３項.md)



[目次](index法人税法施行規則.md)

