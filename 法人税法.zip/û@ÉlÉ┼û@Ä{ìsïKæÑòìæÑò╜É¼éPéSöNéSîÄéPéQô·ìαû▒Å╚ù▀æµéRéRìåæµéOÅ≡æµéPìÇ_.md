　
法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第１項

この省令は、公布の日から施行する。ただし、別表十二<font color="lightsalmon"><font color="lightsalmon">（九）</font></font>を別表十二<font color="lightsalmon"><font color="lightsalmon">（八）</font></font>とし、同表の次に一表を加える改正規定<font color="lightsalmon"><font color="lightsalmon">（別表十二<font color="darkkhaki"><font color="darkkhaki">（九）</font></font>を別表十二<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>とする部分を除く。）</font></font>、別表十二<font color="lightsalmon"><font color="lightsalmon">（十一）</font></font>の改正規定及び別表二十一の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「特定都市鉄道整備準備金」</font></font>の下に<font color="peru"><font color="peru">「、新幹線鉄道大規模改修準備金」</font></font>を加える部分及び<font color="peru"><font color="peru">「特定都市鉄道整備準備金積立額」</font></font>の下に<font color="peru"><font color="peru">「、新幹線鉄道大規模改修準備金積立額」</font></font>を加える部分に限る。）</font></font>は、全国新幹線鉄道整備法の一部を改正する法律<font color="lightsalmon"><font color="lightsalmon">（平成十四年法律第六十四号）</font></font>の施行の日から施行する。


--- ---


[条(全)](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条_.md)  [項](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成１４年４月１２日財務省令第３３号第０条第２項.md)



[目次](index法人税法施行規則.md)

