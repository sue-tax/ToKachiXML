　
法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　別表七<font color="lightsalmon">（一）</font>付表二の記載要領第二号の改正規定、別表七<font color="lightsalmon">（一）</font>付表三の表の改正規定、別表十四<font color="lightsalmon">（三）</font>の表の改正規定<font color="lightsalmon">（「交付の時等の単価　<font color="darkkhaki">（６）</font>」の欄に係る部分を除く。）</font>、同表の記載要領の改正規定<font color="lightsalmon">（同第二号に係る部分を除く。）</font>及び別表十四<font color="lightsalmon">（四）</font>の改正規定並びに附則第四項の規定　平成二十九年十月一日

二　別表六<font color="lightsalmon">（二十一）</font>の記載要領第二号<font color="lightsalmon">（３）</font>の改正規定及び別表六の二<font color="lightsalmon">（十八）</font>付表の記載要領第二号<font color="lightsalmon">（３）</font>の改正規定　福島復興再生特別措置法の一部を改正する法律<font color="lightsalmon">（平成二十九年法律第　　　号）</font>の施行の日

三　別表六<font color="lightsalmon">（十七）</font>を別表六<font color="lightsalmon">（二十）</font>とし、同表の前に四表を加える改正規定<font color="lightsalmon">（別表六<font color="darkkhaki">（十七）</font>に係る部分に限る。）</font>及び別表六の二<font color="lightsalmon">（十一）</font>付表を別表六の二<font color="lightsalmon">（十三）</font>付表とし、同表の次に三表を加える改正規定<font color="lightsalmon">（別表六の二<font color="darkkhaki">（十四）</font>及び別表六の二<font color="darkkhaki">（十四）</font>付表に係る部分に限る。）</font>並びに附則第三項の規定　企業立地の促進等による地域における産業集積の形成及び活性化に関する法律の一部を改正する法律<font color="lightsalmon">（平成二十九年法律第　　　号）</font>の施行の日

四　別表七の二付表一の記載要領に二号を加える改正規定<font color="lightsalmon">（第七号に係る部分に限る。）</font>　農業競争力強化支援法<font color="lightsalmon">（平成二十九年法律第　　　号）</font>の施行の日

--- ---


[条(全)](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条_.md)  [項](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第２項.md)

[第１号](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項第１号.md)  [第２号](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項第２号.md)  [第３号](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項第３号.md)  [第４号](法人税法施行規則附則平成２９年４月１４日財務省令第３６号第０条第１項第４号.md)  

[目次](index法人税法施行規則.md)

