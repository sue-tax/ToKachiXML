　
法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項

この省令の施行の日から特定高度情報通信技術活用システムの開発供給及び導入の促進に関する法律の施行の日の前日までの間における次の各号に掲げる書式の適用については、当該各号に定めるところによる。


一　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>の書式　同表の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「、第４２条の１２の５の２第２項（認定特定高度情報通信技術活用設備を取得した場合の法人税額の特別控除）又は」</font></font>とあるのは、<font color="peru"><font color="peru">「又は」</font></font>とする。


二　新規則別表六の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>の書式　同表の記載要領第一号<font color="lightsalmon"><font color="lightsalmon">（１）</font></font>中<font color="peru"><font color="peru">「、第６８条の１５の６の２第２項（認定特定高度情報通信技術活用設備を取得した場合の法人税額の特別控除）又は」</font></font>とあるのは、<font color="peru"><font color="peru">「又は」</font></font>とする。


--- ---


[条(全)](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条_.md)  [項](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項.md)

[前項(全)←](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項_.md)  ~~→次項(全)~~

[前項 　 ←](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第４項.md)  ~~→次項~~

[第１号](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項第１号.md)  [第２号](法人税法施行規則附則令和２年４月１０日財務省令第４０号第０条第５項第２号.md)  

[目次](index法人税法施行規則.md)

