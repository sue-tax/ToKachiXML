（寄附金の損金不算入に対する特例に関する経過措置）
法人税法施行規則附則平成１６年３月３１日財務省令第２７号第４条

１　法人税法施行令の一部を改正する政令<font color="lightsalmon"><font color="lightsalmon">（平成十六年政令第百一号。以下この条において<font color="peru"><font color="peru">「改正令」</font></font>という。）</font></font>附則第九条第二項<font color="lightsalmon"><font color="lightsalmon">（寄附金の損金不算入に対する特例に関する経過措置）</font></font>に規定する財務省令で定める期間は、施行日から証明書類<font color="lightsalmon"><font color="lightsalmon">（同項の民法<font color="darkkhaki"><font color="darkkhaki">（明治二十九年法律第八十九号）</font></font>第三十四条<font color="darkkhaki"><font color="darkkhaki">（公益法人の設立）</font></font>の規定により設立された法人が改正令による改正前の法人税法施行令第七十七条第一項第二号ル<font color="darkkhaki"><font color="darkkhaki">（公益の増進に著しく寄与する法人の範囲）</font></font>に掲げる法人に該当する旨を改正前の法人税法施行規則第二十四条第一号<font color="darkkhaki"><font color="darkkhaki">（公益の増進に著しく寄与する法人の証明書類等）</font></font>の規定により同号に規定する主務官庁が証明した書類で施行日前二年以内に発行されたものをいう。）</font></font>が発行された日以後二年を経過する日<font color="lightsalmon"><font color="lightsalmon">（当該二年を経過する日が施行日以後一年を経過する日以前に到来する場合は、当該一年を経過する日）</font></font>までの期間とする。


２　改正令附則第九条第二項の規定の適用を受ける寄附金に係る新規則第二十四条<font color="lightsalmon"><font color="lightsalmon">（公益の増進に著しく寄与する法人の証明書類等）</font></font>の規定の適用については、同条第三号中<font color="peru"><font color="peru">「同号に掲げる法人」</font></font>とあるのは<font color="peru"><font color="peru">「法人税法施行令の一部を改正する政令（平成十六年政令第百一号。以下この号において「平成十六年改正令」という。）による改正前の法人税法施行令第七十七条第一項第二号ル（公益の増進に著しく寄与する法人の範囲）に掲げる法人」</font></font>と、<font color="peru"><font color="peru">「当該寄附金を支出する日以前二年内に発行されたもの」</font></font>とあるのは<font color="peru"><font color="peru">「平成十六年改正令の施行の日前二年以内に発行されたもの」</font></font>と、<font color="peru"><font color="peru">「受けたもので当該二年内に発行された書類に記載されている同号の認定の日が当該支出する日以前二年（同号ハに掲げる法人にあつては、五年）内であるもの」</font></font>とあるのは<font color="peru"><font color="peru">「受けたもの」</font></font>とする。


--- ---

[前条(全)←](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第３条_.md)    [→次条(全)](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第５条_.md)

[第１項(全)](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第４条第１項_.md) [第２項(全)](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第４条第２項_.md) 

[第１項 　 ](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第４条第１項.md) [第２項 　 ](法人税法施行規則附則平成１６年３月３１日財務省令第２７号第４条第２項.md) 

[目次](index法人税法施行規則.md)

