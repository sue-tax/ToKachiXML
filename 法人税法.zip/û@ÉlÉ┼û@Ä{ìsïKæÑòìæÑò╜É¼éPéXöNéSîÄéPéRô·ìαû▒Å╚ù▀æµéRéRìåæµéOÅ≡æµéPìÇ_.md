　
法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十七<font color="darkkhaki">（二の三）</font>」を「別表十七<font color="darkkhaki">（二の四）</font>」に改める部分に限る。）</font>、第三十七条の九第二項の改正規定<font color="lightsalmon">（「別表十七<font color="darkkhaki">（二の三）</font>」を「別表十七<font color="darkkhaki">（二の四）</font>」に改める部分に限る。）</font>、別表六<font color="lightsalmon">（二）</font>の記載要領第一号の改正規定、別表六<font color="lightsalmon">（二の二）</font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon">（二）</font>の記載要領第一号の改正規定、別表六の二<font color="lightsalmon">（二）</font>付表の記載要領の改正規定、別表七<font color="lightsalmon">（一）</font>付表一の記載要領第三号の改正規定<font color="lightsalmon">（「第１１６条の２第５項」を「第１１６条の２第６項」に改める部分に限る。）</font>、別表十七<font color="lightsalmon">（二）</font>の記載要領第九号の改正規定、別表十七<font color="lightsalmon">（二）</font>付表の記載要領第十号の改正規定、別表十七<font color="lightsalmon">（二の二）</font>の記載要領第十八号の改正規定、別表十七<font color="lightsalmon">（二の二）</font>付表一の記載要領の改正規定、別表十七<font color="lightsalmon">（二の二）</font>付表二の記載要領の改正規定、別表十七<font color="lightsalmon">（二の三）</font>の記載要領第七号の改正規定及び同表の次に一表を加える改正規定　平成十九年五月一日

二　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（五）</font>」に改める部分に限る。）</font>、第三十四条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（五）</font>」に改める部分に限る。）</font>、第四十三条第二項の改正規定<font color="lightsalmon">（「別表十四<font color="darkkhaki">（四）</font>、別表十四<font color="darkkhaki">（四）</font>付表」を「別表十四<font color="darkkhaki">（四）</font>から別表十四<font color="darkkhaki">（五）</font>まで」に改める部分に限る。）</font>及び別表十四<font color="lightsalmon">（四）</font>付表の次に一表を加える改正規定並びに附則第三項の規定　平成二十年四月一日

三　第三十二条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>まで」を「別表十<font color="darkkhaki">（七）</font>まで、別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、第三十四条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>」を「別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、第四十三条第二項の改正規定<font color="lightsalmon">（「別表十<font color="darkkhaki">（八）</font>」を「別表十<font color="darkkhaki">（九）</font>」に改める部分に限る。）</font>、別表四の表の改正規定、別表四の二の表の改正規定、別表四の二付表の表の改正規定、別表六<font color="lightsalmon">（一）</font>の表の改正規定、別表六<font color="lightsalmon">（二）</font>の表の改正規定、別表六の二<font color="lightsalmon">（一）</font>の表の改正規定、別表六の二<font color="lightsalmon">（二）</font>の表の改正規定、別表七<font color="lightsalmon">（二）</font>の記載要領第四号の改正規定、別表九<font color="lightsalmon">（四）</font>の改正規定、別表十<font color="lightsalmon">（八）</font>を別表十<font color="lightsalmon">（九）</font>とし、別表十<font color="lightsalmon">（七）</font>の次に一表を加える改正規定、別表十七<font color="lightsalmon">（二の三）</font>の記載要領第二号の改正規定、同第四号の改正規定、別表二十の記載要領第一号の改正規定及び別表二十一<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表を別表二十<font color="darkkhaki">（四）</font>とする部分を除く。）</font>　信託法<font color="lightsalmon">（平成十八年法律第百八号）</font>の施行の日

四　別表三<font color="lightsalmon">（二の三）</font>の記載要領第一号の改正規定及び別表三<font color="lightsalmon">（二の三）</font>付表の記載要領の改正規定　都市再生特別措置法等の一部を改正する法律<font color="lightsalmon">（平成十九年法律第十九号）</font>の施行の日

五　別表六<font color="lightsalmon">（二）</font>の記載要領第六号の改正規定<font color="lightsalmon">（「第２条第１９項」を「第２条第１２項」に改める部分に限る。）</font>、別表八の表の改正規定、別表八の二の表の改正規定、別表十<font color="lightsalmon">（七）</font>の表のⅠの改正規定及び同表の記載要領第三号の改正規定　証券取引法等の一部を改正する法律<font color="lightsalmon">（平成十八年法律第六十五号）</font>の施行の日

--- ---


[条(全)](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条_.md)  [項](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項.md)

~~前項(全)←~~　  [→次項(全)](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第２項.md)

[第１号](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項第１号.md)  [第２号](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項第２号.md)  [第３号](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項第３号.md)  [第４号](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項第４号.md)  [第５号](法人税法施行規則附則平成１９年４月１３日財務省令第３３号第０条第１項第５号.md)  

[目次](index法人税法施行規則.md)

