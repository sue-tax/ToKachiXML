<font color="lightsalmon"><font color="lightsalmon">（施行期日）</font></font>
法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項

この省令は、平成十七年四月一日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。


一　第二十七条の七の改正規定　平成十七年七月一日


二　第八条の三第一項の改正規定、第二十七条の十四第二号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「、第二十一条の六第四項第六号（特定都市鉄道整備準備金）」</font></font>を削る部分に限る。）</font></font>及び第三十七条第三項第二号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「、第二十二条の四十八第四項第七号（特定都市鉄道整備準備金）」</font></font>を削る部分に限る。）</font></font>並びに次条の規定　平成十七年十月一日


三　第二十七条の十四第二号の改正規定<font color="lightsalmon"><font color="lightsalmon">（<font color="peru"><font color="peru">「第二十一条の十三第二項第五号」</font></font>を<font color="peru"><font color="peru">「第二十一条の十二第二項第五号」</font></font>に、<font color="peru"><font color="peru">「第二十一条の十三の二第五号」</font></font>を<font color="peru"><font color="peru">「第二十一条の十三第五号」</font></font>に改める部分に限る。）</font></font>　原子力発電における使用済燃料の再処理等のための積立金の積立て及び管理に関する法律<font color="lightsalmon"><font color="lightsalmon">（平成十七年法律第四十八号）</font></font>の施行の日


--- ---


[条(全)](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条_.md)  [項](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~

[第１号](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項第１号.md)  [第２号](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項第２号.md)  [第３号](法人税法施行規則附則平成１７年３月３１日財務省令第３２号第１条第１項第３号.md)  

[目次](index法人税法施行規則.md)

