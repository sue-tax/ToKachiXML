　
法人税法施行規則附則平成１１年６月３０日大蔵省令第６６号第０条

１　この省令は、中小企業総合事業団法<font color="lightsalmon"><font color="lightsalmon">（平成十一年法律第十九号）</font></font>の施行の日<font color="lightsalmon"><font color="lightsalmon">（平成十一年七月一日）</font></font>から施行する。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１１年６月３０日大蔵省令第６６号第０条第１項_.md) 

[第１項 　 ](法人税法施行規則附則平成１１年６月３０日大蔵省令第６６号第０条第１項.md) 

[目次](index法人税法施行規則.md)

