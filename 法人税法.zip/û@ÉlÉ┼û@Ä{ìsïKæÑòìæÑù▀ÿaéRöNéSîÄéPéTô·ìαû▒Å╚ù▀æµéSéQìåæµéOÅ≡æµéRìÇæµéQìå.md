　
[法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項)第２号

法人税法施行規則の一部を改正する省令<font color="lightsalmon"><font color="lightsalmon">（平成三十年財務省令第三十五号。以下<font color="peru"><font color="peru">「平成三十年改正規則」</font></font>という。）</font></font>附則第二項その他これに類する法人税法施行規則別表の書式を改正する省令の経過措置を定める規定によりなお従前の例によることとされる場合におけるこれらの省令による改正前の法人税法施行規則別表一<font color="lightsalmon"><font color="lightsalmon">（一）</font></font>から別表一の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>までの書式<font color="lightsalmon"><font color="lightsalmon">（前号に掲げる書式を除く。）</font></font>　平成三十年改正規則附則第三項の規定にかかわらず、これらの表の表中「


--- ---

[条(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条_.md)    [項(全)](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項_.md)    [項](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項.md)

[前号←](法人税法施行規則附則令和３年４月１５日財務省令第４２号第０条第３項第１号.md)  ~~→次号~~

[目次](index法人税法施行規則.md)

