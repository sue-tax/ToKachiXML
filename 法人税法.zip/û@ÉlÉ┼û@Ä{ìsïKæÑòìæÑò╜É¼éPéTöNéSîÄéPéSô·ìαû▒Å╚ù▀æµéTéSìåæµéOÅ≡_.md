　
法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条

１　この省令は、公布の日から施行する。


２　改正後の法人税法施行規則<font color="lightsalmon"><font color="lightsalmon">（以下<font color="peru"><font color="peru">「新規則」</font></font>という。）</font></font>の規定及び新規則別表の書式<font color="lightsalmon"><font color="lightsalmon">（新規則別表六<font color="darkkhaki"><font color="darkkhaki">（六）</font></font>から別表六<font color="darkkhaki"><font color="darkkhaki">（八）</font></font>まで、別表六の二<font color="darkkhaki"><font color="darkkhaki">（三）</font></font>から別表六の二<font color="darkkhaki"><font color="darkkhaki">（五）</font></font>付表二まで及び別表七から別表七の二付表二までの書式を除く。）</font></font>は、法人<font color="lightsalmon"><font color="lightsalmon">（法人税法第二条第八号<font color="darkkhaki"><font color="darkkhaki">（定義）</font></font>に規定する人格のない社団等を含む。以下同じ。）</font></font>の平成十五年四月一日以後に終了する事業年度の所得に対する法人税、連結法人の同日以後に終了する連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日以後に終了する計算期間の所得に対する法人税、法人の同日以後に終了する事業年度の退職年金等積立金に対する法人税及び法人の同日以後の解散<font color="lightsalmon"><font color="lightsalmon">（合併による解散を除く。以下この項において同じ。）</font></font>による清算所得に対する法人税<font color="lightsalmon"><font color="lightsalmon">（清算所得に対する法人税を課される法人の清算中の事業年度の所得に係る法人税及び残余財産の一部分配により納付すべき法人税を含む。以下この項において同じ。）</font></font>について適用し、法人の同日前に終了した事業年度の所得に対する法人税、連結法人の同日前に終了した連結事業年度の連結所得に対する法人税、特定信託の受託者である法人の同日前に終了した計算期間の所得に対する法人税、法人の同日前に終了した事業年度の退職年金等積立金に対する法人税及び法人の同日前の解散による清算所得に対する法人税については、なお従前の例による。


３　新規則別表六<font color="lightsalmon"><font color="lightsalmon">（六）</font></font>から別表六<font color="lightsalmon"><font color="lightsalmon">（八）</font></font>までの書式は、法人の平成十五年一月一日以後に開始し、かつ、平成十五年四月一日以後に終了する事業年度の所得に対する法人税について適用し、法人の平成十五年一月一日前に開始した事業年度及び平成十五年四月一日前に終了した事業年度の所得に対する法人税については、なお従前の例による。


４　新規則別表六の二<font color="lightsalmon"><font color="lightsalmon">（三）</font></font>から別表六の二<font color="lightsalmon"><font color="lightsalmon">（五）</font></font>付表二までの書式は、連結法人の連結親法人事業年度<font color="lightsalmon"><font color="lightsalmon">（法人税法第十五条の二第一項<font color="darkkhaki"><font color="darkkhaki">（連結事業年度の意義）</font></font>に規定する連結親法人事業年度をいう。以下この項において同じ。）</font></font>が平成十五年一月一日以後に開始し、かつ、平成十五年四月一日以後に終了する連結事業年度の連結所得に対する法人税について適用し、連結法人の連結親法人事業年度が平成十五年一月一日前に開始した連結事業年度及び平成十五年四月一日前に終了した連結事業年度の連結所得に対する法人税については、なお従前の例による。


５　新規則別表七から別表七付表<font color="lightsalmon"><font color="lightsalmon">（二）</font></font>までの書式は、法人の平成十五年四月一日以後に終了する事業年度<font color="lightsalmon"><font color="lightsalmon">（同日に行われた合併等<font color="darkkhaki"><font color="darkkhaki">（合併又は法人税法第二条第十二号の九に規定する分割型分割をいう。以下この項において同じ。）</font></font>に係る被合併法人等<font color="darkkhaki"><font color="darkkhaki">（被合併法人又は分割法人をいう。以下この項において同じ。）</font></font>の最後事業年度等<font color="darkkhaki"><font color="darkkhaki">（合併等の日の前日の属する事業年度をいう。以下この項において同じ。）</font></font>を含む。）</font></font>の所得に対する法人税について適用し、法人の同年四月一日前に終了した事業年度<font color="lightsalmon"><font color="lightsalmon">（同日に行われた合併等に係る被合併法人等の最後事業年度等を除く。）</font></font>の所得に対する法人税については、なお従前の例による。


６　新規則別表七の二から別表七の二付表二までの書式は、連結法人の平成十五年三月三十一日以後に終了する連結事業年度の連結所得に対する法人税について適用する。


--- ---

~~前条(全)←~~　~~→次条(全)~~

[第１項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第１項_.md) [第２項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第２項_.md) [第３項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第３項_.md) [第４項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第４項_.md) [第５項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第５項_.md) [第６項(全)](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第６項_.md) 

[第１項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第１項.md) [第２項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第２項.md) [第３項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第３項.md) [第４項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第４項.md) [第５項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第５項.md) [第６項 　 ](法人税法施行規則附則平成１５年４月１４日財務省令第５４号第０条第６項.md) 

[目次](index法人税法施行規則.md)

