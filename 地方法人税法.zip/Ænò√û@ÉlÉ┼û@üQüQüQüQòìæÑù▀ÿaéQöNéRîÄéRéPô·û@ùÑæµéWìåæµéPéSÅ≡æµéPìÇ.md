<font color="lightsalmon">（連結納税制度の改正に伴う経過措置の原則）</font>
地方法人税法附則令和２年３月３１日法律第８号第１４条第１項

別段の定めがあるものを除き、第三条の規定<font color="lightsalmon">（附則第一条第五号ロに掲げる改正規定に限る。以下この項において同じ。）</font>による改正後の法人税法<font color="lightsalmon">（以下<font color="peru">「新法人税法」</font>という。）</font>、第四条の規定<font color="lightsalmon">（同号ハに掲げる改正規定に限る。次項において同じ。）</font>による改正後の地方法人税法<font color="lightsalmon">（以下<font color="peru">「新地方法人税法」</font>という。）</font>、第十三条の規定<font color="lightsalmon">（同号ヘに掲げる改正規定に限る。次項において同じ。）</font>による改正後の国税通則法、第十四条の規定<font color="lightsalmon">（同号トに掲げる改正規定に限る。次項において同じ。）</font>による改正後の国税徴収法、第十六条の規定による改正後の租税特別措置法<font color="lightsalmon">（以下<font color="peru">「四年新措置法」</font>という。）</font>、第二十一条の規定による改正後の電子計算機を使用して作成する国税関係帳簿書類の保存方法等の特例に関する法律、第二十三条の規定による改正後の東日本大震災の被災者等に係る国税関係法律の臨時特例に関する法律<font color="lightsalmon">（以下<font color="peru">「四年新震災特例法」</font>という。）</font>及び第三十条の規定<font color="lightsalmon">（同号ネに掲げる改正規定に限る。次項において同じ。）</font>による改正後の所得税法等の一部を改正する法律の規定は、法人<font color="lightsalmon">（人格のない社団等を含む。次項及び附則第二十二条において同じ。）</font>の令和四年四月一日以後に開始する事業年度<font color="lightsalmon">（第三条の規定による改正前の法人税法<font color="darkkhaki">（以下<font color="peru">「旧法人税法」</font>という。）</font>第二条第十二号の七に規定する連結子法人<font color="darkkhaki">（以下附則第三十二条までにおいて<font color="peru">「連結子法人」</font>という。）</font>の連結親法人事業年度<font color="darkkhaki">（旧法人税法第十五条の二第一項に規定する連結親法人事業年度をいう。以下附則第三十二条までにおいて同じ。）</font>が同日前に開始した事業年度<font color="darkkhaki">（以下この条において<font color="peru">「旧事業年度」</font>という。）</font>を除く。）</font>の所得に対する法人税及び同日以後に開始する課税事業年度<font color="lightsalmon">（旧事業年度を除く。）</font>の基準法人税額に対する地方法人税について適用する。

--- ---

[条(全)](地方法人税法＿＿＿＿附則令和２年３月３１日法律第８号第１４条_.md)  [項(全)](地方法人税法＿＿＿＿附則令和２年３月３１日法律第８号第１４条第１項_.md)

~~前項(全)←~~　  [→次項(全)](地方法人税法＿＿＿＿附則令和２年３月３１日法律第８号第１４条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](地方法人税法＿＿＿＿附則令和２年３月３１日法律第８号第１４条第２項.md)



[目次](index地方法人税法＿＿＿＿.md)

