<font color="lightsalmon">（定義）</font>
地方法人税法施行規則第１条第１項

この省令において<font color="peru">「内国法人」</font>、<font color="peru">「外国法人」</font>、<font color="peru">「人格のない社団等」</font>、<font color="peru">「被合併法人」</font>、<font color="peru">「合併法人」</font>、<font color="peru">「通算親法人」</font>、<font color="peru">「通算子法人」</font>、<font color="peru">「通算法人」</font>、<font color="peru">「適格合併」</font>、<font color="peru">「地方法人税中間申告書」</font>、<font color="peru">「地方法人税確定申告書」</font>、<font color="peru">「期限後申告書」</font>、<font color="peru">「修正申告書」</font>、<font color="peru">「更正」</font>、<font color="peru">「還付加算金」</font>又は<font color="peru">「課税事業年度」</font>とは、それぞれ地方法人税法<font color="lightsalmon">（以下<font color="peru">「法」</font>という。）</font>[第二条第一号](地方法人税法施行規則＿第２条第１項第１号)から[第八号](地方法人税法施行規則＿第１条第１項第８号)まで、[第十号](地方法人税法施行規則＿第１条第１項第１０号)、[第十四号](地方法人税法施行規則＿第１条第１項第１４号)から[第十七号](地方法人税法施行規則＿第１条第１項第１７号)まで、[第十九号](地方法人税法施行規則＿第１条第１項第１９号)若しくは[第二十二号](地方法人税法施行規則＿第１条第１項第２２号)又は[第七条](地方法人税法施行規則＿第７条第１項)に規定する内国法人、外国法人、人格のない社団等、被合併法人、合併法人、通算親法人、通算子法人、通算法人、適格合併、地方法人税中間申告書、地方法人税確定申告書、期限後申告書、修正申告書、更正、還付加算金又は課税事業年度をいう。

--- ---


[条(全)](地方法人税法施行規則＿第１条_.md)  [項](地方法人税法施行規則＿第１条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~



[目次](index地方法人税法施行規則.md)

