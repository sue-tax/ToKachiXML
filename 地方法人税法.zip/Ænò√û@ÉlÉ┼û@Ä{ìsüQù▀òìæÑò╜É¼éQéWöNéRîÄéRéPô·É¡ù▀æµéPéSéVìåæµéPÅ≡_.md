（施行期日）
地方法人税法施行令附則平成２８年３月３１日政令第１４７号第１条

１　この政令は、平成二十八年四月一日から施行する。ただし、附則第二条第一項の改正規定<font color="lightsalmon">（<font color="peru">「百分の四・四」</font>を<font color="peru">「百分の十・三」</font>に改める部分に限る。）</font>、同条第二項の改正規定<font color="lightsalmon">（<font color="peru">「百分の四・四」</font>を<font color="peru">「百分の十・三」</font>に改める部分に限る。）</font>、同条第三項及び第四項の改正規定、同条第五項の改正規定<font color="lightsalmon">（<font color="peru">「百分の四・四」</font>を<font color="peru">「百分の十・三」</font>に改める部分に限る。）</font>、同条第六項の改正規定並びに同条第七項の改正規定<font color="lightsalmon">（<font color="peru">「百分の四・四」</font>を<font color="peru">「百分の十・三」</font>に改める部分に限る。）</font>並びに次条及び附則第三条の規定は、令和元年十月一日から施行する。

--- ---

~~前条(全)←~~　  [→次条(全)](地方法人税法施行＿令附則平成２８年３月３１日政令第１４７号第２条_.md)

[第１項(全)](地方法人税法施行＿令附則平成２８年３月３１日政令第１４７号第１条第１項_.md) 

[第１項 　 ](地方法人税法施行＿令附則平成２８年３月３１日政令第１４７号第１条第１項.md) 

[目次](index地方法人税法施行＿令.md)

