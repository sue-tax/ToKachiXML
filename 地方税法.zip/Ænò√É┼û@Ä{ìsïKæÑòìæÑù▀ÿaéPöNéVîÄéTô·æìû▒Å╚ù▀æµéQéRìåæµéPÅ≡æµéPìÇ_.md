<font color="lightsalmon">（施行期日）</font>
地方税法施行規則附則令和１年７月５日総務省令第２３号第１条第１項

この省令は、公布の日から施行する。ただし、次の各号に掲げる規定は、当該各号に定める日から施行する。

一　第三条の十三の三、第四条の四、第五条、第六条の五、第七条の二の四第一項第五号及び第七条の二の五第二項第四号の改正規定並びに第一号様式の表の改正規定、第六号様式の表の改正規定<font color="lightsalmon">（「<font color="darkkhaki">（<font color="springgreen">（３３）</font>）</font>」を「<font color="darkkhaki">（<font color="springgreen">（３４）</font>）</font>」に改める部分、「４９」を「４７」に改める部分及び「５６」を「５４」に改める部分を除く。）</font>、同様式記載要領の改正規定<font color="lightsalmon">（同様式記載要領１０、１２及び１９に係る部分を除く。）</font>、同様式別表五の二の表の改正規定<font color="lightsalmon">（「別表５の６<font color="darkkhaki">（<font color="springgreen">（３６）</font>）</font>又は別表５の６の２<font color="darkkhaki">（<font color="springgreen">（２７）</font>）</font>」を「別表５の６の２<font color="darkkhaki">（<font color="springgreen">（２７）</font>）</font>」に改める部分に限る。）</font>、同様式別表五の六、同様式別表十四記載要領、第六号の三様式の表、同様式記載要領、第七号の三様式の表、第十号の三様式の表、同様式記載要領、第十号の五様式の表、同様式記載要領、第十二号の二様式の表、第十三号様式の表、同様式記載要領、第十三号の二様式の表、第十四号様式の表、同様式記載要領及び第二十号の五様式の表の改正規定並びに次条及び附則第三条の規定　令和元年十月一日

二　第五号の十四様式及び第五号の十四の二様式の改正規定、第六号様式の表の改正規定<font color="lightsalmon">（「<font color="darkkhaki">（<font color="springgreen">（３３）</font>）</font>」を「<font color="darkkhaki">（<font color="springgreen">（３４）</font>）</font>」に改める部分に限る。）</font>、同様式記載要領１２の改正規定、同様式別表一記載要領の改正規定<font color="lightsalmon">（「<font color="darkkhaki">（１８）</font>の欄」を「<font color="darkkhaki">（１８）</font>の欄の金額）</font>、分配時調整外国税相当額の個別帰属額<font color="lightsalmon">（法人税の明細書<font color="darkkhaki">（別表６の２<font color="springgreen">（２の２）</font>）</font>の<font color="darkkhaki">（２７）</font>の欄」に改める部分に限る。）</font>、同様式別表五の表の改正規定、同様式別表五記載要領の改正規定<font color="lightsalmon">（同表記載要領４に係る部分を除く。）</font>、同様式別表五の二の表の改正規定<font color="lightsalmon">（「<font color="darkkhaki">（<font color="springgreen">（２３）</font>）</font>」を「<font color="darkkhaki">（<font color="springgreen">（２４）</font>）</font>」に改める部分に限る。）</font>、同様式別表五の二記載要領、同様式別表五の二の二の表、同様式別表九の記載要領３、同様式別表十記載要領、同様式別表十一の表及び同様式別表十一記載要領の改正規定並びに第二十号様式別表一記載要領の改正規定<font color="lightsalmon">（「<font color="darkkhaki">（１８）</font>の欄」を「<font color="darkkhaki">（１８）</font>の欄の金額）</font>、分配時調整外国税相当額の個別帰属額<font color="lightsalmon">（法人税の明細書<font color="darkkhaki">（別表６の２<font color="springgreen">（２の２）</font>）</font>の<font color="darkkhaki">（２７）</font>の欄」に改める部分に限る。）</font>　令和二年一月一日

三　附則第二十条の改正規定　中小企業の事業活動の継続に資するための中小企業等経営強化法等の一部を改正する法律<font color="lightsalmon">（令和元年法律第二十一号）</font>の施行の日

--- ---


[条(全)](地方税法施行規則附則令和１年７月５日総務省令第２３号第１条_.md)  [項](地方税法施行規則附則令和１年７月５日総務省令第２３号第１条第１項.md)

~~前項(全)←~~　~~→次項(全)~~

~~前項 　 ←~~　~~→次項~~

[第１号](地方税法施行規則附則令和１年７月５日総務省令第２３号第１条第１項第１号.md)  [第２号](地方税法施行規則附則令和１年７月５日総務省令第２３号第１条第１項第２号.md)  [第３号](地方税法施行規則附則令和１年７月５日総務省令第２３号第１条第１項第３号.md)  

[目次](index地方税法施行規則.md)

