（法第七百条の六の二第一項第三号の自治省令で定める基準に関する特例）
地方税法施行規則附則平成１年７月２６日自治省令第３３号第２条

１　平成元年九月三十日において現に地方税法の一部を改正する法律<font color="lightsalmon">（平成元年法律第十四号。以下<font color="peru">「改正法」</font>という。）</font>による改正前の地方税法<font color="lightsalmon">（次条において<font color="peru">「旧法」</font>という。）</font>の規定により元売業者の指定を受けている者<font color="lightsalmon">（平成二年三月三十一日までの間に改正法による改正後の地方税法<font color="darkkhaki">（次条において<font color="peru">「新法」</font>という。）</font>第七百条の六の二第一項の規定による元売業者の指定を受ける者に限る。）</font>に係る改正後の地方税法施行規則<font color="lightsalmon">（次条において<font color="peru">「新規則」</font>という。）</font>第十八条の五第一号の規定の適用については、当分の間、同号イ中<font color="peru">「最近の三年」</font>とあるのは<font color="peru">「前年」</font>と、<font color="peru">「の平均が三十万キロリットル」</font>とあるのは<font color="peru">「が十万キロリットル」</font>と、同号ロ中<font color="peru">「百五十」</font>とあるのは<font color="peru">「十」</font>と、同号ハ中<font color="peru">「三十」</font>とあるのは<font color="peru">「十」</font>とする。

--- ---

[前条(全)←](地方税法施行規則附則平成１年７月２６日自治省令第３３号第１条_.md)    [→次条(全)](地方税法施行規則附則平成１年７月２６日自治省令第３３号第３条_.md)

[第１項(全)](地方税法施行規則附則平成１年７月２６日自治省令第３３号第２条第１項_.md) 

[第１項 　 ](地方税法施行規則附則平成１年７月２６日自治省令第３３号第２条第１項.md) 

[目次](index地方税法施行規則.md)

