<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則令和７年３月３１日財務省令第１８号第１０条第７項

令和七年十二月一日から同年十二月三十一日までの間における新規則別表第六<font color="lightsalmon">（一）</font>に定める書式の適用については、同表の備考２<font color="lightsalmon">（９）</font><font color="lightsalmon">（ニ）</font>中<font color="peru">「特定親族（当該給与等が法第１９０条の規定の適用を受けていないものである場合には、源泉控除対象親族で法第２条第１項第３０号に規定する合計所得金額又はその見積額が５８万円を超える者）」</font>とあるのは<font color="peru">「特定親族」</font>と、同表の備考２<font color="lightsalmon">（１０）</font>中<font color="peru">「源泉控除対象親族」</font>とあるのは<font color="peru">「控除対象扶養親族」</font>と、同表の備考２<font color="lightsalmon">（１４）</font>中<font color="peru">「その年中」</font>とあるのは<font color="peru">「、その年中」</font>と、<font color="peru">「こととし、租税特別措置法第４１条の１５の５第１項の規定の適用がある場合には、「摘要」の欄にその旨を記載すること」</font>とあるのは<font color="peru">「こと」</font>と、同表の備考２<font color="lightsalmon">（１７）</font>中<font color="peru">「、法第８４条の２第１項」</font>とあるのは<font color="peru">「又は法第８４条の２第１項」</font>と、<font color="peru">「又は源泉控除対象親族の氏名」</font>とあるのは<font color="peru">「の氏名」</font>と、<font color="peru">「、特定親族又は源泉控除対象親族」</font>とあるのは<font color="peru">「又は特定親族」</font>と、同表の備考２<font color="lightsalmon">（１８）</font><font color="lightsalmon">（チ）</font>中<font color="peru">「源泉控除対象親族」</font>とあるのは<font color="peru">「控除対象扶養親族」</font>とする。

--- ---

[条(全)](所得税法施行規則附則令和７年３月３１日財務省令第１８号＿第１０条_.md)  [項(全)](所得税法施行規則附則令和７年３月３１日財務省令第１８号＿第１０条第７項_.md)

[前項(全)←](所得税法施行規則附則令和７年３月３１日財務省令第１８号＿第１０条第６項_.md)  ~~→次項(全)~~

[前項 　 ←](所得税法施行規則附則令和７年３月３１日財務省令第１８号＿第１０条第６項.md)  ~~→次項~~



[目次](index所得税法施行規則.md)

