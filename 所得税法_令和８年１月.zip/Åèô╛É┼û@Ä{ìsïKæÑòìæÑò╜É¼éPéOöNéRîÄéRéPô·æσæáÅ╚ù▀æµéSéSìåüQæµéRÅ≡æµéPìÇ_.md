<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号第３条第１項

改正後の所得税法施行規則<font color="lightsalmon">（以下この条において<font color="peru">「新規則」</font>という。）</font>別表第三<font color="lightsalmon">（二）</font>、別表第三<font color="lightsalmon">（四）</font>、別表第三<font color="lightsalmon">（五）</font>、別表第五<font color="lightsalmon">（三）</font>、別表第五<font color="lightsalmon">（七）</font>、別表第五<font color="lightsalmon">（九）</font>、別表第五<font color="lightsalmon">（十五）</font>から別表第五<font color="lightsalmon">（二十九）</font>まで及び別表第六<font color="lightsalmon">（一）</font>に定める書式は、この省令の施行の日以後に所得税[法第二百二十条](所得税法＿＿＿＿＿第２２０条第１項)<font color="lightsalmon">（源泉徴収に係る所得税の納付手続）</font>、[第二百二十五条](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第２２５条第１項)<font color="lightsalmon">（支払調書及び支払通知書）</font>又は[第二百二十六条第一項](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第２２６条第１項)<font color="lightsalmon">（源泉徴収票）</font>の規定により添付し、提出し、又は交付するこれらの規定に規定する計算書、調書、通知書及び源泉徴収票について適用し、同日前に添付し、提出し、又は交付したこれらの計算書、調書、通知書及び源泉徴収票については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第３条_.md)  [項](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第３条第１項.md)

~~前項(全)←~~　  [→次項(全)](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第３条第２項_.md)

~~前項 　 ←~~　  [→次項 　 ](所得税法施行規則附則平成１０年３月３１日大蔵省令第４４号＿第３条第２項.md)



[目次](index所得税法施行規則.md)

