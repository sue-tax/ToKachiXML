<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成２０年４月３０日財務省令第２４号第１１条第６項

施行日から平成二十一年十二月三十一日までの間における新規則別表第三<font color="lightsalmon">（一）</font>の表の備考及び別表第三<font color="lightsalmon">（二）</font>の表の備考の規定の適用については、新規則別表第三<font color="lightsalmon">（一）</font>の表の備考３中<font color="peru">「配当等（源泉徴収選択口座内配当等に該当するもの及び」</font>とあるのは<font color="peru">「配当等（」</font>と、新規則別表第三<font color="lightsalmon">（二）</font>の表の備考４中<font color="peru">「限るものとし、源泉徴収選択口座内配当等に該当するものを除く」</font>とあるのは<font color="peru">「限る」</font>と、<font color="peru">「、同法」</font>とあるのは<font color="peru">「又は同法」</font>と、<font color="peru">「国外株式の配当等（源泉徴収選択口座内配当等に該当するものを除く。」</font>とあるのは<font color="peru">「国外株式の配当等（」</font>と、<font color="peru">「いう。）又は同法第９条の３の２第１項の規定の適用を受ける上場株式等の配当等」</font>とあるのは<font color="peru">「いう。）」</font>と、<font color="peru">「、国外株式の配当等又は上場株式等の配当等」</font>とあるのは<font color="peru">「又は国外株式の配当等」</font>と、<font color="peru">「、上場株式等の配当等にあつては同欄の「上場株式等の配当等（源泉徴収義務特例分）」をそれぞれ」</font>とあるのは<font color="peru">「それぞれ」</font>と、<font color="peru">「非課税適用分及び上場株式等の配当等の支払の取扱者への支払分」</font>とあるのは<font color="peru">「非課税適用分」</font>と、<font color="peru">「配当等又は同法第９条の３の２第１項の規定の適用を受ける上場株式等の配当等」</font>とあるのは<font color="peru">「配当等」</font>とする。

--- ---

[条(全)](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１１条_.md)  [項(全)](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１１条第６項_.md)

[前項(全)←](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１１条第５項_.md)  ~~→次項(全)~~

[前項 　 ←](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１１条第５項.md)  ~~→次項~~



[目次](index所得税法施行規則.md)

