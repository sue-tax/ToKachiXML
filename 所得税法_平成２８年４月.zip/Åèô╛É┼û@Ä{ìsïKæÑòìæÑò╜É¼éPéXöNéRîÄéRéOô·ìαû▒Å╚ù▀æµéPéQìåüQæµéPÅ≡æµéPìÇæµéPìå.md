<font color="lightsalmon">（施行期日）</font>
[所得税法施行規則附則平成１９年３月３０日財務省令第１２号第１条第１項](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第１条第１項)第１号

目次の改正規定<font color="lightsalmon">（<font color="peru">「[第二十三条の二](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第２３条の２第１項)」</font>を<font color="peru">「[第二十三条の二](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第２３条の２第１項)―[第二十三条の四](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第２３条の４第１項)」</font>に改める部分に限る。）</font>、第二編第一章第三節第一款の二中[第二十三条の二](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第２３条の２第１項)を[第二十三条の四](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第２３条の４第１項)とし、同条の前に二条を加える改正規定、別表第五<font color="lightsalmon">（七）</font>の改正規定<font color="lightsalmon">（同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ロ）</font>に係る部分<font color="darkkhaki">（<font color="peru">「第２条第２１項」</font>を<font color="peru">「第２条第１４項」</font>に改める部分を除く。）</font>及び同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ハ）</font>に係る部分に限る。）</font>及び別表第五<font color="lightsalmon">（二十九）</font>の改正規定<font color="lightsalmon">（同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ロ）</font>に係る部分<font color="darkkhaki">（<font color="peru">「第２条第２１項」</font>を<font color="peru">「第２条第１４項」</font>に改める部分を除く。）</font>及び同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ハ）</font>に係る部分に限る。）</font>並びに附則[第七条第四項](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第７条第４項)の規定　平成十九年五月一日

--- ---

[条(全)](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第１条_.md)    [項(全)](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第１条第１項_.md)    [項](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第１条第１項.md)

~~前号←~~　  [→次号](所得税法施行規則附則平成１９年３月３０日財務省令第１２号＿第１条第１項第２号.md)

[目次](index所得税法施行規則.md)

