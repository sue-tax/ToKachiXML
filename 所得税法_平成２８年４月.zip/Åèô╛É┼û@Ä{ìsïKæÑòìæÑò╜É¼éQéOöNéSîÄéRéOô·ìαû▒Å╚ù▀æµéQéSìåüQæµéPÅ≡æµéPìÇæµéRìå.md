<font color="lightsalmon">（施行期日）</font>
[所得税法施行規則附則平成２０年４月３０日財務省令第２４号第１条第１項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第１項)第３号

[第八十三条第三項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第８３条第３項)の改正規定、[第九十七条第四項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第９７条第４項)の改正規定、別表第三<font color="lightsalmon">（一）</font>の改正規定<font color="lightsalmon">（同表の備考２中<font color="peru">「配当等」</font>の次に<font color="peru">「（租税特別措置法第３７条の１１の６第１項に規定する源泉徴収選択口座内配当等（以下この表において「源泉徴収選択口座内配当等」という。）に該当するものを除く。）」</font>を加える部分に限る。）</font>、別表第三<font color="lightsalmon">（二）</font>の改正規定<font color="lightsalmon">（同表の表に係る部分<font color="darkkhaki">（<font color="peru">「総合課税適用分（合計）」</font>を<font color="peru">「総合課税等適用分（合計）」</font>に改める部分を除く。）</font>及び同表の備考２に係る部分<font color="darkkhaki">（<font color="peru">「、特定受益証券発行信託の収益の分配及び法人課税信託」</font>を<font color="peru">「及び特定受益証券発行信託」</font>に改める部分、同表の備考２<font color="springgreen">（２）</font>に係る部分、同表の備考２<font color="springgreen">（５）</font><font color="springgreen">（イ）</font>に係る部分及び同表の備考２<font color="springgreen">（５）</font><font color="springgreen">（ハ）</font>に係る部分を除く。）</font>に限る。）</font>、別表第三<font color="lightsalmon">（四）</font>の改正規定<font color="lightsalmon">（同表の備考１に係る部分<font color="darkkhaki">（同表の備考１<font color="springgreen">（１）</font>に係る部分を除く。）</font>、同表の備考７中<font color="peru">「規定する剰余金の配当」</font>を<font color="peru">「規定する配当等（源泉徴収選択口座内配当等に該当するものを除く。）のうち同項に規定する剰余金の配当」</font>に改める部分、同表の備考８中<font color="peru">「配当等に」</font>を<font color="peru">「配当等（源泉徴収選択口座内配当等に該当するものを除く。）に」</font>に改める部分、同表の備考９中<font color="peru">「並びに」</font>の次に<font color="peru">「源泉徴収選択口座内配当等に該当するもの並びに」</font>を加える部分、同表の備考２６中<font color="peru">「又は」</font>を<font color="peru">「若しくは」</font>に改め、<font color="peru">「受けるもの」</font>の次に<font color="peru">「又は租税特別措置法第９条の３の２第１項に規定する上場株式等の配当等で同項に規定する支払の取扱者を通じて支払をしたもの」</font>を加える部分及び同表の備考２６の次に次のように加える部分に限る。）</font>、別表第五<font color="lightsalmon">（三）</font>から別表第五<font color="lightsalmon">（七）</font>までの改正規定及び別表第八<font color="lightsalmon">（二）</font>の改正規定並びに附則[第十一条第三項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１１条第３項)及び[第四項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第４項)の規定　平成二十二年一月一日

--- ---

[条(全)](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条_.md)    [項(全)](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第１項_.md)    [項](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第１項.md)

[前号←](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第１項第２号.md)    [→次号](所得税法施行規則附則平成２０年４月３０日財務省令第２４号＿第１条第１項第４号.md)

[目次](index所得税法施行規則.md)

