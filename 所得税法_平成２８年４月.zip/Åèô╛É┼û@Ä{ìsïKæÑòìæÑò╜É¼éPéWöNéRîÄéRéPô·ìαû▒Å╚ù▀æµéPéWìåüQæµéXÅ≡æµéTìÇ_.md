<font color="lightsalmon">（書式に関する経過措置）</font>
所得税法施行規則附則平成１８年３月３１日財務省令第１８号第９条第５項

別表第五<font color="lightsalmon">（七）</font>の改正規定<font color="lightsalmon">（同表中<font color="peru">「自己の株式の取得等の場合の」</font>を<font color="peru">「配当等とみなす金額に関する」</font>に改める部分、同表の備考１に係る部分、同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ロ）</font>に係る部分、同表の備考２<font color="darkkhaki">（３）</font><font color="darkkhaki">（ハ）</font>中<font color="peru">「掲げる資本若しくは出資の減少」</font>を<font color="peru">「掲げる資本の払戻し」</font>に、<font color="peru">「当該資本若しくは出資の減少又は」</font>を<font color="peru">「当該資本の払戻し又は当該」</font>に改める部分、同表の備考２<font color="darkkhaki">（４）</font><font color="darkkhaki">（ハ）</font>に係る部分並びに同表の備考２<font color="darkkhaki">（８）</font>中<font color="peru">「資本若しくは出資の減少」</font>を<font color="peru">「資本の払戻し」</font>に改める部分及び<font color="peru">「脱退」</font>を<font color="peru">「脱退、組織変更」</font>に改める部分に限る。）</font>、別表第五<font color="lightsalmon">（二十八）</font>の改正規定<font color="lightsalmon">（同表の備考２<font color="darkkhaki">（２）</font>中<font color="peru">「、同法第３７条の１４第１項に規定する株式交換等（以下この表において「株式交換等」という。）により移転があつた同項に規定する特定子会社株式（以下この表において「特定子会社株式」という。）については特定子会社株式」</font>を削る部分及び同表の備考２<font color="darkkhaki">（６）</font>を削り、同表の備考２<font color="darkkhaki">（７）</font>を同表の備考２<font color="darkkhaki">（６）</font>とし、同表の備考２<font color="darkkhaki">（８）</font>から<font color="darkkhaki">（１０）</font>までを削る部分を除く。）</font>及び別表第五<font color="lightsalmon">（二十九）</font>の改正規定<font color="lightsalmon">（同表の備考１に係る部分、同表の備考２<font color="darkkhaki">（２）</font><font color="darkkhaki">（ロ）</font>に係る部分、同表の備考２<font color="darkkhaki">（３）</font>に係る部分、同表の備考２<font color="darkkhaki">（４）</font><font color="darkkhaki">（ハ）</font>に係る部分、同表の備考２<font color="darkkhaki">（４）</font><font color="darkkhaki">（ホ）</font>中<font color="peru">「自己の株式」</font>の次に<font color="peru">「又は出資」</font>を加える部分、同表の備考２<font color="darkkhaki">（４）</font>に次のように加える部分、同表の備考２<font color="darkkhaki">（６）</font>に係る部分及び同表の備考２<font color="darkkhaki">（８）</font>に係る部分<font color="darkkhaki">（<font color="peru">「、株式の消却」</font>を削る部分及び<font color="peru">「退社」</font>を<font color="peru">「自己の出資の取得、出資の消却、出資の払戻し、退社」</font>に改める部分を除く。）</font>に限る。）</font>による新規則別表第五<font color="lightsalmon">（七）</font>、別表第五<font color="lightsalmon">（二十八）</font>及び別表第五<font color="lightsalmon">（二十九）</font>に定める書式は、会社法施行日以後に新[法第二百二十五条](所得税法＿＿＿＿＿第２２５条第１項)の規定により提出し、又は交付する同条に規定する調書及び通知書について適用し、会社法施行日前に提出し、又は交付した当該調書及び通知書については、なお従前の例による。

--- ---


[条(全)](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条_.md)  [項](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条第５項.md)

[前項(全)←](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条第４項_.md)    [→次項(全)](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条第６項_.md)

[前項 　 ←](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条第４項.md)    [→次項 　 ](所得税法施行規則附則平成１８年３月３１日財務省令第１８号＿第９条第６項.md)



[目次](index所得税法施行規則.md)

